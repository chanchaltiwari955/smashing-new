/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 435);
/******/ })
/************************************************************************/
/******/ ({

/***/ 0:
/***/ (function(module, exports) {

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    "default": obj
  };
}

module.exports = _interopRequireDefault;
module.exports["default"] = module.exports, module.exports.__esModule = true;

/***/ }),

/***/ 2:
/***/ (function(module, exports) {

function _classCallCheck(instance, Constructor) {
  if (!(instance instanceof Constructor)) {
    throw new TypeError("Cannot call a class as a function");
  }
}

module.exports = _classCallCheck;
module.exports["default"] = module.exports, module.exports.__esModule = true;

/***/ }),

/***/ 3:
/***/ (function(module, exports) {

function _defineProperties(target, props) {
  for (var i = 0; i < props.length; i++) {
    var descriptor = props[i];
    descriptor.enumerable = descriptor.enumerable || false;
    descriptor.configurable = true;
    if ("value" in descriptor) descriptor.writable = true;
    Object.defineProperty(target, descriptor.key, descriptor);
  }
}

function _createClass(Constructor, protoProps, staticProps) {
  if (protoProps) _defineProperties(Constructor.prototype, protoProps);
  if (staticProps) _defineProperties(Constructor, staticProps);
  return Constructor;
}

module.exports = _createClass;
module.exports["default"] = module.exports, module.exports.__esModule = true;

/***/ }),

/***/ 435:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(436);


/***/ }),

/***/ 436:
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__(0);

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _classCallCheck2 = _interopRequireDefault(__webpack_require__(2));

var _createClass2 = _interopRequireDefault(__webpack_require__(3));

var Loading = /*#__PURE__*/function () {
  function Loading() {
    var _this = this;

    (0, _classCallCheck2.default)(this, Loading);
    this.el = document.getElementById('loading');
    this.bg = document.querySelector('#loading-bg');
    this.number = document.querySelector('#loading-number');
    this.done = false;
    this.progress = this.progress.bind(this);
    this.event = new CustomEvent('customload');
    this.isMobile = window.innerWidth < 970;
    this.hideItems();
    this.loadImages(function () {
      _this.done = true;
      if (_this.number) _this.number.innerHTML = "100%";

      _this.close();
    }, this.progress);
    setTimeout(function () {
      if (!_this.done) _this.open();
    }, 3000);
  }

  (0, _createClass2.default)(Loading, [{
    key: "setImages",
    value: function setImages() {
      if (this.isMobile) {
        Array.from(document.querySelectorAll('img[data-responsive-src]')).forEach(function (image) {
          var src = image.src;
          image.src = src.replace(/\.jpg|\.webp/, function (ext) {
            return '-m' + ext;
          });
        });
        Array.from(document.querySelectorAll('[data-bg-img][data-responsive-src]')).forEach(function (image) {
          var src = image.getAttribute('data-bg-img');
          image.setAttribute('data-bg-img', src.replace(/\.jpg|\.webp/, function (ext) {
            return '-m' + ext;
          }));
        });
      }

      Array.from(document.querySelectorAll('img[data-src]')).forEach(function (img) {
        img.src = img.dataset.src;
      });
      Array.from(document.querySelectorAll('[data-bg-img]')).forEach(function (item) {
        item.style.backgroundImage = "url('".concat(item.getAttribute('data-bg-img'), "')");
      });
    }
  }, {
    key: "loadImages",
    value: function loadImages(callback, progress) {
      this.setImages();
      var images = Array.from(document.querySelectorAll('img'));
      var done = false;

      function loadedL() {
        return images.filter(function (image) {
          return image.complete;
        }).length;
      }

      if (loadedL() === images.length) {
        done = true;
        callback();
      } else {
        images.forEach(function (image) {
          image.addEventListener('load', function () {
            if (progress) progress(loadedL() / images.length);

            if (!done && loadedL() === images.length) {
              done = true;
              callback();
            }
          });
        });
      }

      setTimeout(function () {
        if (!done) {
          done = true;
          callback();
        }
      }, 1000);
    }
  }, {
    key: "progress",
    value: function progress(prc) {
      if (this.number) this.number.innerHTML = "".concat(Math.ceil(prc * 100), "%");
    }
  }, {
    key: "open",
    value: function open() {
      this.isOpen = true;
      if (this.number) this.number.style.opacity = 1;
    }
  }, {
    key: "close",
    value: function close() {
      var _this2 = this;

      this.isOpen = false;
      this.el.classList.add('hide');
      this.bg.style.opacity = 0;
      if (this.number) this.number.style.opacity = 0;
      setTimeout(function () {
        document.documentElement.setAttribute('data-custom-loaded', true);
        window.dispatchEvent(_this2.event);
      }, 500);
    }
  }, {
    key: "hideItems",
    value: function hideItems() {
      var _this3 = this;

      this.el.classList.add('no-transition');
      if (this.number) this.number.style.opacity = 0;
      setTimeout(function () {
        _this3.el.classList.remove('no-transition');
      }, 500);
    }
  }]);
  return Loading;
}();

exports.default = Loading;
var loading = new Loading();

/***/ })

/******/ });