!(function (e) {
  var t = {};
  function n(r) {
      if (t[r]) return t[r].exports;
      var i = (t[r] = { i: r, l: !1, exports: {} });
      return e[r].call(i.exports, i, i.exports, n), (i.l = !0), i.exports;
  }
  (n.m = e),
      (n.c = t),
      (n.d = function (e, t, r) {
          n.o(e, t) || Object.defineProperty(e, t, { enumerable: !0, get: r });
      }),
      (n.r = function (e) {
          "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, { value: "Module" }), Object.defineProperty(e, "__esModule", { value: !0 });
      }),
      (n.t = function (e, t) {
          if ((1 & t && (e = n(e)), 8 & t)) return e;
          if (4 & t && "object" == typeof e && e && e.__esModule) return e;
          var r = Object.create(null);
          if ((n.r(r), Object.defineProperty(r, "default", { enumerable: !0, value: e }), 2 & t && "string" != typeof e))
              for (var i in e)
                  n.d(
                      r,
                      i,
                      function (t) {
                          return e[t];
                      }.bind(null, i)
                  );
          return r;
      }),
      (n.n = function (e) {
          var t =
              e && e.__esModule
                  ? function () {
                        return e.default;
                    }
                  : function () {
                        return e;
                    };
          return n.d(t, "a", t), t;
      }),
      (n.o = function (e, t) {
          return Object.prototype.hasOwnProperty.call(e, t);
      }),
      (n.p = ""),
      n((n.s = 151));
})([
  ,
  ,
  function (e, t) {
      (e.exports = function (e) {
          return e && e.__esModule ? e : { default: e };
      }),
          (e.exports.default = e.exports),
          (e.exports.__esModule = !0);
  },
  ,
  ,
  ,
  function (e, t, n) {
      "use strict";
      var r = n(2);
      Object.defineProperty(t, "__esModule", { value: !0 }), (t.default = void 0);
      r(n(157));
      function i(e) {
          var t;
          switch (e) {
              case "safari":
                  t = void 0 !== window.safari && window.safari.pushNotification;
                  break;
              case "safari mobile":
                  t = /iPhone/i.test(navigator.userAgent) && /Safari/i.test(navigator.userAgent);
                  break;
              case "samsung":
                  t = /SamsungBrowser/.test(navigator.userAgent);
                  break;
              case "chrome":
                  t = /Chrome/.test(navigator.userAgent) && /Google Inc/.test(navigator.vendor) && !/SamsungBrowser/.test(navigator.userAgent);
                  break;
              case "chrome mobile":
                  t = /Chrome/.test(navigator.userAgent) && /Google Inc/.test(navigator.vendor) && !/SamsungBrowser/.test(navigator.userAgent) && window.chrome && !window.chrome.webstore;
                  break;
              case "firefox mobile":
                  t = !/Chrome/.test(navigator.userAgent) && /Mozilla/.test(navigator.userAgent) && /Firefox/.test(navigator.userAgent) && /Mobile/.test(navigator.userAgent);
                  break;
              case "firefox":
                  t = !/Chrome/.test(navigator.userAgent) && /Mozilla/.test(navigator.userAgent) && /Firefox/.test(navigator.userAgent);
                  break;
              case "ie":
                  t = /MSIE/.test(window.navigator.userAgent) || /NET/.test(window.navigator.userAgent);
                  break;
              case "edge":
                  t = /Edge/.test(window.navigator.userAgent);
                  break;
              case "ms":
                  t = /Edge/.test(window.navigator.userAgent) || /MSIE/.test(window.navigator.userAgent) || /NET/.test(window.navigator.userAgent);
                  break;
              default:
                  t = !1;
          }
          return t;
      }
      function a(e, t) {
          var n = new Image();
          return (n.src = e), (n.onload = t), n;
      }
      var s = {
          waitForLoader: function (e) {
              document.documentElement.getAttribute("data-custom-loaded")
                  ? e()
                  : window.addEventListener("customload", function () {
                        e();
                    });
          },
          smoothstep: function (e, t, n) {
              return n <= e ? e : n >= t ? t : (n = (n - e) / (t - e)) * n * (3 - 2 * n);
          },
          getLang: function () {
              return document.querySelector("html").getAttribute("lang");
          },
          isArabic: function () {
              var e = document.querySelector("html");
              return "ar" === e.getAttribute("lang") || "rtl" === e.getAttribute("dir");
          },
          isInViewportDom: function (e, t) {
              var n,
                  r,
                  i,
                  a,
                  s = e.getBoundingClientRect();
              (n = s.left), (r = s.top + (void 0 !== t ? t : 0)), (i = s.width), (a = s.height);
              var o = Math.max(document.documentElement.clientWidth, window.innerWidth || 0);
              return r < Math.max(document.documentElement.clientHeight, window.innerHeight || 0) && r + a > 0 && n < o && n + i > 0;
          },
          lineBreak: function (e, t, n, r) {
              n.innerHTML = e
                  .split(/\s/)
                  .map(function (e) {
                      return '<span class="word">' + e + "</span>";
                  })
                  .join("");
              var i = 0;
              if (
                  (Array.from(n.querySelectorAll(".word")).forEach(function (e) {
                      i += c(e);
                  }),
                  i > t)
              ) {
                  n.innerHTML = "";
                  var a = document.createElement("span");
                  a.classList.add("line"), n.appendChild(a);
                  var s = a;
                  e.split(/\s/).forEach(function (e, r) {
                      if (((i = document.createElement("span")).classList.add("word"), (i.innerHTML = 0 == r ? e : " " + e), s.appendChild(i), c(s) > t)) {
                          i.remove();
                          var i,
                              a = document.createElement("span");
                          a.classList.add("line"), (i = document.createElement("span")).classList.add("word"), (i.innerHTML = 0 == r ? e : " " + e), a.appendChild(i), (s = a), n.appendChild(a);
                      }
                  });
                  var o = Array.from(n.querySelectorAll(".line")).find(function (e) {
                      return 1 == e.children.length;
                  });
                  if (r && o) {
                      var l = o.previousElementSibling.querySelector(".word:last-child"),
                          d = l.innerHTML.replace(/^\s/, "");
                      l.remove();
                      var u = document.createElement("span");
                      u.classList.add("word"), (u.innerHTML = d), o.prepend(u);
                  }
              }
              function c(e) {
                  if (e.classList.contains("word")) {
                      var t = e.getBoundingClientRect().width,
                          n = e.innerHTML;
                      return -1 !== n.indexOf(" ") && (t += t / n.length), t;
                  }
                  var r = 0;
                  return (
                      Array.from(e.querySelectorAll(".word")).forEach(function (e) {
                          r += c(e);
                      }),
                      r
                  );
              }
              Array.from(n.querySelectorAll(".line")).forEach(function (e) {
                  e.children[0].innerHTML = e.children[0].innerHTML.replace(/\s/, "");
              });
          },
          getEmbedURL: function (e, t) {
              var n;
              if (e.search && -1 !== e.search(/\/\/www.youtube.com|\/\/youtube.com|\/\/www.youtu.be|\/\/youtu.be/)) {
                  if (-1 !== e.search(/\/\//))
                      if (-1 !== e.search("youtu.be")) n = e.replace(/.*youtu.be\//, "");
                      else n = new URL(e).searchParams.get("v");
                  var r = "https://www.youtube.com/embed/".concat(n, "?modestbranding=1&showinfo=0&rel=0");
                  return t ? { url: r, id: n } : r;
              }
              if (e.search && -1 !== e.search(/\/\/www.vimeo.com|\/\/vimeo.com/)) {
                  n = e.replace(/.*vimeo.com\//, "");
                  r = "https://player.vimeo.com/video/".concat(n);
                  return t ? { url: r, id: n } : r;
              }
              return t ? { url: e, id: n } : e;
          },
          isVideoNative: function (e) {
              return e.search && (-1 === e.search(/\/\/www.youtube.com|\/\/youtube.com|\/\/www.youtu.be|\/\/youtu.be/) || -1 !== e.search(/\/\/www.vimeo.com|\/\/vimeo.com/)) && /\.mp4\?*/.test(e);
          },
          getPosition: function (e) {
              for (var t = 0, n = 0; e; ) (t += e.offsetLeft - e.scrollLeft + e.clientLeft), (n += e.offsetTop - e.scrollTop + e.clientTop), (e = e.offsetParent);
              return { x: t, y: n };
          },
          testBrowser: i,
          getBrowser: function () {
              return i("chrome") ? "chrome" : i("safari") ? "safari" : i("safari mobile") ? "safari-mobile" : i("firefox") ? "firefox" : i("ie") ? "ie" : i("edge") ? "edge" : void 0;
          },
          ease: {
              bounce: function (e) {
                  return Math.pow(2, -10 * e) * Math.sin(((e - 0.075) * (2 * Math.PI)) / 0.3) + 1;
              },
              out: function (e) {
                  return 1 - --e * e * e * e;
              },
              inQuint: function (e) {
                  return e * e * e * e * e * e * e * e * e * e * e * e * e;
              },
              out2: function (e) {
                  return e * (2 - e);
              },
          },
          round: function (e, t) {
              return (t = t ? Math.pow(10, t) : 1e3), Math.round(e * t) / t;
          },
          lerp: function (e, t, n) {
              return (1 - n) * e + n * t;
          },
          loadImages: function (e, t) {
              for (
                  var n = [],
                      r = e.length,
                      i = function () {
                          0 === --r && t(n);
                      },
                      s = 0;
                  s < r;
                  ++s
              ) {
                  var o = a(e[s], i);
                  n.push(o);
              }
          },
          loadImage: a,
      };
      t.default = s;
  },
  function (e, t, n) {
      var r = n(153),
          i = n(154),
          a = n(155),
          s = n(156);
      (e.exports = function (e) {
          return r(e) || i(e) || a(e) || s();
      }),
          (e.exports.default = e.exports),
          (e.exports.__esModule = !0);
  },
  function (e, t, n) {
      "use strict";
      var r = n(2);
      Object.defineProperty(t, "__esModule", { value: !0 }), (t.default = void 0);
      var i = r(n(36)),
          a = r(n(37)),
          s = r(n(43)),
          o = r(n(6)),
          l = (function () {
              function e(t) {
                  var n = this;
                  (0, i.default)(this, e), (this.data = { t: 0, c: 0 }), (this.page = document.getElementById("page")), (this.scrollingElement = document.getElementById("main")), (this.tween = null), (this.paralax = t);
                  var r = location.hash;
                  (this.isIE = o.default.testBrowser("ie")),
                      r && "" !== r && ((location.hash = ""), this.goTo(r, 0.6)),
                      window.addEventListener("wheel", function (e) {
                          n.handleWheel(e);
                      }),
                      document.addEventListener(
                          "touchmove",
                          function (e) {
                              n.handleTouch(e);
                          },
                          { passive: !1 }
                      ),
                      this.scrollingElement.addEventListener("scroll", function (e) {
                          n.handleScroll(e);
                      }),
                      this.render();
              }
              return (
                  (0, a.default)(e, [
                      {
                          key: "handleScroll",
                          value: function () {
                              var e = page.scrollHeight - window.innerHeight,
                                  t = this.scrollingElement.scrollTop;
                              this.data.t = o.default.round(t / e);
                          },
                      },
                      {
                          key: "handleWheel",
                          value: function () {
                              this.tween && this.tween.kill();
                          },
                      },
                      {
                          key: "handleTouch",
                          value: function () {
                              this.tween && this.tween.kill();
                          },
                      },
                      {
                          key: "render",
                          value: function () {
                              var e = this;
                              this.data.c += 0.12 * (this.data.t - this.data.c);
                              var t = o.default.round(this.data.c);
                              t !== this.data.t && this.paralax && this.paralax(t),
                                  requestAnimationFrame(function () {
                                      return e.render();
                                  });
                          },
                      },
                      {
                          key: "goTo",
                          value: function (e, t) {
                              var n = this,
                                  r = document.querySelector(e);
                              r &&
                                  this.waitForAssets(function () {
                                      var e = r.offsetTop + r.offsetParent.offsetTop;
                                      n.tween = s.default.to(n.scrollingElement, {
                                          duration: 2,
                                          scrollTop: e,
                                          delay: t || 0,
                                          overwrite: "false",
                                          ease: "Power2.easeInOut",
                                          onComplete: function () {
                                              n.handleScroll();
                                          },
                                      });
                                  });
                          },
                      },
                      {
                          key: "waitForAssets",
                          value: function (e) {
                              var t = !1;
                              "complete" === document.readyState
                                  ? ((t = !0), e())
                                  : document.addEventListener("readystatechange", function () {
                                        t || "complete" !== document.readyState || ((t = !0), e());
                                    });
                          },
                      },
                  ]),
                  e
              );
          })();
      t.default = l;
  },
  ,
  function (e, t, n) {
      "use strict";
      n.r(t);
  },
  function (e, t, n) {
      "use strict";
      var r = n(2);
      Object.defineProperty(t, "__esModule", { value: !0 }), (t.default = void 0);
      var i = r(n(7)),
          a = r(n(36)),
          s = r(n(37)),
          o = r(n(43)),
          l = r(n(6)),
          d =
              (r(n(160)),
              (function () {
                  function e() {
                      var t = this;
                      (0, a.default)(this, e),
                          (this.el = document.getElementById("menu")),
                          (this.button = document.getElementById("menu-toggle")),
                          (this.navBar = document.getElementById("nav")),
                          (this.bg = document.querySelector("#menu .bg")),
                          (this.navItems = Array.from(document.querySelectorAll(".nav-item-container"))),
                          (this.langs = document.getElementById("nav-langs")),
                          (this.nav = document.getElementById("nav-items")),
                          this.button.addEventListener("click", function () {
                              t.toggle();
                          }),
                          (this.items = Array.from(this.el.querySelectorAll("a"))),
                          Array.from(document.querySelectorAll('[data-lang="'.concat(l.default.getLang(), '"]'))).forEach(function (e) {
                              e.classList.add("active");
                          }),
                          (this.langsButton = document.getElementById("nav-langs")),
                          (this.langsButtonBG = document.getElementById("nav-langs-bg")),
                          o.default.set(this.langsButtonBG, { height: this.langsButton.clientHeight }),
                          this.langsButton.addEventListener("mouseover", function () {
                              o.default.to(t.langsButtonBG, { duration: 1, height: t.langsButton.scrollHeight, ease: "Power4.easeOut" });
                          }),
                          this.langsButton.addEventListener("mouseleave", function () {
                              o.default.to(t.langsButtonBG, { duration: 1, height: t.langsButton.clientHeight, ease: "Power4.easeOut" });
                          }),
                          this.hide();
                  }
                  return (
                      (0, s.default)(e, [
                          {
                              key: "toggle",
                              value: function () {
                                  this.isOpen ? this.close() : this.open();
                              },
                          },
                          {
                              key: "open",
                              value: function () {
                                  if (!this.isOpen) {
                                      (this.isOpen = !0), this.button.classList.add("close"), this.el.classList.add("show"), o.default.to(this.bg, 2, { x: "0%", ease: "Power4.easeInOut" });
                                      o.default.to(this.navItems, { duration: 1.5, x: 0, opacity: 1, stagger: 0.1, delay: 1, ease: "Power4.easeOut" }),
                                          o.default.to(this.langs, { duration: 1.5, y: -30, autoAlpha: 1, display: "block", delay: 1, ease: "Power4.easeOut" }),
                                          this.nav.classList.toggle("show");
                                  }
                              },
                          },
                          {
                              key: "close",
                              value: function () {
                                  if (this.isOpen) {
                                      o.default.killTweensOf([].concat((0, i.default)(this.items), [this.bg])), (this.isOpen = !1);
                                      o.default.to(this.navItems, { duration: 1, x: 50, opacity: 0, stagger: 0.1, ease: "Power4.easeOut" }),
                                          o.default.to(this.langs, { duration: 1.5, y: 0, autoAlpha: 0, display: "none", delay: 0.8, ease: "Power4.easeOut" }),
                                          o.default.to(this.bg, 1, { x: "100%", delay: 0.8, ease: "Power4.easeInOut" }),
                                          this.el.classList.remove("show"),
                                          this.button.classList.remove("close"),
                                          this.nav.classList.toggle("show");
                                  }
                              },
                          },
                          {
                              key: "hide",
                              value: function () {
                                  o.default.set(this.items, { opacity: 0, y: -100 }), o.default.set(this.bg, { x: "100%" });
                              },
                          },
                      ]),
                      e
                  );
              })());
      t.default = d;
  },
  function (e, t, n) {
      "use strict";
      var r = n(2);
      Object.defineProperty(t, "__esModule", { value: !0 }), (t.default = void 0);
      var i = r(n(36)),
          a = r(n(37)),
          s = (r(n(114)), r(n(43))),
          o = (function () {
              function e() {
                  var t = this;
                  (0, i.default)(this, e),
                      (this.el = document.getElementById("share")),
                      (this.buttonClose = document.getElementById("share-close")),
                      (this.container = document.getElementById("share-container")),
                      (this.bg = document.querySelector("#share .bg")),
                      (this.copy = document.getElementById("share-text").getAttribute("content")),
                      Array.from(document.querySelectorAll(".share-item[data-type]")).forEach(function (e) {
                          e.addEventListener("click", function () {
                              var n = e.getAttribute("data-copy"),
                                  r = e.getAttribute("data-url");
                              t.shareByType(e.getAttribute("data-type"), n || r || t.copy);
                          });
                      }),
                      this.el &&
                          (Array.from(document.querySelectorAll(".open-main-share")).forEach(function (e) {
                              e.addEventListener("click", function () {
                                  t.open();
                              });
                          }),
                          this.buttonClose.addEventListener("click", function () {
                              t.close();
                          }),
                          this.el.addEventListener("click", function (e) {
                              e.target.closest(".bg") && t.close();
                          }),
                          this.hide());
              }
              return (
                  (0, a.default)(e, [
                      {
                          key: "shareByType",
                          value: function (e, t) {
                              var n = t.match(/#[^ ]+/),
                                  r = t.match(/(http|https):\/\/[^ ]+/);
                              switch (((r = r && r[0] ? r[0] : window.location.href), e)) {
                                  case "twitter":
                                      window.open("https://twitter.com/intent/tweet?text=".concat(encodeURIComponent("".concat(t))), "sharer", "toolbar=0,status=0,width=580,height=480");
                                      break;
                                  case "facebook":
                                      FB.ui({ method: "share", hashtag: n, href: r, quote: t });
                                      break;
                                  case "whatsapp":
                                      window.open("https://wa.me/?text=".concat(r), "_blank");
                                      break;
                                  case "linkedin":
                                      window.open("https://linkedin.com/shareArticle?mini=true&url=".concat(r, "&summary="), "sharer", "toolbar=0,status=0,width=580,height=325");
                              }
                          },
                      },
                      {
                          key: "open",
                          value: function () {
                              var e = this;
                              this.isOpen ||
                                  ((this.isOpen = !0),
                                  this.el.classList.add("show"),
                                  s.default.fromTo(this.bg, { duration: 0.7, opacity: 0 }, { opacity: 1, ease: "Power2.easeIn" }),
                                  window.innerWidth <= 580 &&
                                      setTimeout(function () {
                                          var t = window.innerHeight - e.container.querySelector("#share-content").getBoundingClientRect().height - 96;
                                          e.container.querySelector("#share-image").style.height = "".concat(t, "px");
                                      }, 200),
                                  s.default.fromTo(
                                      this.container,
                                      { duration: 1, opacity: 0 },
                                      {
                                          opacity: 1,
                                          delay: 0.3,
                                          ease: "Power2.easeIn",
                                          onComplete: function () {
                                              e.buttonClose.classList.add("show");
                                          },
                                      }
                                  ));
                          },
                      },
                      {
                          key: "close",
                          value: function () {
                              var e = this;
                              this.isOpen &&
                                  ((this.isOpen = !1),
                                  this.buttonClose.classList.remove("show"),
                                  s.default.to(this.container, { duration: 0.5, opacity: 0, ease: "Power4.easeOut" }),
                                  s.default.to(this.bg, {
                                      duration: 1,
                                      opacity: 0,
                                      delay: 0.3,
                                      ease: "Power4.easeOut",
                                      onComplete: function () {
                                          e.hide(), e.el.classList.remove("show"), e.buttonClose.classList.add("show");
                                      },
                                  }));
                          },
                      },
                      {
                          key: "hide",
                          value: function () {
                              s.default.set([this.bg, this.container], { opacity: 0, overwrite: "all" });
                          },
                      },
                  ]),
                  e
              );
          })();
      t.default = o;
  },
  function (e, t, n) {
      "use strict";
      var r = n(2);
      Object.defineProperty(t, "__esModule", { value: !0 }), (t.default = void 0);
      var i = r(n(36)),
          a = r(n(37)),
          s = (r(n(114)), r(n(43))),
          o = (function () {
              function e() {
                  var t = this;
                  (0, i.default)(this, e),
                      (this.el = document.getElementById("search")),
                      (this.buttonOpen = document.getElementById("nav-search")),
                      (this.buttonClose = document.getElementById("search-close")),
                      (this.container = document.getElementById("search-container")),
                      (this.content = document.getElementById("search-content")),
                      (this.bg = document.querySelector("#search .bg")),
                      (this.input = document.getElementById("input-search")),
                      (this.clear = document.querySelector(".clear-search")),
                      (this.vh = window.innerHeight),
                      this.el &&
                          (this.buttonOpen.addEventListener("click", function () {
                              t.open();
                          }),
                          this.buttonClose.addEventListener("click", function () {
                              t.close();
                          }),
                          this.el.addEventListener("click", function (e) {
                              e.target.closest(".bg") && t.close();
                          }),
                          this.hide(),
                          this.input.addEventListener("keydown", function () {
                              console.log(t.input.value.length), t.input.value.length > 1 ? t.showContent() : t.hideContent();
                          }),
                          this.clear.addEventListener("click", function () {
                              t.clearInput();
                          }));
              }
              return (
                  (0, a.default)(e, [
                      {
                          key: "open",
                          value: function () {
                              var e = this;
                              this.isOpen ||
                                  ((this.isOpen = !0),
                                  this.el.classList.add("show"),
                                  s.default.fromTo(this.bg, { duration: 0.7, opacity: 0 }, { opacity: 1, ease: "Power2.easeIn" }),
                                  s.default.fromTo(
                                      this.container,
                                      { duration: 1, opacity: 0 },
                                      {
                                          opacity: 1,
                                          delay: 0.3,
                                          ease: "Power2.easeIn",
                                          onComplete: function () {
                                              e.buttonClose.classList.add("show");
                                          },
                                      }
                                  ));
                          },
                      },
                      {
                          key: "close",
                          value: function () {
                              var e = this;
                              this.isOpen &&
                                  ((this.isOpen = !1),
                                  this.buttonClose.classList.remove("show"),
                                  s.default.to(this.container, { duration: 0.5, opacity: 0, ease: "Power4.easeOut" }),
                                  s.default.to(this.bg, {
                                      duration: 1,
                                      opacity: 0,
                                      delay: 0.3,
                                      ease: "Power4.easeOut",
                                      onComplete: function () {
                                          e.hide(), e.el.classList.remove("show"), e.buttonClose.classList.add("show");
                                      },
                                  }));
                          },
                      },
                      {
                          key: "hide",
                          value: function () {
                              s.default.set([this.bg, this.container], { opacity: 0, overwrite: "all" });
                          },
                      },
                      {
                          key: "showContent",
                          value: function () {
                              var e = this.vh / 2;
                              s.default.to(this.content, { duration: 1, height: e, opacity: 1, ease: "Power4.easeOut" }), s.default.to(this.container, { duration: 1, y: -0.5 * e, ease: "Power4.easeOut" });
                          },
                      },
                      {
                          key: "hideContent",
                          value: function () {
                              s.default.to(this.content, { duration: 1, height: 0, opacity: 0, ease: "Power4.easeOut" }), s.default.to(this.container, { duration: 1, y: 0, ease: "Power4.easeOut" });
                          },
                      },
                      {
                          key: "clearInput",
                          value: function () {
                              this.hideContent(), (this.input.value = "");
                          },
                      },
                  ]),
                  e
              );
          })();
      t.default = o;
  },
  ,
  ,
  function (e, t, n) {
      "use strict";
      var r = n(2)(n(158)),
          i = document.querySelector(".container"),
          a = 0;
      i && (a = i.getBoundingClientRect().left),
          Array.from(document.querySelectorAll(".cards-slider .swiper-container")).forEach(function (e) {
              var t = null !== e.getAttribute("data-half");
              new r.default(e, {
                  slidesPerView: 1.1,
                  spaceBetween: 16,
                  slidesOffsetBefore: t ? a : 16,
                  slidesOffsetAfter: t ? a : 16,
                  speed: 1e3,
                  navigation: { prevEl: ".slider-button-prev", nextEl: ".slider-button-next" },
                  pagination: { el: ".swiper-pagination", type: "progressbar" },
                  breakpoints: { 580: { slidesPerView: 2 }, 880: { slidesPerView: 3 }, 1024: { slidesPerView: 3.5 } },
                  on: {
                      resize: function (e) {
                          if (t) {
                              var n = document.querySelector(".container"),
                                  r = 0;
                              n && (r = n.getBoundingClientRect().left), (e.slidesOffsetBefore = r), (e.slidesOffsetAfter = r);
                          }
                      },
                  },
              });
          });
  },
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  function (e, t) {
      (e.exports = function (e, t) {
          if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
      }),
          (e.exports.default = e.exports),
          (e.exports.__esModule = !0);
  },
  function (e, t) {
      function n(e, t) {
          for (var n = 0; n < t.length; n++) {
              var r = t[n];
              (r.enumerable = r.enumerable || !1), (r.configurable = !0), "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r);
          }
      }
      (e.exports = function (e, t, r) {
          return t && n(e.prototype, t), r && n(e, r), e;
      }),
          (e.exports.default = e.exports),
          (e.exports.__esModule = !0);
  },
  ,
  ,
  ,
  ,
  ,
  function (e, t, n) {
      "use strict";
      function r(e) {
          if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
          return e;
      }
      function i(e, t) {
          (e.prototype = Object.create(t.prototype)), (e.prototype.constructor = e), (e.__proto__ = t);
      }
      /*!
       * GSAP 3.7.1
       * https://greensock.com
       *
       * @license Copyright 2008-2021, GreenSock. All rights reserved.
       * Subject to the terms at https://greensock.com/standard-license or for
       * Club GreenSock members, the agreement issued with that membership.
       * @author: Jack Doyle, jack@greensock.com
       */ n.r(t),
          n.d(t, "gsap", function () {
              return Xr;
          }),
          n.d(t, "default", function () {
              return Xr;
          }),
          n.d(t, "CSSPlugin", function () {
              return Yr;
          }),
          n.d(t, "TweenMax", function () {
              return jr;
          }),
          n.d(t, "TweenLite", function () {
              return Zt;
          }),
          n.d(t, "TimelineMax", function () {
              return Gt;
          }),
          n.d(t, "TimelineLite", function () {
              return Gt;
          }),
          n.d(t, "Power0", function () {
              return _n;
          }),
          n.d(t, "Power1", function () {
              return Cn;
          }),
          n.d(t, "Power2", function () {
              return Mn;
          }),
          n.d(t, "Power3", function () {
              return Pn;
          }),
          n.d(t, "Power4", function () {
              return Ln;
          }),
          n.d(t, "Linear", function () {
              return An;
          }),
          n.d(t, "Quad", function () {
              return kn;
          }),
          n.d(t, "Cubic", function () {
              return zn;
          }),
          n.d(t, "Quart", function () {
              return In;
          }),
          n.d(t, "Quint", function () {
              return On;
          }),
          n.d(t, "Strong", function () {
              return Dn;
          }),
          n.d(t, "Elastic", function () {
              return $n;
          }),
          n.d(t, "Back", function () {
              return Bn;
          }),
          n.d(t, "SteppedEase", function () {
              return qn;
          }),
          n.d(t, "Bounce", function () {
              return Rn;
          }),
          n.d(t, "Sine", function () {
              return Fn;
          }),
          n.d(t, "Expo", function () {
              return Hn;
          }),
          n.d(t, "Circ", function () {
              return Nn;
          });
      var a,
          s,
          o,
          l,
          d,
          u,
          c,
          p,
          f,
          h,
          m,
          v,
          g,
          y,
          w,
          b,
          E,
          x,
          S,
          T,
          _,
          C,
          M,
          P,
          L,
          A,
          k,
          z,
          I = { autoSleep: 120, force3D: "auto", nullTargetWarn: 1, units: { lineHeight: "" } },
          O = { duration: 0.5, overwrite: !1, delay: 0 },
          D = 1e8,
          $ = 2 * Math.PI,
          B = $ / 4,
          q = 0,
          R = Math.sqrt,
          F = Math.cos,
          H = Math.sin,
          N = function (e) {
              return "string" == typeof e;
          },
          G = function (e) {
              return "function" == typeof e;
          },
          W = function (e) {
              return "number" == typeof e;
          },
          V = function (e) {
              return void 0 === e;
          },
          Y = function (e) {
              return "object" == typeof e;
          },
          X = function (e) {
              return !1 !== e;
          },
          j = function () {
              return "undefined" != typeof window;
          },
          U = function (e) {
              return G(e) || N(e);
          },
          K = ("function" == typeof ArrayBuffer && ArrayBuffer.isView) || function () {},
          Q = Array.isArray,
          Z = /(?:-?\.?\d|\.)+/gi,
          J = /[-+=.]*\d+[.e\-+]*\d*[e\-+]*\d*/g,
          ee = /[-+=.]*\d+[.e-]*\d*[a-z%]*/g,
          te = /[-+=.]*\d+\.?\d*(?:e-|e\+)?\d*/gi,
          ne = /[+-]=-?[.\d]+/,
          re = /[^,'"\[\]\s]+/gi,
          ie = /[\d.+\-=]+(?:e[-+]\d*)*/i,
          ae = {},
          se = {},
          oe = function (e) {
              return (se = ze(e, ae)) && gn;
          },
          le = function (e, t) {
              return console.warn("Invalid property", e, "set to", t, "Missing plugin? gsap.registerPlugin()");
          },
          de = function (e, t) {
              return !t && console.warn(e);
          },
          ue = function (e, t) {
              return (e && (ae[e] = t) && se && (se[e] = t)) || ae;
          },
          ce = function () {
              return 0;
          },
          pe = {},
          fe = [],
          he = {},
          me = {},
          ve = {},
          ge = 30,
          ye = [],
          we = "",
          be = function (e) {
              var t,
                  n,
                  r = e[0];
              if ((Y(r) || G(r) || (e = [e]), !(t = (r._gsap || {}).harness))) {
                  for (n = ye.length; n-- && !ye[n].targetTest(r); );
                  t = ye[n];
              }
              for (n = e.length; n--; ) (e[n] && (e[n]._gsap || (e[n]._gsap = new Ht(e[n], t)))) || e.splice(n, 1);
              return e;
          },
          Ee = function (e) {
              return e._gsap || be(ot(e))[0]._gsap;
          },
          xe = function (e, t, n) {
              return (n = e[t]) && G(n) ? e[t]() : (V(n) && e.getAttribute && e.getAttribute(t)) || n;
          },
          Se = function (e, t) {
              return (e = e.split(",")).forEach(t) || e;
          },
          Te = function (e) {
              return Math.round(1e5 * e) / 1e5 || 0;
          },
          _e = function (e, t) {
              for (var n = t.length, r = 0; e.indexOf(t[r]) < 0 && ++r < n; );
              return r < n;
          },
          Ce = function () {
              var e,
                  t,
                  n = fe.length,
                  r = fe.slice(0);
              for (he = {}, fe.length = 0, e = 0; e < n; e++) (t = r[e]) && t._lazy && (t.render(t._lazy[0], t._lazy[1], !0)._lazy = 0);
          },
          Me = function (e, t, n, r) {
              fe.length && Ce(), e.render(t, n, r), fe.length && Ce();
          },
          Pe = function (e) {
              var t = parseFloat(e);
              return (t || 0 === t) && (e + "").match(re).length < 2 ? t : N(e) ? e.trim() : e;
          },
          Le = function (e) {
              return e;
          },
          Ae = function (e, t) {
              for (var n in t) n in e || (e[n] = t[n]);
              return e;
          },
          ke = function (e, t) {
              for (var n in t) n in e || "duration" === n || "ease" === n || (e[n] = t[n]);
          },
          ze = function (e, t) {
              for (var n in t) e[n] = t[n];
              return e;
          },
          Ie = function e(t, n) {
              for (var r in n) "__proto__" !== r && "constructor" !== r && "prototype" !== r && (t[r] = Y(n[r]) ? e(t[r] || (t[r] = {}), n[r]) : n[r]);
              return t;
          },
          Oe = function (e, t) {
              var n,
                  r = {};
              for (n in e) n in t || (r[n] = e[n]);
              return r;
          },
          De = function (e) {
              var t = e.parent || s,
                  n = e.keyframes ? ke : Ae;
              if (X(e.inherit)) for (; t; ) n(e, t.vars.defaults), (t = t.parent || t._dp);
              return e;
          },
          $e = function (e, t, n, r) {
              void 0 === n && (n = "_first"), void 0 === r && (r = "_last");
              var i = t._prev,
                  a = t._next;
              i ? (i._next = a) : e[n] === t && (e[n] = a), a ? (a._prev = i) : e[r] === t && (e[r] = i), (t._next = t._prev = t.parent = null);
          },
          Be = function (e, t) {
              e.parent && (!t || e.parent.autoRemoveChildren) && e.parent.remove(e), (e._act = 0);
          },
          qe = function (e, t) {
              if (e && (!t || t._end > e._dur || t._start < 0)) for (var n = e; n; ) (n._dirty = 1), (n = n.parent);
              return e;
          },
          Re = function (e) {
              for (var t = e.parent; t && t.parent; ) (t._dirty = 1), t.totalDuration(), (t = t.parent);
              return e;
          },
          Fe = function (e) {
              return e._repeat ? He(e._tTime, (e = e.duration() + e._rDelay)) * e : 0;
          },
          He = function (e, t) {
              var n = Math.floor((e /= t));
              return e && n === e ? n - 1 : n;
          },
          Ne = function (e, t) {
              return (e - t._start) * t._ts + (t._ts >= 0 ? 0 : t._dirty ? t.totalDuration() : t._tDur);
          },
          Ge = function (e) {
              return (e._end = Te(e._start + (e._tDur / Math.abs(e._ts || e._rts || 1e-8) || 0)));
          },
          We = function (e, t) {
              var n = e._dp;
              return n && n.smoothChildTiming && e._ts && ((e._start = Te(n._time - (e._ts > 0 ? t / e._ts : ((e._dirty ? e.totalDuration() : e._tDur) - t) / -e._ts))), Ge(e), n._dirty || qe(n, e)), e;
          },
          Ve = function (e, t) {
              var n;
              if (((t._time || (t._initted && !t._dur)) && ((n = Ne(e.rawTime(), t)), (!t._dur || nt(0, t.totalDuration(), n) - t._tTime > 1e-8) && t.render(n, !0)), qe(e, t)._dp && e._initted && e._time >= e._dur && e._ts)) {
                  if (e._dur < e.duration()) for (n = e; n._dp; ) n.rawTime() >= 0 && n.totalTime(n._tTime), (n = n._dp);
                  e._zTime = -1e-8;
              }
          },
          Ye = function (e, t, n, r) {
              return (
                  t.parent && Be(t),
                  (t._start = Te((W(n) ? n : n || e !== s ? Je(e, n, t) : e._time) + t._delay)),
                  (t._end = Te(t._start + (t.totalDuration() / Math.abs(t.timeScale()) || 0))),
                  (function (e, t, n, r, i) {
                      void 0 === n && (n = "_first"), void 0 === r && (r = "_last");
                      var a,
                          s = e[r];
                      if (i) for (a = t[i]; s && s[i] > a; ) s = s._prev;
                      s ? ((t._next = s._next), (s._next = t)) : ((t._next = e[n]), (e[n] = t)), t._next ? (t._next._prev = t) : (e[r] = t), (t._prev = s), (t.parent = t._dp = e);
                  })(e, t, "_first", "_last", e._sort ? "_start" : 0),
                  Ue(t) || (e._recent = t),
                  r || Ve(e, t),
                  e
              );
          },
          Xe = function (e, t) {
              return (ae.ScrollTrigger || le("scrollTrigger", t)) && ae.ScrollTrigger.create(t, e);
          },
          je = function (e, t, n, r) {
              return jt(e, t), e._initted ? (!n && e._pt && ((e._dur && !1 !== e.vars.lazy) || (!e._dur && e.vars.lazy)) && c !== Pt.frame ? (fe.push(e), (e._lazy = [t, r]), 1) : void 0) : 1;
          },
          Ue = function (e) {
              var t = e.data;
              return "isFromStart" === t || "isStart" === t;
          },
          Ke = function (e, t, n, r) {
              var i = e._repeat,
                  a = Te(t) || 0,
                  s = e._tTime / e._tDur;
              return s && !r && (e._time *= a / e._dur), (e._dur = a), (e._tDur = i ? (i < 0 ? 1e10 : Te(a * (i + 1) + e._rDelay * i)) : a), s && !r ? We(e, (e._tTime = e._tDur * s)) : e.parent && Ge(e), n || qe(e.parent, e), e;
          },
          Qe = function (e) {
              return e instanceof Gt ? qe(e) : Ke(e, e._dur);
          },
          Ze = { _start: 0, endTime: ce, totalDuration: ce },
          Je = function e(t, n, r) {
              var i,
                  a,
                  s,
                  o = t.labels,
                  l = t._recent || Ze,
                  d = t.duration() >= D ? l.endTime(!1) : t._dur;
              return N(n) && (isNaN(n) || n in o)
                  ? ((a = n.charAt(0)),
                    (s = "%" === n.substr(-1)),
                    (i = n.indexOf("=")),
                    "<" === a || ">" === a
                        ? (i >= 0 && (n = n.replace(/=/, "")), ("<" === a ? l._start : l.endTime(l._repeat >= 0)) + (parseFloat(n.substr(1)) || 0) * (s ? (i < 0 ? l : r).totalDuration() / 100 : 1))
                        : i < 0
                        ? (n in o || (o[n] = d), o[n])
                        : ((a = parseFloat(n.charAt(i - 1) + n.substr(i + 1))), s && r && (a = (a / 100) * (Q(r) ? r[0] : r).totalDuration()), i > 1 ? e(t, n.substr(0, i - 1), r) + a : d + a))
                  : null == n
                  ? d
                  : +n;
          },
          et = function (e, t, n) {
              var r,
                  i,
                  a = W(t[1]),
                  s = (a ? 2 : 1) + (e < 2 ? 0 : 1),
                  o = t[s];
              if ((a && (o.duration = t[1]), (o.parent = n), e)) {
                  for (r = o, i = n; i && !("immediateRender" in r); ) (r = i.vars.defaults || {}), (i = X(i.vars.inherit) && i.parent);
                  (o.immediateRender = X(r.immediateRender)), e < 2 ? (o.runBackwards = 1) : (o.startAt = t[s - 1]);
              }
              return new Zt(t[0], o, t[s + 1]);
          },
          tt = function (e, t) {
              return e || 0 === e ? t(e) : t;
          },
          nt = function (e, t, n) {
              return n < e ? e : n > t ? t : n;
          },
          rt = function (e) {
              if ("string" != typeof e) return "";
              var t = ie.exec(e);
              return t ? e.substr(t.index + t[0].length) : "";
          },
          it = [].slice,
          at = function (e, t) {
              return e && Y(e) && "length" in e && ((!t && !e.length) || (e.length - 1 in e && Y(e[0]))) && !e.nodeType && e !== o;
          },
          st = function (e, t, n) {
              return (
                  void 0 === n && (n = []),
                  e.forEach(function (e) {
                      var r;
                      return (N(e) && !t) || at(e, 1) ? (r = n).push.apply(r, ot(e)) : n.push(e);
                  }) || n
              );
          },
          ot = function (e, t, n) {
              return !N(e) || n || (!l && Lt()) ? (Q(e) ? st(e, n) : at(e) ? it.call(e, 0) : e ? [e] : []) : it.call((t || d).querySelectorAll(e), 0);
          },
          lt = function (e) {
              return e.sort(function () {
                  return 0.5 - Math.random();
              });
          },
          dt = function (e) {
              if (G(e)) return e;
              var t = Y(e) ? e : { each: e },
                  n = $t(t.ease),
                  r = t.from || 0,
                  i = parseFloat(t.base) || 0,
                  a = {},
                  s = r > 0 && r < 1,
                  o = isNaN(r) || s,
                  l = t.axis,
                  d = r,
                  u = r;
              return (
                  N(r) ? (d = u = { center: 0.5, edges: 0.5, end: 1 }[r] || 0) : !s && o && ((d = r[0]), (u = r[1])),
                  function (e, s, c) {
                      var p,
                          f,
                          h,
                          m,
                          v,
                          g,
                          y,
                          w,
                          b,
                          E = (c || t).length,
                          x = a[E];
                      if (!x) {
                          if (!(b = "auto" === t.grid ? 0 : (t.grid || [1, D])[1])) {
                              for (y = -D; y < (y = c[b++].getBoundingClientRect().left) && b < E; );
                              b--;
                          }
                          for (x = a[E] = [], p = o ? Math.min(b, E) * d - 0.5 : r % b, f = o ? (E * u) / b - 0.5 : (r / b) | 0, y = 0, w = D, g = 0; g < E; g++)
                              (h = (g % b) - p), (m = f - ((g / b) | 0)), (x[g] = v = l ? Math.abs("y" === l ? m : h) : R(h * h + m * m)), v > y && (y = v), v < w && (w = v);
                          "random" === r && lt(x),
                              (x.max = y - w),
                              (x.min = w),
                              (x.v = E = (parseFloat(t.amount) || parseFloat(t.each) * (b > E ? E - 1 : l ? ("y" === l ? E / b : b) : Math.max(b, E / b)) || 0) * ("edges" === r ? -1 : 1)),
                              (x.b = E < 0 ? i - E : i),
                              (x.u = rt(t.amount || t.each) || 0),
                              (n = n && E < 0 ? Ot(n) : n);
                      }
                      return (E = (x[e] - x.min) / x.max || 0), Te(x.b + (n ? n(E) : E) * x.v) + x.u;
                  }
              );
          },
          ut = function (e) {
              var t = e < 1 ? Math.pow(10, (e + "").length - 2) : 1;
              return function (n) {
                  var r = Math.round(parseFloat(n) / e) * e * t;
                  return (r - (r % 1)) / t + (W(n) ? 0 : rt(n));
              };
          },
          ct = function (e, t) {
              var n,
                  r,
                  i = Q(e);
              return (
                  !i && Y(e) && ((n = i = e.radius || D), e.values ? ((e = ot(e.values)), (r = !W(e[0])) && (n *= n)) : (e = ut(e.increment))),
                  tt(
                      t,
                      i
                          ? G(e)
                              ? function (t) {
                                    return (r = e(t)), Math.abs(r - t) <= n ? r : t;
                                }
                              : function (t) {
                                    for (var i, a, s = parseFloat(r ? t.x : t), o = parseFloat(r ? t.y : 0), l = D, d = 0, u = e.length; u--; )
                                        (i = r ? (i = e[u].x - s) * i + (a = e[u].y - o) * a : Math.abs(e[u] - s)) < l && ((l = i), (d = u));
                                    return (d = !n || l <= n ? e[d] : t), r || d === t || W(t) ? d : d + rt(t);
                                }
                          : ut(e)
                  )
              );
          },
          pt = function (e, t, n, r) {
              return tt(Q(e) ? !t : !0 === n ? !!(n = 0) : !r, function () {
                  return Q(e) ? e[~~(Math.random() * e.length)] : (n = n || 1e-5) && (r = n < 1 ? Math.pow(10, (n + "").length - 2) : 1) && Math.floor(Math.round((e - n / 2 + Math.random() * (t - e + 0.99 * n)) / n) * n * r) / r;
              });
          },
          ft = function (e, t, n) {
              return tt(n, function (n) {
                  return e[~~t(n)];
              });
          },
          ht = function (e) {
              for (var t, n, r, i, a = 0, s = ""; ~(t = e.indexOf("random(", a)); )
                  (r = e.indexOf(")", t)), (i = "[" === e.charAt(t + 7)), (n = e.substr(t + 7, r - t - 7).match(i ? re : Z)), (s += e.substr(a, t - a) + pt(i ? n : +n[0], i ? 0 : +n[1], +n[2] || 1e-5)), (a = r + 1);
              return s + e.substr(a, e.length - a);
          },
          mt = function (e, t, n, r, i) {
              var a = t - e,
                  s = r - n;
              return tt(i, function (t) {
                  return n + (((t - e) / a) * s || 0);
              });
          },
          vt = function (e, t, n) {
              var r,
                  i,
                  a,
                  s = e.labels,
                  o = D;
              for (r in s) (i = s[r] - t) < 0 == !!n && i && o > (i = Math.abs(i)) && ((a = r), (o = i));
              return a;
          },
          gt = function (e, t, n) {
              var r,
                  i,
                  a = e.vars,
                  s = a[t];
              if (s) return (r = a[t + "Params"]), (i = a.callbackScope || e), n && fe.length && Ce(), r ? s.apply(i, r) : s.call(i);
          },
          yt = function (e) {
              return Be(e), e.scrollTrigger && e.scrollTrigger.kill(!1), e.progress() < 1 && gt(e, "onInterrupt"), e;
          },
          wt = function (e) {
              var t = (e = (!e.name && e.default) || e).name,
                  n = G(e),
                  r =
                      t && !n && e.init
                          ? function () {
                                this._props = [];
                            }
                          : e,
                  i = { init: ce, render: ln, add: Yt, kill: un, modifier: dn, rawVars: 0 },
                  a = { targetTest: 0, get: 0, getSetter: rn, aliases: {}, register: 0 };
              if ((Lt(), e !== r)) {
                  if (me[t]) return;
                  Ae(r, Ae(Oe(e, i), a)), ze(r.prototype, ze(i, Oe(e, a))), (me[(r.prop = t)] = r), e.targetTest && (ye.push(r), (pe[t] = 1)), (t = ("css" === t ? "CSS" : t.charAt(0).toUpperCase() + t.substr(1)) + "Plugin");
              }
              ue(t, r), e.register && e.register(gn, r, fn);
          },
          bt = {
              aqua: [0, 255, 255],
              lime: [0, 255, 0],
              silver: [192, 192, 192],
              black: [0, 0, 0],
              maroon: [128, 0, 0],
              teal: [0, 128, 128],
              blue: [0, 0, 255],
              navy: [0, 0, 128],
              white: [255, 255, 255],
              olive: [128, 128, 0],
              yellow: [255, 255, 0],
              orange: [255, 165, 0],
              gray: [128, 128, 128],
              purple: [128, 0, 128],
              green: [0, 128, 0],
              red: [255, 0, 0],
              pink: [255, 192, 203],
              cyan: [0, 255, 255],
              transparent: [255, 255, 255, 0],
          },
          Et = function (e, t, n) {
              return (255 * (6 * (e = e < 0 ? e + 1 : e > 1 ? e - 1 : e) < 1 ? t + (n - t) * e * 6 : e < 0.5 ? n : 3 * e < 2 ? t + (n - t) * (2 / 3 - e) * 6 : t) + 0.5) | 0;
          },
          xt = function (e, t, n) {
              var r,
                  i,
                  a,
                  s,
                  o,
                  l,
                  d,
                  u,
                  c,
                  p,
                  f = e ? (W(e) ? [e >> 16, (e >> 8) & 255, 255 & e] : 0) : bt.black;
              if (!f) {
                  if (("," === e.substr(-1) && (e = e.substr(0, e.length - 1)), bt[e])) f = bt[e];
                  else if ("#" === e.charAt(0)) {
                      if ((e.length < 6 && ((r = e.charAt(1)), (i = e.charAt(2)), (a = e.charAt(3)), (e = "#" + r + r + i + i + a + a + (5 === e.length ? e.charAt(4) + e.charAt(4) : ""))), 9 === e.length))
                          return [(f = parseInt(e.substr(1, 6), 16)) >> 16, (f >> 8) & 255, 255 & f, parseInt(e.substr(7), 16) / 255];
                      f = [(e = parseInt(e.substr(1), 16)) >> 16, (e >> 8) & 255, 255 & e];
                  } else if ("hsl" === e.substr(0, 3))
                      if (((f = p = e.match(Z)), t)) {
                          if (~e.indexOf("=")) return (f = e.match(J)), n && f.length < 4 && (f[3] = 1), f;
                      } else
                          (s = (+f[0] % 360) / 360),
                              (o = +f[1] / 100),
                              (r = 2 * (l = +f[2] / 100) - (i = l <= 0.5 ? l * (o + 1) : l + o - l * o)),
                              f.length > 3 && (f[3] *= 1),
                              (f[0] = Et(s + 1 / 3, r, i)),
                              (f[1] = Et(s, r, i)),
                              (f[2] = Et(s - 1 / 3, r, i));
                  else f = e.match(Z) || bt.transparent;
                  f = f.map(Number);
              }
              return (
                  t &&
                      !p &&
                      ((r = f[0] / 255),
                      (i = f[1] / 255),
                      (a = f[2] / 255),
                      (l = ((d = Math.max(r, i, a)) + (u = Math.min(r, i, a))) / 2),
                      d === u ? (s = o = 0) : ((c = d - u), (o = l > 0.5 ? c / (2 - d - u) : c / (d + u)), (s = d === r ? (i - a) / c + (i < a ? 6 : 0) : d === i ? (a - r) / c + 2 : (r - i) / c + 4), (s *= 60)),
                      (f[0] = ~~(s + 0.5)),
                      (f[1] = ~~(100 * o + 0.5)),
                      (f[2] = ~~(100 * l + 0.5))),
                  n && f.length < 4 && (f[3] = 1),
                  f
              );
          },
          St = function (e) {
              var t = [],
                  n = [],
                  r = -1;
              return (
                  e.split(_t).forEach(function (e) {
                      var i = e.match(ee) || [];
                      t.push.apply(t, i), n.push((r += i.length + 1));
                  }),
                  (t.c = n),
                  t
              );
          },
          Tt = function (e, t, n) {
              var r,
                  i,
                  a,
                  s,
                  o = "",
                  l = (e + o).match(_t),
                  d = t ? "hsla(" : "rgba(",
                  u = 0;
              if (!l) return e;
              if (
                  ((l = l.map(function (e) {
                      return (e = xt(e, t, 1)) && d + (t ? e[0] + "," + e[1] + "%," + e[2] + "%," + e[3] : e.join(",")) + ")";
                  })),
                  n && ((a = St(e)), (r = n.c).join(o) !== a.c.join(o)))
              )
                  for (s = (i = e.replace(_t, "1").split(ee)).length - 1; u < s; u++) o += i[u] + (~r.indexOf(u) ? l.shift() || d + "0,0,0,0)" : (a.length ? a : l.length ? l : n).shift());
              if (!i) for (s = (i = e.split(_t)).length - 1; u < s; u++) o += i[u] + l[u];
              return o + i[s];
          },
          _t = (function () {
              var e,
                  t = "(?:\\b(?:(?:rgb|rgba|hsl|hsla)\\(.+?\\))|\\B#(?:[0-9a-f]{3,4}){1,2}\\b";
              for (e in bt) t += "|" + e + "\\b";
              return new RegExp(t + ")", "gi");
          })(),
          Ct = /hsl[a]?\(/,
          Mt = function (e) {
              var t,
                  n = e.join(" ");
              if (((_t.lastIndex = 0), _t.test(n))) return (t = Ct.test(n)), (e[1] = Tt(e[1], t)), (e[0] = Tt(e[0], t, St(e[1]))), !0;
          },
          Pt =
              ((b = Date.now),
              (E = 500),
              (x = 33),
              (S = b()),
              (T = S),
              (C = _ = 1e3 / 240),
              (P = function e(t) {
                  var n,
                      r,
                      i,
                      a,
                      s = b() - T,
                      o = !0 === t;
                  if ((s > E && (S += s - x), ((n = (i = (T += s) - S) - C) > 0 || o) && ((a = ++g.frame), (y = i - 1e3 * g.time), (g.time = i /= 1e3), (C += n + (n >= _ ? 4 : _ - n)), (r = 1)), o || (h = m(e)), r))
                      for (w = 0; w < M.length; w++) M[w](i, y, a, t);
              }),
              (g = {
                  time: 0,
                  frame: 0,
                  tick: function () {
                      P(!0);
                  },
                  deltaRatio: function (e) {
                      return y / (1e3 / (e || 60));
                  },
                  wake: function () {
                      u &&
                          (!l &&
                              j() &&
                              ((o = l = window), (d = o.document || {}), (ae.gsap = gn), (o.gsapVersions || (o.gsapVersions = [])).push(gn.version), oe(se || o.GreenSockGlobals || (!o.gsap && o) || {}), (v = o.requestAnimationFrame)),
                          h && g.sleep(),
                          (m =
                              v ||
                              function (e) {
                                  return setTimeout(e, (C - 1e3 * g.time + 1) | 0);
                              }),
                          (f = 1),
                          P(2));
                  },
                  sleep: function () {
                      (v ? o.cancelAnimationFrame : clearTimeout)(h), (f = 0), (m = ce);
                  },
                  lagSmoothing: function (e, t) {
                      (E = e || 1 / 1e-8), (x = Math.min(t, E, 0));
                  },
                  fps: function (e) {
                      (_ = 1e3 / (e || 240)), (C = 1e3 * g.time + _);
                  },
                  add: function (e) {
                      M.indexOf(e) < 0 && M.push(e), Lt();
                  },
                  remove: function (e) {
                      var t;
                      ~(t = M.indexOf(e)) && M.splice(t, 1) && w >= t && w--;
                  },
                  _listeners: (M = []),
              })),
          Lt = function () {
              return !f && Pt.wake();
          },
          At = {},
          kt = /^[\d.\-M][\d.\-,\s]/,
          zt = /["']/g,
          It = function (e) {
              for (var t, n, r, i = {}, a = e.substr(1, e.length - 3).split(":"), s = a[0], o = 1, l = a.length; o < l; o++)
                  (n = a[o]), (t = o !== l - 1 ? n.lastIndexOf(",") : n.length), (r = n.substr(0, t)), (i[s] = isNaN(r) ? r.replace(zt, "").trim() : +r), (s = n.substr(t + 1).trim());
              return i;
          },
          Ot = function (e) {
              return function (t) {
                  return 1 - e(1 - t);
              };
          },
          Dt = function e(t, n) {
              for (var r, i = t._first; i; )
                  i instanceof Gt ? e(i, n) : !i.vars.yoyoEase || (i._yoyo && i._repeat) || i._yoyo === n || (i.timeline ? e(i.timeline, n) : ((r = i._ease), (i._ease = i._yEase), (i._yEase = r), (i._yoyo = n))), (i = i._next);
          },
          $t = function (e, t) {
              return (
                  (e &&
                      (G(e)
                          ? e
                          : At[e] ||
                            (function (e) {
                                var t,
                                    n,
                                    r,
                                    i,
                                    a = (e + "").split("("),
                                    s = At[a[0]];
                                return s && a.length > 1 && s.config
                                    ? s.config.apply(
                                          null,
                                          ~e.indexOf("{") ? [It(a[1])] : ((t = e), (n = t.indexOf("(") + 1), (r = t.indexOf(")")), (i = t.indexOf("(", n)), t.substring(n, ~i && i < r ? t.indexOf(")", r + 1) : r)).split(",").map(Pe)
                                      )
                                    : At._CE && kt.test(e)
                                    ? At._CE("", e)
                                    : s;
                            })(e))) ||
                  t
              );
          },
          Bt = function (e, t, n, r) {
              void 0 === n &&
                  (n = function (e) {
                      return 1 - t(1 - e);
                  }),
                  void 0 === r &&
                      (r = function (e) {
                          return e < 0.5 ? t(2 * e) / 2 : 1 - t(2 * (1 - e)) / 2;
                      });
              var i,
                  a = { easeIn: t, easeOut: n, easeInOut: r };
              return (
                  Se(e, function (e) {
                      for (var t in ((At[e] = ae[e] = a), (At[(i = e.toLowerCase())] = n), a)) At[i + ("easeIn" === t ? ".in" : "easeOut" === t ? ".out" : ".inOut")] = At[e + "." + t] = a[t];
                  }),
                  a
              );
          },
          qt = function (e) {
              return function (t) {
                  return t < 0.5 ? (1 - e(1 - 2 * t)) / 2 : 0.5 + e(2 * (t - 0.5)) / 2;
              };
          },
          Rt = function e(t, n, r) {
              var i = n >= 1 ? n : 1,
                  a = (r || (t ? 0.3 : 0.45)) / (n < 1 ? n : 1),
                  s = (a / $) * (Math.asin(1 / i) || 0),
                  o = function (e) {
                      return 1 === e ? 1 : i * Math.pow(2, -10 * e) * H((e - s) * a) + 1;
                  },
                  l =
                      "out" === t
                          ? o
                          : "in" === t
                          ? function (e) {
                                return 1 - o(1 - e);
                            }
                          : qt(o);
              return (
                  (a = $ / a),
                  (l.config = function (n, r) {
                      return e(t, n, r);
                  }),
                  l
              );
          },
          Ft = function e(t, n) {
              void 0 === n && (n = 1.70158);
              var r = function (e) {
                      return e ? --e * e * ((n + 1) * e + n) + 1 : 0;
                  },
                  i =
                      "out" === t
                          ? r
                          : "in" === t
                          ? function (e) {
                                return 1 - r(1 - e);
                            }
                          : qt(r);
              return (
                  (i.config = function (n) {
                      return e(t, n);
                  }),
                  i
              );
          };
      Se("Linear,Quad,Cubic,Quart,Quint,Strong", function (e, t) {
          var n = t < 5 ? t + 1 : t;
          Bt(
              e + ",Power" + (n - 1),
              t
                  ? function (e) {
                        return Math.pow(e, n);
                    }
                  : function (e) {
                        return e;
                    },
              function (e) {
                  return 1 - Math.pow(1 - e, n);
              },
              function (e) {
                  return e < 0.5 ? Math.pow(2 * e, n) / 2 : 1 - Math.pow(2 * (1 - e), n) / 2;
              }
          );
      }),
          (At.Linear.easeNone = At.none = At.Linear.easeIn),
          Bt("Elastic", Rt("in"), Rt("out"), Rt()),
          (L = 7.5625),
          (k = 1 / (A = 2.75)),
          Bt(
              "Bounce",
              function (e) {
                  return 1 - z(1 - e);
              },
              (z = function (e) {
                  return e < k ? L * e * e : e < 0.7272727272727273 ? L * Math.pow(e - 1.5 / A, 2) + 0.75 : e < 0.9090909090909092 ? L * (e -= 2.25 / A) * e + 0.9375 : L * Math.pow(e - 2.625 / A, 2) + 0.984375;
              })
          ),
          Bt("Expo", function (e) {
              return e ? Math.pow(2, 10 * (e - 1)) : 0;
          }),
          Bt("Circ", function (e) {
              return -(R(1 - e * e) - 1);
          }),
          Bt("Sine", function (e) {
              return 1 === e ? 1 : 1 - F(e * B);
          }),
          Bt("Back", Ft("in"), Ft("out"), Ft()),
          (At.SteppedEase = At.steps = ae.SteppedEase = {
              config: function (e, t) {
                  void 0 === e && (e = 1);
                  var n = 1 / e,
                      r = e + (t ? 0 : 1),
                      i = t ? 1 : 0;
                  return function (e) {
                      return (((r * nt(0, 1 - 1e-8, e)) | 0) + i) * n;
                  };
              },
          }),
          (O.ease = At["quad.out"]),
          Se("onComplete,onUpdate,onStart,onRepeat,onReverseComplete,onInterrupt", function (e) {
              return (we += e + "," + e + "Params,");
          });
      var Ht = function (e, t) {
              (this.id = q++), (e._gsap = this), (this.target = e), (this.harness = t), (this.get = t ? t.get : xe), (this.set = t ? t.getSetter : rn);
          },
          Nt = (function () {
              function e(e) {
                  (this.vars = e),
                      (this._delay = +e.delay || 0),
                      (this._repeat = e.repeat === 1 / 0 ? -2 : e.repeat || 0) && ((this._rDelay = e.repeatDelay || 0), (this._yoyo = !!e.yoyo || !!e.yoyoEase)),
                      (this._ts = 1),
                      Ke(this, +e.duration, 1, 1),
                      (this.data = e.data),
                      f || Pt.wake();
              }
              var t = e.prototype;
              return (
                  (t.delay = function (e) {
                      return e || 0 === e ? (this.parent && this.parent.smoothChildTiming && this.startTime(this._start + e - this._delay), (this._delay = e), this) : this._delay;
                  }),
                  (t.duration = function (e) {
                      return arguments.length ? this.totalDuration(this._repeat > 0 ? e + (e + this._rDelay) * this._repeat : e) : this.totalDuration() && this._dur;
                  }),
                  (t.totalDuration = function (e) {
                      return arguments.length ? ((this._dirty = 0), Ke(this, this._repeat < 0 ? e : (e - this._repeat * this._rDelay) / (this._repeat + 1))) : this._tDur;
                  }),
                  (t.totalTime = function (e, t) {
                      if ((Lt(), !arguments.length)) return this._tTime;
                      var n = this._dp;
                      if (n && n.smoothChildTiming && this._ts) {
                          for (We(this, e), !n._dp || n.parent || Ve(n, this); n.parent; )
                              n.parent._time !== n._start + (n._ts >= 0 ? n._tTime / n._ts : (n.totalDuration() - n._tTime) / -n._ts) && n.totalTime(n._tTime, !0), (n = n.parent);
                          !this.parent && this._dp.autoRemoveChildren && ((this._ts > 0 && e < this._tDur) || (this._ts < 0 && e > 0) || (!this._tDur && !e)) && Ye(this._dp, this, this._start - this._delay);
                      }
                      return (
                          (this._tTime !== e || (!this._dur && !t) || (this._initted && 1e-8 === Math.abs(this._zTime)) || (!e && !this._initted && (this.add || this._ptLookup))) && (this._ts || (this._pTime = e), Me(this, e, t)), this
                      );
                  }),
                  (t.time = function (e, t) {
                      return arguments.length ? this.totalTime(Math.min(this.totalDuration(), e + Fe(this)) % (this._dur + this._rDelay) || (e ? this._dur : 0), t) : this._time;
                  }),
                  (t.totalProgress = function (e, t) {
                      return arguments.length ? this.totalTime(this.totalDuration() * e, t) : this.totalDuration() ? Math.min(1, this._tTime / this._tDur) : this.ratio;
                  }),
                  (t.progress = function (e, t) {
                      return arguments.length ? this.totalTime(this.duration() * (!this._yoyo || 1 & this.iteration() ? e : 1 - e) + Fe(this), t) : this.duration() ? Math.min(1, this._time / this._dur) : this.ratio;
                  }),
                  (t.iteration = function (e, t) {
                      var n = this.duration() + this._rDelay;
                      return arguments.length ? this.totalTime(this._time + (e - 1) * n, t) : this._repeat ? He(this._tTime, n) + 1 : 1;
                  }),
                  (t.timeScale = function (e) {
                      if (!arguments.length) return -1e-8 === this._rts ? 0 : this._rts;
                      if (this._rts === e) return this;
                      var t = this.parent && this._ts ? Ne(this.parent._time, this) : this._tTime;
                      return (this._rts = +e || 0), (this._ts = this._ps || -1e-8 === e ? 0 : this._rts), Re(this.totalTime(nt(-this._delay, this._tDur, t), !0));
                  }),
                  (t.paused = function (e) {
                      return arguments.length
                          ? (this._ps !== e &&
                                ((this._ps = e),
                                e
                                    ? ((this._pTime = this._tTime || Math.max(-this._delay, this.rawTime())), (this._ts = this._act = 0))
                                    : (Lt(),
                                      (this._ts = this._rts),
                                      this.totalTime(this.parent && !this.parent.smoothChildTiming ? this.rawTime() : this._tTime || this._pTime, 1 === this.progress() && 1e-8 !== Math.abs(this._zTime) && (this._tTime -= 1e-8)))),
                            this)
                          : this._ps;
                  }),
                  (t.startTime = function (e) {
                      if (arguments.length) {
                          this._start = e;
                          var t = this.parent || this._dp;
                          return t && (t._sort || !this.parent) && Ye(t, this, e - this._delay), this;
                      }
                      return this._start;
                  }),
                  (t.endTime = function (e) {
                      return this._start + (X(e) ? this.totalDuration() : this.duration()) / Math.abs(this._ts);
                  }),
                  (t.rawTime = function (e) {
                      var t = this.parent || this._dp;
                      return t ? (e && (!this._ts || (this._repeat && this._time && this.totalProgress() < 1)) ? this._tTime % (this._dur + this._rDelay) : this._ts ? Ne(t.rawTime(e), this) : this._tTime) : this._tTime;
                  }),
                  (t.globalTime = function (e) {
                      for (var t = this, n = arguments.length ? e : t.rawTime(); t; ) (n = t._start + n / (t._ts || 1)), (t = t._dp);
                      return n;
                  }),
                  (t.repeat = function (e) {
                      return arguments.length ? ((this._repeat = e === 1 / 0 ? -2 : e), Qe(this)) : -2 === this._repeat ? 1 / 0 : this._repeat;
                  }),
                  (t.repeatDelay = function (e) {
                      if (arguments.length) {
                          var t = this._time;
                          return (this._rDelay = e), Qe(this), t ? this.time(t) : this;
                      }
                      return this._rDelay;
                  }),
                  (t.yoyo = function (e) {
                      return arguments.length ? ((this._yoyo = e), this) : this._yoyo;
                  }),
                  (t.seek = function (e, t) {
                      return this.totalTime(Je(this, e), X(t));
                  }),
                  (t.restart = function (e, t) {
                      return this.play().totalTime(e ? -this._delay : 0, X(t));
                  }),
                  (t.play = function (e, t) {
                      return null != e && this.seek(e, t), this.reversed(!1).paused(!1);
                  }),
                  (t.reverse = function (e, t) {
                      return null != e && this.seek(e || this.totalDuration(), t), this.reversed(!0).paused(!1);
                  }),
                  (t.pause = function (e, t) {
                      return null != e && this.seek(e, t), this.paused(!0);
                  }),
                  (t.resume = function () {
                      return this.paused(!1);
                  }),
                  (t.reversed = function (e) {
                      return arguments.length ? (!!e !== this.reversed() && this.timeScale(-this._rts || (e ? -1e-8 : 0)), this) : this._rts < 0;
                  }),
                  (t.invalidate = function () {
                      return (this._initted = this._act = 0), (this._zTime = -1e-8), this;
                  }),
                  (t.isActive = function () {
                      var e,
                          t = this.parent || this._dp,
                          n = this._start;
                      return !(t && !(this._ts && this._initted && t.isActive() && (e = t.rawTime(!0)) >= n && e < this.endTime(!0) - 1e-8));
                  }),
                  (t.eventCallback = function (e, t, n) {
                      var r = this.vars;
                      return arguments.length > 1 ? (t ? ((r[e] = t), n && (r[e + "Params"] = n), "onUpdate" === e && (this._onUpdate = t)) : delete r[e], this) : r[e];
                  }),
                  (t.then = function (e) {
                      var t = this;
                      return new Promise(function (n) {
                          var r = G(e) ? e : Le,
                              i = function () {
                                  var e = t.then;
                                  (t.then = null), G(r) && (r = r(t)) && (r.then || r === t) && (t.then = e), n(r), (t.then = e);
                              };
                          (t._initted && 1 === t.totalProgress() && t._ts >= 0) || (!t._tTime && t._ts < 0) ? i() : (t._prom = i);
                      });
                  }),
                  (t.kill = function () {
                      yt(this);
                  }),
                  e
              );
          })();
      Ae(Nt.prototype, { _time: 0, _start: 0, _end: 0, _tTime: 0, _tDur: 0, _dirty: 0, _repeat: 0, _yoyo: !1, parent: null, _initted: !1, _rDelay: 0, _ts: 1, _dp: 0, ratio: 0, _zTime: -1e-8, _prom: 0, _ps: !1, _rts: 1 });
      var Gt = (function (e) {
          function t(t, n) {
              var i;
              return (
                  void 0 === t && (t = {}),
                  ((i = e.call(this, t) || this).labels = {}),
                  (i.smoothChildTiming = !!t.smoothChildTiming),
                  (i.autoRemoveChildren = !!t.autoRemoveChildren),
                  (i._sort = X(t.sortChildren)),
                  s && Ye(t.parent || s, r(i), n),
                  t.reversed && i.reverse(),
                  t.paused && i.paused(!0),
                  t.scrollTrigger && Xe(r(i), t.scrollTrigger),
                  i
              );
          }
          i(t, e);
          var n = t.prototype;
          return (
              (n.to = function (e, t, n) {
                  return et(0, arguments, this), this;
              }),
              (n.from = function (e, t, n) {
                  return et(1, arguments, this), this;
              }),
              (n.fromTo = function (e, t, n, r) {
                  return et(2, arguments, this), this;
              }),
              (n.set = function (e, t, n) {
                  return (t.duration = 0), (t.parent = this), De(t).repeatDelay || (t.repeat = 0), (t.immediateRender = !!t.immediateRender), new Zt(e, t, Je(this, n), 1), this;
              }),
              (n.call = function (e, t, n) {
                  return Ye(this, Zt.delayedCall(0, e, t), n);
              }),
              (n.staggerTo = function (e, t, n, r, i, a, s) {
                  return (n.duration = t), (n.stagger = n.stagger || r), (n.onComplete = a), (n.onCompleteParams = s), (n.parent = this), new Zt(e, n, Je(this, i)), this;
              }),
              (n.staggerFrom = function (e, t, n, r, i, a, s) {
                  return (n.runBackwards = 1), (De(n).immediateRender = X(n.immediateRender)), this.staggerTo(e, t, n, r, i, a, s);
              }),
              (n.staggerFromTo = function (e, t, n, r, i, a, s, o) {
                  return (r.startAt = n), (De(r).immediateRender = X(r.immediateRender)), this.staggerTo(e, t, r, i, a, s, o);
              }),
              (n.render = function (e, t, n) {
                  var r,
                      i,
                      a,
                      o,
                      l,
                      d,
                      u,
                      c,
                      p,
                      f,
                      h,
                      m,
                      v = this._time,
                      g = this._dirty ? this.totalDuration() : this._tDur,
                      y = this._dur,
                      w = this !== s && e > g - 1e-8 && e >= 0 ? g : e < 1e-8 ? 0 : e,
                      b = this._zTime < 0 != e < 0 && (this._initted || !y);
                  if (w !== this._tTime || n || b) {
                      if ((v !== this._time && y && ((w += this._time - v), (e += this._time - v)), (r = w), (p = this._start), (d = !(c = this._ts)), b && (y || (v = this._zTime), (e || !t) && (this._zTime = e)), this._repeat)) {
                          if (((h = this._yoyo), (l = y + this._rDelay), this._repeat < -1 && e < 0)) return this.totalTime(100 * l + e, t, n);
                          if (
                              ((r = Te(w % l)),
                              w === g ? ((o = this._repeat), (r = y)) : ((o = ~~(w / l)) && o === w / l && ((r = y), o--), r > y && (r = y)),
                              (f = He(this._tTime, l)),
                              !v && this._tTime && f !== o && (f = o),
                              h && 1 & o && ((r = y - r), (m = 1)),
                              o !== f && !this._lock)
                          ) {
                              var E = h && 1 & f,
                                  x = E === (h && 1 & o);
                              if (
                                  (o < f && (E = !E),
                                  (v = E ? 0 : y),
                                  (this._lock = 1),
                                  (this.render(v || (m ? 0 : Te(o * l)), t, !y)._lock = 0),
                                  (this._tTime = w),
                                  !t && this.parent && gt(this, "onRepeat"),
                                  this.vars.repeatRefresh && !m && (this.invalidate()._lock = 1),
                                  (v && v !== this._time) || d !== !this._ts || (this.vars.onRepeat && !this.parent && !this._act))
                              )
                                  return this;
                              if (((y = this._dur), (g = this._tDur), x && ((this._lock = 2), (v = E ? y : -1e-4), this.render(v, !0), this.vars.repeatRefresh && !m && this.invalidate()), (this._lock = 0), !this._ts && !d)) return this;
                              Dt(this, m);
                          }
                      }
                      if (
                          (this._hasPause &&
                              !this._forcing &&
                              this._lock < 2 &&
                              (u = (function (e, t, n) {
                                  var r;
                                  if (n > t)
                                      for (r = e._first; r && r._start <= n; ) {
                                          if (!r._dur && "isPause" === r.data && r._start > t) return r;
                                          r = r._next;
                                      }
                                  else
                                      for (r = e._last; r && r._start >= n; ) {
                                          if (!r._dur && "isPause" === r.data && r._start < t) return r;
                                          r = r._prev;
                                      }
                              })(this, Te(v), Te(r))) &&
                              (w -= r - (r = u._start)),
                          (this._tTime = w),
                          (this._time = r),
                          (this._act = !c),
                          this._initted || ((this._onUpdate = this.vars.onUpdate), (this._initted = 1), (this._zTime = e), (v = 0)),
                          !v && r && !t && (gt(this, "onStart"), this._tTime !== w))
                      )
                          return this;
                      if (r >= v && e >= 0)
                          for (i = this._first; i; ) {
                              if (((a = i._next), (i._act || r >= i._start) && i._ts && u !== i)) {
                                  if (i.parent !== this) return this.render(e, t, n);
                                  if ((i.render(i._ts > 0 ? (r - i._start) * i._ts : (i._dirty ? i.totalDuration() : i._tDur) + (r - i._start) * i._ts, t, n), r !== this._time || (!this._ts && !d))) {
                                      (u = 0), a && (w += this._zTime = -1e-8);
                                      break;
                                  }
                              }
                              i = a;
                          }
                      else {
                          i = this._last;
                          for (var S = e < 0 ? e : r; i; ) {
                              if (((a = i._prev), (i._act || S <= i._end) && i._ts && u !== i)) {
                                  if (i.parent !== this) return this.render(e, t, n);
                                  if ((i.render(i._ts > 0 ? (S - i._start) * i._ts : (i._dirty ? i.totalDuration() : i._tDur) + (S - i._start) * i._ts, t, n), r !== this._time || (!this._ts && !d))) {
                                      (u = 0), a && (w += this._zTime = S ? -1e-8 : 1e-8);
                                      break;
                                  }
                              }
                              i = a;
                          }
                      }
                      if (u && !t && (this.pause(), (u.render(r >= v ? 0 : -1e-8)._zTime = r >= v ? 1 : -1), this._ts)) return (this._start = p), Ge(this), this.render(e, t, n);
                      this._onUpdate && !t && gt(this, "onUpdate", !0),
                          ((w === g && g >= this.totalDuration()) || (!w && v)) &&
                              ((p !== this._start && Math.abs(c) === Math.abs(this._ts)) ||
                                  this._lock ||
                                  ((e || !y) && ((w === g && this._ts > 0) || (!w && this._ts < 0)) && Be(this, 1),
                                  t || (e < 0 && !v) || (!w && !v && g) || (gt(this, w === g && e >= 0 ? "onComplete" : "onReverseComplete", !0), this._prom && !(w < g && this.timeScale() > 0) && this._prom())));
                  }
                  return this;
              }),
              (n.add = function (e, t) {
                  var n = this;
                  if ((W(t) || (t = Je(this, t, e)), !(e instanceof Nt))) {
                      if (Q(e))
                          return (
                              e.forEach(function (e) {
                                  return n.add(e, t);
                              }),
                              this
                          );
                      if (N(e)) return this.addLabel(e, t);
                      if (!G(e)) return this;
                      e = Zt.delayedCall(0, e);
                  }
                  return this !== e ? Ye(this, e, t) : this;
              }),
              (n.getChildren = function (e, t, n, r) {
                  void 0 === e && (e = !0), void 0 === t && (t = !0), void 0 === n && (n = !0), void 0 === r && (r = -D);
                  for (var i = [], a = this._first; a; ) a._start >= r && (a instanceof Zt ? t && i.push(a) : (n && i.push(a), e && i.push.apply(i, a.getChildren(!0, t, n)))), (a = a._next);
                  return i;
              }),
              (n.getById = function (e) {
                  for (var t = this.getChildren(1, 1, 1), n = t.length; n--; ) if (t[n].vars.id === e) return t[n];
              }),
              (n.remove = function (e) {
                  return N(e) ? this.removeLabel(e) : G(e) ? this.killTweensOf(e) : ($e(this, e), e === this._recent && (this._recent = this._last), qe(this));
              }),
              (n.totalTime = function (t, n) {
                  return arguments.length
                      ? ((this._forcing = 1),
                        !this._dp && this._ts && (this._start = Te(Pt.time - (this._ts > 0 ? t / this._ts : (this.totalDuration() - t) / -this._ts))),
                        e.prototype.totalTime.call(this, t, n),
                        (this._forcing = 0),
                        this)
                      : this._tTime;
              }),
              (n.addLabel = function (e, t) {
                  return (this.labels[e] = Je(this, t)), this;
              }),
              (n.removeLabel = function (e) {
                  return delete this.labels[e], this;
              }),
              (n.addPause = function (e, t, n) {
                  var r = Zt.delayedCall(0, t || ce, n);
                  return (r.data = "isPause"), (this._hasPause = 1), Ye(this, r, Je(this, e));
              }),
              (n.removePause = function (e) {
                  var t = this._first;
                  for (e = Je(this, e); t; ) t._start === e && "isPause" === t.data && Be(t), (t = t._next);
              }),
              (n.killTweensOf = function (e, t, n) {
                  for (var r = this.getTweensOf(e, n), i = r.length; i--; ) Wt !== r[i] && r[i].kill(e, t);
                  return this;
              }),
              (n.getTweensOf = function (e, t) {
                  for (var n, r = [], i = ot(e), a = this._first, s = W(t); a; )
                      a instanceof Zt
                          ? _e(a._targets, i) && (s ? (!Wt || (a._initted && a._ts)) && a.globalTime(0) <= t && a.globalTime(a.totalDuration()) > t : !t || a.isActive()) && r.push(a)
                          : (n = a.getTweensOf(i, t)).length && r.push.apply(r, n),
                          (a = a._next);
                  return r;
              }),
              (n.tweenTo = function (e, t) {
                  t = t || {};
                  var n,
                      r = this,
                      i = Je(r, e),
                      a = t,
                      s = a.startAt,
                      o = a.onStart,
                      l = a.onStartParams,
                      d = a.immediateRender,
                      u = Zt.to(
                          r,
                          Ae(
                              {
                                  ease: t.ease || "none",
                                  lazy: !1,
                                  immediateRender: !1,
                                  time: i,
                                  overwrite: "auto",
                                  duration: t.duration || Math.abs((i - (s && "time" in s ? s.time : r._time)) / r.timeScale()) || 1e-8,
                                  onStart: function () {
                                      if ((r.pause(), !n)) {
                                          var e = t.duration || Math.abs((i - (s && "time" in s ? s.time : r._time)) / r.timeScale());
                                          u._dur !== e && Ke(u, e, 0, 1).render(u._time, !0, !0), (n = 1);
                                      }
                                      o && o.apply(u, l || []);
                                  },
                              },
                              t
                          )
                      );
                  return d ? u.render(0) : u;
              }),
              (n.tweenFromTo = function (e, t, n) {
                  return this.tweenTo(t, Ae({ startAt: { time: Je(this, e) } }, n));
              }),
              (n.recent = function () {
                  return this._recent;
              }),
              (n.nextLabel = function (e) {
                  return void 0 === e && (e = this._time), vt(this, Je(this, e));
              }),
              (n.previousLabel = function (e) {
                  return void 0 === e && (e = this._time), vt(this, Je(this, e), 1);
              }),
              (n.currentLabel = function (e) {
                  return arguments.length ? this.seek(e, !0) : this.previousLabel(this._time + 1e-8);
              }),
              (n.shiftChildren = function (e, t, n) {
                  void 0 === n && (n = 0);
                  for (var r, i = this._first, a = this.labels; i; ) i._start >= n && ((i._start += e), (i._end += e)), (i = i._next);
                  if (t) for (r in a) a[r] >= n && (a[r] += e);
                  return qe(this);
              }),
              (n.invalidate = function () {
                  var t = this._first;
                  for (this._lock = 0; t; ) t.invalidate(), (t = t._next);
                  return e.prototype.invalidate.call(this);
              }),
              (n.clear = function (e) {
                  void 0 === e && (e = !0);
                  for (var t, n = this._first; n; ) (t = n._next), this.remove(n), (n = t);
                  return this._dp && (this._time = this._tTime = this._pTime = 0), e && (this.labels = {}), qe(this);
              }),
              (n.totalDuration = function (e) {
                  var t,
                      n,
                      r,
                      i = 0,
                      a = this,
                      o = a._last,
                      l = D;
                  if (arguments.length) return a.timeScale((a._repeat < 0 ? a.duration() : a.totalDuration()) / (a.reversed() ? -e : e));
                  if (a._dirty) {
                      for (r = a.parent; o; )
                          (t = o._prev),
                              o._dirty && o.totalDuration(),
                              (n = o._start) > l && a._sort && o._ts && !a._lock ? ((a._lock = 1), (Ye(a, o, n - o._delay, 1)._lock = 0)) : (l = n),
                              n < 0 && o._ts && ((i -= n), ((!r && !a._dp) || (r && r.smoothChildTiming)) && ((a._start += n / a._ts), (a._time -= n), (a._tTime -= n)), a.shiftChildren(-n, !1, -Infinity), (l = 0)),
                              o._end > i && o._ts && (i = o._end),
                              (o = t);
                      Ke(a, a === s && a._time > i ? a._time : i, 1, 1), (a._dirty = 0);
                  }
                  return a._tDur;
              }),
              (t.updateRoot = function (e) {
                  if ((s._ts && (Me(s, Ne(e, s)), (c = Pt.frame)), Pt.frame >= ge)) {
                      ge += I.autoSleep || 120;
                      var t = s._first;
                      if ((!t || !t._ts) && I.autoSleep && Pt._listeners.length < 2) {
                          for (; t && !t._ts; ) t = t._next;
                          t || Pt.sleep();
                      }
                  }
              }),
              t
          );
      })(Nt);
      Ae(Gt.prototype, { _lock: 0, _hasPause: 0, _forcing: 0 });
      var Wt,
          Vt = function (e, t, n, r, i, a, s) {
              var o,
                  l,
                  d,
                  u,
                  c,
                  p,
                  f,
                  h,
                  m = new fn(this._pt, e, t, 0, 1, on, null, i),
                  v = 0,
                  g = 0;
              for (m.b = n, m.e = r, n += "", (f = ~(r += "").indexOf("random(")) && (r = ht(r)), a && (a((h = [n, r]), e, t), (n = h[0]), (r = h[1])), l = n.match(te) || []; (o = te.exec(r)); )
                  (u = o[0]),
                      (c = r.substring(v, o.index)),
                      d ? (d = (d + 1) % 5) : "rgba(" === c.substr(-5) && (d = 1),
                      u !== l[g++] &&
                          ((p = parseFloat(l[g - 1]) || 0),
                          (m._pt = { _next: m._pt, p: c || 1 === g ? c : ",", s: p, c: "=" === u.charAt(1) ? parseFloat(u.substr(2)) * ("-" === u.charAt(0) ? -1 : 1) : parseFloat(u) - p, m: d && d < 4 ? Math.round : 0 }),
                          (v = te.lastIndex));
              return (m.c = v < r.length ? r.substring(v, r.length) : ""), (m.fp = s), (ne.test(r) || f) && (m.e = 0), (this._pt = m), m;
          },
          Yt = function (e, t, n, r, i, a, s, o, l) {
              G(r) && (r = r(i || 0, e, a));
              var d,
                  u = e[t],
                  c = "get" !== n ? n : G(u) ? (l ? e[t.indexOf("set") || !G(e["get" + t.substr(3)]) ? t : "get" + t.substr(3)](l) : e[t]()) : u,
                  p = G(u) ? (l ? tn : en) : Jt;
              if ((N(r) && (~r.indexOf("random(") && (r = ht(r)), "=" === r.charAt(1) && ((d = parseFloat(c) + parseFloat(r.substr(2)) * ("-" === r.charAt(0) ? -1 : 1) + (rt(c) || 0)) || 0 === d) && (r = d)), c !== r))
                  return isNaN(c * r) || "" === r
                      ? (!u && !(t in e) && le(t, r), Vt.call(this, e, t, c, r, p, o || I.stringFilter, l))
                      : ((d = new fn(this._pt, e, t, +c || 0, r - (c || 0), "boolean" == typeof u ? sn : an, 0, p)), l && (d.fp = l), s && d.modifier(s, this, e), (this._pt = d));
          },
          Xt = function (e, t, n, r, i, a) {
              var s, o, l, d;
              if (
                  me[e] &&
                  !1 !==
                      (s = new me[e]()).init(
                          i,
                          s.rawVars
                              ? t[e]
                              : (function (e, t, n, r, i) {
                                    if ((G(e) && (e = Ut(e, i, t, n, r)), !Y(e) || (e.style && e.nodeType) || Q(e) || K(e))) return N(e) ? Ut(e, i, t, n, r) : e;
                                    var a,
                                        s = {};
                                    for (a in e) s[a] = Ut(e[a], i, t, n, r);
                                    return s;
                                })(t[e], r, i, a, n),
                          n,
                          r,
                          a
                      ) &&
                  ((n._pt = o = new fn(n._pt, i, e, 0, 1, s.render, s, 0, s.priority)), n !== p)
              )
                  for (l = n._ptLookup[n._targets.indexOf(i)], d = s._props.length; d--; ) l[s._props[d]] = o;
              return s;
          },
          jt = function e(t, n) {
              var r,
                  i,
                  o,
                  l,
                  d,
                  u,
                  c,
                  p,
                  f,
                  h,
                  m,
                  v,
                  g,
                  y = t.vars,
                  w = y.ease,
                  b = y.startAt,
                  E = y.immediateRender,
                  x = y.lazy,
                  S = y.onUpdate,
                  T = y.onUpdateParams,
                  _ = y.callbackScope,
                  C = y.runBackwards,
                  M = y.yoyoEase,
                  P = y.keyframes,
                  L = y.autoRevert,
                  A = t._dur,
                  k = t._startAt,
                  z = t._targets,
                  I = t.parent,
                  D = I && "nested" === I.data ? I.parent._targets : z,
                  $ = "auto" === t._overwrite && !a,
                  B = t.timeline;
              if (
                  (B && (!P || !w) && (w = "none"),
                  (t._ease = $t(w, O.ease)),
                  (t._yEase = M ? Ot($t(!0 === M ? w : M, O.ease)) : 0),
                  M && t._yoyo && !t._repeat && ((M = t._yEase), (t._yEase = t._ease), (t._ease = M)),
                  (t._from = !B && !!y.runBackwards),
                  !B)
              ) {
                  if (((v = (p = z[0] ? Ee(z[0]).harness : 0) && y[p.prop]), (r = Oe(y, pe)), k && k.render(-1, !0).kill(), b))
                      if (
                          (Be((t._startAt = Zt.set(z, Ae({ data: "isStart", overwrite: !1, parent: I, immediateRender: !0, lazy: X(x), startAt: null, delay: 0, onUpdate: S, onUpdateParams: T, callbackScope: _, stagger: 0 }, b)))),
                          n < 0 && !E && !L && t._startAt.render(-1, !0),
                          E)
                      ) {
                          if ((n > 0 && !L && (t._startAt = 0), A && n <= 0)) return void (n && (t._zTime = n));
                      } else !1 === L && (t._startAt = 0);
                  else if (C && A)
                      if (k) !L && (t._startAt = 0);
                      else if (
                          (n && (E = !1),
                          (o = Ae({ overwrite: !1, data: "isFromStart", lazy: E && X(x), immediateRender: E, stagger: 0, parent: I }, r)),
                          v && (o[p.prop] = v),
                          Be((t._startAt = Zt.set(z, o))),
                          n < 0 && t._startAt.render(-1, !0),
                          E)
                      ) {
                          if (!n) return;
                      } else e(t._startAt, 1e-8);
                  for (t._pt = 0, x = (A && X(x)) || (x && !A), i = 0; i < z.length; i++) {
                      if (
                          ((c = (d = z[i])._gsap || be(z)[i]._gsap),
                          (t._ptLookup[i] = h = {}),
                          he[c.id] && fe.length && Ce(),
                          (m = D === z ? i : D.indexOf(d)),
                          p &&
                              !1 !== (f = new p()).init(d, v || r, t, m, D) &&
                              ((t._pt = l = new fn(t._pt, d, f.name, 0, 1, f.render, f, 0, f.priority)),
                              f._props.forEach(function (e) {
                                  h[e] = l;
                              }),
                              f.priority && (u = 1)),
                          !p || v)
                      )
                          for (o in r) me[o] && (f = Xt(o, r, t, m, d, D)) ? f.priority && (u = 1) : (h[o] = l = Yt.call(t, d, o, "get", r[o], m, D, 0, y.stringFilter));
                      t._op && t._op[i] && t.kill(d, t._op[i]), $ && t._pt && ((Wt = t), s.killTweensOf(d, h, t.globalTime(0)), (g = !t.parent), (Wt = 0)), t._pt && x && (he[c.id] = 1);
                  }
                  u && pn(t), t._onInit && t._onInit(t);
              }
              (t._onUpdate = S), (t._initted = (!t._op || t._pt) && !g);
          },
          Ut = function (e, t, n, r, i) {
              return G(e) ? e.call(t, n, r, i) : N(e) && ~e.indexOf("random(") ? ht(e) : e;
          },
          Kt = we + "repeat,repeatDelay,yoyo,repeatRefresh,yoyoEase",
          Qt = (Kt + ",id,stagger,delay,duration,paused,scrollTrigger").split(","),
          Zt = (function (e) {
              function t(t, n, i, o) {
                  var l;
                  "number" == typeof n && ((i.duration = n), (n = i), (i = null));
                  var d,
                      u,
                      c,
                      p,
                      f,
                      h,
                      m,
                      v,
                      g = (l = e.call(this, o ? n : De(n)) || this).vars,
                      y = g.duration,
                      w = g.delay,
                      b = g.immediateRender,
                      E = g.stagger,
                      x = g.overwrite,
                      S = g.keyframes,
                      T = g.defaults,
                      _ = g.scrollTrigger,
                      C = g.yoyoEase,
                      M = n.parent || s,
                      P = (Q(t) || K(t) ? W(t[0]) : "length" in n) ? [t] : ot(t);
                  if (((l._targets = P.length ? be(P) : de("GSAP target " + t + " not found. https://greensock.com", !I.nullTargetWarn) || []), (l._ptLookup = []), (l._overwrite = x), S || E || U(y) || U(w))) {
                      if (((n = l.vars), (d = l.timeline = new Gt({ data: "nested", defaults: T || {} })).kill(), (d.parent = d._dp = r(l)), (d._start = 0), S))
                          Ae(d.vars.defaults, { ease: "none" }),
                              E
                                  ? P.forEach(function (e, t) {
                                        return S.forEach(function (n, r) {
                                            return d.to(e, n, r ? ">" : t * E);
                                        });
                                    })
                                  : S.forEach(function (e) {
                                        return d.to(P, e, ">");
                                    });
                      else {
                          if (((p = P.length), (m = E ? dt(E) : ce), Y(E))) for (f in E) ~Kt.indexOf(f) && (v || (v = {}), (v[f] = E[f]));
                          for (u = 0; u < p; u++) {
                              for (f in ((c = {}), n)) Qt.indexOf(f) < 0 && (c[f] = n[f]);
                              (c.stagger = 0),
                                  C && (c.yoyoEase = C),
                                  v && ze(c, v),
                                  (h = P[u]),
                                  (c.duration = +Ut(y, r(l), u, h, P)),
                                  (c.delay = (+Ut(w, r(l), u, h, P) || 0) - l._delay),
                                  !E && 1 === p && c.delay && ((l._delay = w = c.delay), (l._start += w), (c.delay = 0)),
                                  d.to(h, c, m(u, h, P));
                          }
                          d.duration() ? (y = w = 0) : (l.timeline = 0);
                      }
                      y || l.duration((y = d.duration()));
                  } else l.timeline = 0;
                  return (
                      !0 !== x || a || ((Wt = r(l)), s.killTweensOf(P), (Wt = 0)),
                      Ye(M, r(l), i),
                      n.reversed && l.reverse(),
                      n.paused && l.paused(!0),
                      (b ||
                          (!y &&
                              !S &&
                              l._start === Te(M._time) &&
                              X(b) &&
                              (function e(t) {
                                  return !t || (t._ts && e(t.parent));
                              })(r(l)) &&
                              "nested" !== M.data)) &&
                          ((l._tTime = -1e-8), l.render(Math.max(0, -w))),
                      _ && Xe(r(l), _),
                      l
                  );
              }
              i(t, e);
              var n = t.prototype;
              return (
                  (n.render = function (e, t, n) {
                      var r,
                          i,
                          a,
                          s,
                          o,
                          l,
                          d,
                          u,
                          c,
                          p = this._time,
                          f = this._tDur,
                          h = this._dur,
                          m = e > f - 1e-8 && e >= 0 ? f : e < 1e-8 ? 0 : e;
                      if (h) {
                          if (m !== this._tTime || !e || n || (!this._initted && this._tTime) || (this._startAt && this._zTime < 0 != e < 0)) {
                              if (((r = m), (u = this.timeline), this._repeat)) {
                                  if (((s = h + this._rDelay), this._repeat < -1 && e < 0)) return this.totalTime(100 * s + e, t, n);
                                  if (
                                      ((r = Te(m % s)),
                                      m === f ? ((a = this._repeat), (r = h)) : ((a = ~~(m / s)) && a === m / s && ((r = h), a--), r > h && (r = h)),
                                      (l = this._yoyo && 1 & a) && ((c = this._yEase), (r = h - r)),
                                      (o = He(this._tTime, s)),
                                      r === p && !n && this._initted)
                                  )
                                      return this;
                                  a !== o && (u && this._yEase && Dt(u, l), !this.vars.repeatRefresh || l || this._lock || ((this._lock = n = 1), (this.render(Te(s * a), !0).invalidate()._lock = 0)));
                              }
                              if (!this._initted) {
                                  if (je(this, e < 0 ? e : r, n, t)) return (this._tTime = 0), this;
                                  if (h !== this._dur) return this.render(e, t, n);
                              }
                              if (
                                  ((this._tTime = m),
                                  (this._time = r),
                                  !this._act && this._ts && ((this._act = 1), (this._lazy = 0)),
                                  (this.ratio = d = (c || this._ease)(r / h)),
                                  this._from && (this.ratio = d = 1 - d),
                                  r && !p && !t && (gt(this, "onStart"), this._tTime !== m))
                              )
                                  return this;
                              for (i = this._pt; i; ) i.r(d, i.d), (i = i._next);
                              (u && u.render(e < 0 ? e : !r && l ? -1e-8 : u._dur * d, t, n)) || (this._startAt && (this._zTime = e)),
                                  this._onUpdate && !t && (e < 0 && this._startAt && this._startAt.render(e, !0, n), gt(this, "onUpdate")),
                                  this._repeat && a !== o && this.vars.onRepeat && !t && this.parent && gt(this, "onRepeat"),
                                  (m !== this._tDur && m) ||
                                      this._tTime !== m ||
                                      (e < 0 && this._startAt && !this._onUpdate && this._startAt.render(e, !0, !0),
                                      (e || !h) && ((m === this._tDur && this._ts > 0) || (!m && this._ts < 0)) && Be(this, 1),
                                      t || (e < 0 && !p) || (!m && !p) || (gt(this, m === f ? "onComplete" : "onReverseComplete", !0), this._prom && !(m < f && this.timeScale() > 0) && this._prom()));
                          }
                      } else
                          !(function (e, t, n, r) {
                              var i,
                                  a,
                                  s,
                                  o = e.ratio,
                                  l =
                                      t < 0 ||
                                      (!t &&
                                          ((!e._start &&
                                              (function e(t) {
                                                  var n = t.parent;
                                                  return n && n._ts && n._initted && !n._lock && (n.rawTime() < 0 || e(n));
                                              })(e) &&
                                              (e._initted || !Ue(e))) ||
                                              ((e._ts < 0 || e._dp._ts < 0) && !Ue(e))))
                                          ? 0
                                          : 1,
                                  d = e._rDelay,
                                  u = 0;
                              if (
                                  (d && e._repeat && ((u = nt(0, e._tDur, t)), (a = He(u, d)), (s = He(e._tTime, d)), e._yoyo && 1 & a && (l = 1 - l), a !== s && ((o = 1 - l), e.vars.repeatRefresh && e._initted && e.invalidate())),
                                  l !== o || r || 1e-8 === e._zTime || (!t && e._zTime))
                              ) {
                                  if (!e._initted && je(e, t, r, n)) return;
                                  for (s = e._zTime, e._zTime = t || (n ? 1e-8 : 0), n || (n = t && !s), e.ratio = l, e._from && (l = 1 - l), e._time = 0, e._tTime = u, i = e._pt; i; ) i.r(l, i.d), (i = i._next);
                                  e._startAt && t < 0 && e._startAt.render(t, !0, !0),
                                      e._onUpdate && !n && gt(e, "onUpdate"),
                                      u && e._repeat && !n && e.parent && gt(e, "onRepeat"),
                                      (t >= e._tDur || t < 0) && e.ratio === l && (l && Be(e, 1), n || (gt(e, l ? "onComplete" : "onReverseComplete", !0), e._prom && e._prom()));
                              } else e._zTime || (e._zTime = t);
                          })(this, e, t, n);
                      return this;
                  }),
                  (n.targets = function () {
                      return this._targets;
                  }),
                  (n.invalidate = function () {
                      return (this._pt = this._op = this._startAt = this._onUpdate = this._lazy = this.ratio = 0), (this._ptLookup = []), this.timeline && this.timeline.invalidate(), e.prototype.invalidate.call(this);
                  }),
                  (n.kill = function (e, t) {
                      if ((void 0 === t && (t = "all"), !(e || (t && "all" !== t)))) return (this._lazy = this._pt = 0), this.parent ? yt(this) : this;
                      if (this.timeline) {
                          var n = this.timeline.totalDuration();
                          return this.timeline.killTweensOf(e, t, Wt && !0 !== Wt.vars.overwrite)._first || yt(this), this.parent && n !== this.timeline.totalDuration() && Ke(this, (this._dur * this.timeline._tDur) / n, 0, 1), this;
                      }
                      var r,
                          i,
                          a,
                          s,
                          o,
                          l,
                          d,
                          u = this._targets,
                          c = e ? ot(e) : u,
                          p = this._ptLookup,
                          f = this._pt;
                      if (
                          (!t || "all" === t) &&
                          (function (e, t) {
                              for (var n = e.length, r = n === t.length; r && n-- && e[n] === t[n]; );
                              return n < 0;
                          })(u, c)
                      )
                          return "all" === t && (this._pt = 0), yt(this);
                      for (
                          r = this._op = this._op || [],
                              "all" !== t &&
                                  (N(t) &&
                                      ((o = {}),
                                      Se(t, function (e) {
                                          return (o[e] = 1);
                                      }),
                                      (t = o)),
                                  (t = (function (e, t) {
                                      var n,
                                          r,
                                          i,
                                          a,
                                          s = e[0] ? Ee(e[0]).harness : 0,
                                          o = s && s.aliases;
                                      if (!o) return t;
                                      for (r in ((n = ze({}, t)), o)) if ((r in n)) for (i = (a = o[r].split(",")).length; i--; ) n[a[i]] = n[r];
                                      return n;
                                  })(u, t))),
                              d = u.length;
                          d--;

                      )
                          if (~c.indexOf(u[d]))
                              for (o in ((i = p[d]), "all" === t ? ((r[d] = t), (s = i), (a = {})) : ((a = r[d] = r[d] || {}), (s = t)), s))
                                  (l = i && i[o]) && (("kill" in l.d && !0 !== l.d.kill(o)) || $e(this, l, "_pt"), delete i[o]), "all" !== a && (a[o] = 1);
                      return this._initted && !this._pt && f && yt(this), this;
                  }),
                  (t.to = function (e, n) {
                      return new t(e, n, arguments[2]);
                  }),
                  (t.from = function (e, t) {
                      return et(1, arguments);
                  }),
                  (t.delayedCall = function (e, n, r, i) {
                      return new t(n, 0, { immediateRender: !1, lazy: !1, overwrite: !1, delay: e, onComplete: n, onReverseComplete: n, onCompleteParams: r, onReverseCompleteParams: r, callbackScope: i });
                  }),
                  (t.fromTo = function (e, t, n) {
                      return et(2, arguments);
                  }),
                  (t.set = function (e, n) {
                      return (n.duration = 0), n.repeatDelay || (n.repeat = 0), new t(e, n);
                  }),
                  (t.killTweensOf = function (e, t, n) {
                      return s.killTweensOf(e, t, n);
                  }),
                  t
              );
          })(Nt);
      Ae(Zt.prototype, { _targets: [], _lazy: 0, _startAt: 0, _op: 0, _onInit: 0 }),
          Se("staggerTo,staggerFrom,staggerFromTo", function (e) {
              Zt[e] = function () {
                  var t = new Gt(),
                      n = it.call(arguments, 0);
                  return n.splice("staggerFromTo" === e ? 5 : 4, 0, 0), t[e].apply(t, n);
              };
          });
      var Jt = function (e, t, n) {
              return (e[t] = n);
          },
          en = function (e, t, n) {
              return e[t](n);
          },
          tn = function (e, t, n, r) {
              return e[t](r.fp, n);
          },
          nn = function (e, t, n) {
              return e.setAttribute(t, n);
          },
          rn = function (e, t) {
              return G(e[t]) ? en : V(e[t]) && e.setAttribute ? nn : Jt;
          },
          an = function (e, t) {
              return t.set(t.t, t.p, Math.round(1e6 * (t.s + t.c * e)) / 1e6, t);
          },
          sn = function (e, t) {
              return t.set(t.t, t.p, !!(t.s + t.c * e), t);
          },
          on = function (e, t) {
              var n = t._pt,
                  r = "";
              if (!e && t.b) r = t.b;
              else if (1 === e && t.e) r = t.e;
              else {
                  for (; n; ) (r = n.p + (n.m ? n.m(n.s + n.c * e) : Math.round(1e4 * (n.s + n.c * e)) / 1e4) + r), (n = n._next);
                  r += t.c;
              }
              t.set(t.t, t.p, r, t);
          },
          ln = function (e, t) {
              for (var n = t._pt; n; ) n.r(e, n.d), (n = n._next);
          },
          dn = function (e, t, n, r) {
              for (var i, a = this._pt; a; ) (i = a._next), a.p === r && a.modifier(e, t, n), (a = i);
          },
          un = function (e) {
              for (var t, n, r = this._pt; r; ) (n = r._next), (r.p === e && !r.op) || r.op === e ? $e(this, r, "_pt") : r.dep || (t = 1), (r = n);
              return !t;
          },
          cn = function (e, t, n, r) {
              r.mSet(e, t, r.m.call(r.tween, n, r.mt), r);
          },
          pn = function (e) {
              for (var t, n, r, i, a = e._pt; a; ) {
                  for (t = a._next, n = r; n && n.pr > a.pr; ) n = n._next;
                  (a._prev = n ? n._prev : i) ? (a._prev._next = a) : (r = a), (a._next = n) ? (n._prev = a) : (i = a), (a = t);
              }
              e._pt = r;
          },
          fn = (function () {
              function e(e, t, n, r, i, a, s, o, l) {
                  (this.t = t), (this.s = r), (this.c = i), (this.p = n), (this.r = a || an), (this.d = s || this), (this.set = o || Jt), (this.pr = l || 0), (this._next = e), e && (e._prev = this);
              }
              return (
                  (e.prototype.modifier = function (e, t, n) {
                      (this.mSet = this.mSet || this.set), (this.set = cn), (this.m = e), (this.mt = n), (this.tween = t);
                  }),
                  e
              );
          })();
      Se(
          we +
              "parent,duration,ease,delay,overwrite,runBackwards,startAt,yoyo,immediateRender,repeat,repeatDelay,data,paused,reversed,lazy,callbackScope,stringFilter,id,yoyoEase,stagger,inherit,repeatRefresh,keyframes,autoRevert,scrollTrigger",
          function (e) {
              return (pe[e] = 1);
          }
      ),
          (ae.TweenMax = ae.TweenLite = Zt),
          (ae.TimelineLite = ae.TimelineMax = Gt),
          (s = new Gt({ sortChildren: !1, defaults: O, autoRemoveChildren: !0, id: "root", smoothChildTiming: !0 })),
          (I.stringFilter = Mt);
      var hn = {
          registerPlugin: function () {
              for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++) t[n] = arguments[n];
              t.forEach(function (e) {
                  return wt(e);
              });
          },
          timeline: function (e) {
              return new Gt(e);
          },
          getTweensOf: function (e, t) {
              return s.getTweensOf(e, t);
          },
          getProperty: function (e, t, n, r) {
              N(e) && (e = ot(e)[0]);
              var i = Ee(e || {}).get,
                  a = n ? Le : Pe;
              return (
                  "native" === n && (n = ""),
                  e
                      ? t
                          ? a(((me[t] && me[t].get) || i)(e, t, n, r))
                          : function (t, n, r) {
                                return a(((me[t] && me[t].get) || i)(e, t, n, r));
                            }
                      : e
              );
          },
          quickSetter: function (e, t, n) {
              if ((e = ot(e)).length > 1) {
                  var r = e.map(function (e) {
                          return gn.quickSetter(e, t, n);
                      }),
                      i = r.length;
                  return function (e) {
                      for (var t = i; t--; ) r[t](e);
                  };
              }
              e = e[0] || {};
              var a = me[t],
                  s = Ee(e),
                  o = (s.harness && (s.harness.aliases || {})[t]) || t,
                  l = a
                      ? function (t) {
                            var r = new a();
                            (p._pt = 0), r.init(e, n ? t + n : t, p, 0, [e]), r.render(1, r), p._pt && ln(1, p);
                        }
                      : s.set(e, o);
              return a
                  ? l
                  : function (t) {
                        return l(e, o, n ? t + n : t, s, 1);
                    };
          },
          isTweening: function (e) {
              return s.getTweensOf(e, !0).length > 0;
          },
          defaults: function (e) {
              return e && e.ease && (e.ease = $t(e.ease, O.ease)), Ie(O, e || {});
          },
          config: function (e) {
              return Ie(I, e || {});
          },
          registerEffect: function (e) {
              var t = e.name,
                  n = e.effect,
                  r = e.plugins,
                  i = e.defaults,
                  a = e.extendTimeline;
              (r || "").split(",").forEach(function (e) {
                  return e && !me[e] && !ae[e] && de(t + " effect requires " + e + " plugin.");
              }),
                  (ve[t] = function (e, t, r) {
                      return n(ot(e), Ae(t || {}, i), r);
                  }),
                  a &&
                      (Gt.prototype[t] = function (e, n, r) {
                          return this.add(ve[t](e, Y(n) ? n : (r = n) && {}, this), r);
                      });
          },
          registerEase: function (e, t) {
              At[e] = $t(t);
          },
          parseEase: function (e, t) {
              return arguments.length ? $t(e, t) : At;
          },
          getById: function (e) {
              return s.getById(e);
          },
          exportRoot: function (e, t) {
              void 0 === e && (e = {});
              var n,
                  r,
                  i = new Gt(e);
              for (i.smoothChildTiming = X(e.smoothChildTiming), s.remove(i), i._dp = 0, i._time = i._tTime = s._time, n = s._first; n; )
                  (r = n._next), (!t && !n._dur && n instanceof Zt && n.vars.onComplete === n._targets[0]) || Ye(i, n, n._start - n._delay), (n = r);
              return Ye(s, i, 0), i;
          },
          utils: {
              wrap: function e(t, n, r) {
                  var i = n - t;
                  return Q(t)
                      ? ft(t, e(0, t.length), n)
                      : tt(r, function (e) {
                            return ((i + ((e - t) % i)) % i) + t;
                        });
              },
              wrapYoyo: function e(t, n, r) {
                  var i = n - t,
                      a = 2 * i;
                  return Q(t)
                      ? ft(t, e(0, t.length - 1), n)
                      : tt(r, function (e) {
                            return t + ((e = (a + ((e - t) % a)) % a || 0) > i ? a - e : e);
                        });
              },
              distribute: dt,
              random: pt,
              snap: ct,
              normalize: function (e, t, n) {
                  return mt(e, t, 0, 1, n);
              },
              getUnit: rt,
              clamp: function (e, t, n) {
                  return tt(n, function (n) {
                      return nt(e, t, n);
                  });
              },
              splitColor: xt,
              toArray: ot,
              selector: function (e) {
                  return (
                      (e = ot(e)[0] || de("Invalid scope") || {}),
                      function (t) {
                          var n = e.current || e.nativeElement || e;
                          return ot(t, n.querySelectorAll ? n : n === e ? de("Invalid scope") || d.createElement("div") : e);
                      }
                  );
              },
              mapRange: mt,
              pipe: function () {
                  for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++) t[n] = arguments[n];
                  return function (e) {
                      return t.reduce(function (e, t) {
                          return t(e);
                      }, e);
                  };
              },
              unitize: function (e, t) {
                  return function (n) {
                      return e(parseFloat(n)) + (t || rt(n));
                  };
              },
              interpolate: function e(t, n, r, i) {
                  var a = isNaN(t + n)
                      ? 0
                      : function (e) {
                            return (1 - e) * t + e * n;
                        };
                  if (!a) {
                      var s,
                          o,
                          l,
                          d,
                          u,
                          c = N(t),
                          p = {};
                      if ((!0 === r && (i = 1) && (r = null), c)) (t = { p: t }), (n = { p: n });
                      else if (Q(t) && !Q(n)) {
                          for (l = [], d = t.length, u = d - 2, o = 1; o < d; o++) l.push(e(t[o - 1], t[o]));
                          d--,
                              (a = function (e) {
                                  e *= d;
                                  var t = Math.min(u, ~~e);
                                  return l[t](e - t);
                              }),
                              (r = n);
                      } else i || (t = ze(Q(t) ? [] : {}, t));
                      if (!l) {
                          for (s in n) Yt.call(p, t, s, "get", n[s]);
                          a = function (e) {
                              return ln(e, p) || (c ? t.p : t);
                          };
                      }
                  }
                  return tt(r, a);
              },
              shuffle: lt,
          },
          install: oe,
          effects: ve,
          ticker: Pt,
          updateRoot: Gt.updateRoot,
          plugins: me,
          globalTimeline: s,
          core: {
              PropTween: fn,
              globals: ue,
              Tween: Zt,
              Timeline: Gt,
              Animation: Nt,
              getCache: Ee,
              _removeLinkedListItem: $e,
              suppressOverwrites: function (e) {
                  return (a = e);
              },
          },
      };
      Se("to,from,fromTo,delayedCall,set,killTweensOf", function (e) {
          return (hn[e] = Zt[e]);
      }),
          Pt.add(Gt.updateRoot),
          (p = hn.to({}, { duration: 0 }));
      var mn = function (e, t) {
              for (var n = e._pt; n && n.p !== t && n.op !== t && n.fp !== t; ) n = n._next;
              return n;
          },
          vn = function (e, t) {
              return {
                  name: e,
                  rawVars: 1,
                  init: function (e, n, r) {
                      r._onInit = function (e) {
                          var r, i;
                          if (
                              (N(n) &&
                                  ((r = {}),
                                  Se(n, function (e) {
                                      return (r[e] = 1);
                                  }),
                                  (n = r)),
                              t)
                          ) {
                              for (i in ((r = {}), n)) r[i] = t(n[i]);
                              n = r;
                          }
                          !(function (e, t) {
                              var n,
                                  r,
                                  i,
                                  a = e._targets;
                              for (n in t) for (r = a.length; r--; ) (i = e._ptLookup[r][n]) && (i = i.d) && (i._pt && (i = mn(i, n)), i && i.modifier && i.modifier(t[n], e, a[r], n));
                          })(e, n);
                      };
                  },
              };
          },
          gn =
              hn.registerPlugin(
                  {
                      name: "attr",
                      init: function (e, t, n, r, i) {
                          var a, s;
                          for (a in t) (s = this.add(e, "setAttribute", (e.getAttribute(a) || 0) + "", t[a], r, i, 0, 0, a)) && (s.op = a), this._props.push(a);
                      },
                  },
                  {
                      name: "endArray",
                      init: function (e, t) {
                          for (var n = t.length; n--; ) this.add(e, n, e[n] || 0, t[n]);
                      },
                  },
                  vn("roundProps", ut),
                  vn("modifiers"),
                  vn("snap", ct)
              ) || hn;
      (Zt.version = Gt.version = gn.version = "3.7.1"), (u = 1), j() && Lt();
      var yn,
          wn,
          bn,
          En,
          xn,
          Sn,
          Tn,
          _n = At.Power0,
          Cn = At.Power1,
          Mn = At.Power2,
          Pn = At.Power3,
          Ln = At.Power4,
          An = At.Linear,
          kn = At.Quad,
          zn = At.Cubic,
          In = At.Quart,
          On = At.Quint,
          Dn = At.Strong,
          $n = At.Elastic,
          Bn = At.Back,
          qn = At.SteppedEase,
          Rn = At.Bounce,
          Fn = At.Sine,
          Hn = At.Expo,
          Nn = At.Circ,
          Gn = {},
          Wn = 180 / Math.PI,
          Vn = Math.PI / 180,
          Yn = Math.atan2,
          Xn = /([A-Z])/g,
          jn = /(?:left|right|width|margin|padding|x)/i,
          Un = /[\s,\(]\S/,
          Kn = { autoAlpha: "opacity,visibility", scale: "scaleX,scaleY", alpha: "opacity" },
          Qn = function (e, t) {
              return t.set(t.t, t.p, Math.round(1e4 * (t.s + t.c * e)) / 1e4 + t.u, t);
          },
          Zn = function (e, t) {
              return t.set(t.t, t.p, 1 === e ? t.e : Math.round(1e4 * (t.s + t.c * e)) / 1e4 + t.u, t);
          },
          Jn = function (e, t) {
              return t.set(t.t, t.p, e ? Math.round(1e4 * (t.s + t.c * e)) / 1e4 + t.u : t.b, t);
          },
          er = function (e, t) {
              var n = t.s + t.c * e;
              t.set(t.t, t.p, ~~(n + (n < 0 ? -0.5 : 0.5)) + t.u, t);
          },
          tr = function (e, t) {
              return t.set(t.t, t.p, e ? t.e : t.b, t);
          },
          nr = function (e, t) {
              return t.set(t.t, t.p, 1 !== e ? t.b : t.e, t);
          },
          rr = function (e, t, n) {
              return (e.style[t] = n);
          },
          ir = function (e, t, n) {
              return e.style.setProperty(t, n);
          },
          ar = function (e, t, n) {
              return (e._gsap[t] = n);
          },
          sr = function (e, t, n) {
              return (e._gsap.scaleX = e._gsap.scaleY = n);
          },
          or = function (e, t, n, r, i) {
              var a = e._gsap;
              (a.scaleX = a.scaleY = n), a.renderTransform(i, a);
          },
          lr = function (e, t, n, r, i) {
              var a = e._gsap;
              (a[t] = n), a.renderTransform(i, a);
          },
          dr = "transform",
          ur = dr + "Origin",
          cr = function (e, t) {
              var n = wn.createElementNS ? wn.createElementNS((t || "http://www.w3.org/1999/xhtml").replace(/^https/, "http"), e) : wn.createElement(e);
              return n.style ? n : wn.createElement(e);
          },
          pr = function e(t, n, r) {
              var i = getComputedStyle(t);
              return i[n] || i.getPropertyValue(n.replace(Xn, "-$1").toLowerCase()) || i.getPropertyValue(n) || (!r && e(t, hr(n) || n, 1)) || "";
          },
          fr = "O,Moz,ms,Ms,Webkit".split(","),
          hr = function (e, t, n) {
              var r = (t || xn).style,
                  i = 5;
              if (e in r && !n) return e;
              for (e = e.charAt(0).toUpperCase() + e.substr(1); i-- && !(fr[i] + e in r); );
              return i < 0 ? null : (3 === i ? "ms" : i >= 0 ? fr[i] : "") + e;
          },
          mr = function () {
              "undefined" != typeof window &&
                  window.document &&
                  ((yn = window),
                  (wn = yn.document),
                  (bn = wn.documentElement),
                  (xn = cr("div") || { style: {} }),
                  cr("div"),
                  (dr = hr(dr)),
                  (ur = dr + "Origin"),
                  (xn.style.cssText = "border-width:0;line-height:0;position:absolute;padding:0"),
                  (Tn = !!hr("perspective")),
                  (En = 1));
          },
          vr = function e(t) {
              var n,
                  r = cr("svg", (this.ownerSVGElement && this.ownerSVGElement.getAttribute("xmlns")) || "http://www.w3.org/2000/svg"),
                  i = this.parentNode,
                  a = this.nextSibling,
                  s = this.style.cssText;
              if ((bn.appendChild(r), r.appendChild(this), (this.style.display = "block"), t))
                  try {
                      (n = this.getBBox()), (this._gsapBBox = this.getBBox), (this.getBBox = e);
                  } catch (e) {}
              else this._gsapBBox && (n = this._gsapBBox());
              return i && (a ? i.insertBefore(this, a) : i.appendChild(this)), bn.removeChild(r), (this.style.cssText = s), n;
          },
          gr = function (e, t) {
              for (var n = t.length; n--; ) if (e.hasAttribute(t[n])) return e.getAttribute(t[n]);
          },
          yr = function (e) {
              var t;
              try {
                  t = e.getBBox();
              } catch (n) {
                  t = vr.call(e, !0);
              }
              return (t && (t.width || t.height)) || e.getBBox === vr || (t = vr.call(e, !0)), !t || t.width || t.x || t.y ? t : { x: +gr(e, ["x", "cx", "x1"]) || 0, y: +gr(e, ["y", "cy", "y1"]) || 0, width: 0, height: 0 };
          },
          wr = function (e) {
              return !(!e.getCTM || (e.parentNode && !e.ownerSVGElement) || !yr(e));
          },
          br = function (e, t) {
              if (t) {
                  var n = e.style;
                  t in Gn && t !== ur && (t = dr), n.removeProperty ? (("ms" !== t.substr(0, 2) && "webkit" !== t.substr(0, 6)) || (t = "-" + t), n.removeProperty(t.replace(Xn, "-$1").toLowerCase())) : n.removeAttribute(t);
              }
          },
          Er = function (e, t, n, r, i, a) {
              var s = new fn(e._pt, t, n, 0, 1, a ? nr : tr);
              return (e._pt = s), (s.b = r), (s.e = i), e._props.push(n), s;
          },
          xr = { deg: 1, rad: 1, turn: 1 },
          Sr = function e(t, n, r, i) {
              var a,
                  s,
                  o,
                  l,
                  d = parseFloat(r) || 0,
                  u = (r + "").trim().substr((d + "").length) || "px",
                  c = xn.style,
                  p = jn.test(n),
                  f = "svg" === t.tagName.toLowerCase(),
                  h = (f ? "client" : "offset") + (p ? "Width" : "Height"),
                  m = "px" === i,
                  v = "%" === i;
              return i === u || !d || xr[i] || xr[u]
                  ? d
                  : ("px" !== u && !m && (d = e(t, n, r, "px")),
                    (l = t.getCTM && wr(t)),
                    (!v && "%" !== u) || (!Gn[n] && !~n.indexOf("adius"))
                        ? ((c[p ? "width" : "height"] = 100 + (m ? u : i)),
                          (s = ~n.indexOf("adius") || ("em" === i && t.appendChild && !f) ? t : t.parentNode),
                          l && (s = (t.ownerSVGElement || {}).parentNode),
                          (s && s !== wn && s.appendChild) || (s = wn.body),
                          (o = s._gsap) && v && o.width && p && o.time === Pt.time
                              ? Te((d / o.width) * 100)
                              : ((v || "%" === u) && (c.position = pr(t, "position")),
                                s === t && (c.position = "static"),
                                s.appendChild(xn),
                                (a = xn[h]),
                                s.removeChild(xn),
                                (c.position = "absolute"),
                                p && v && (((o = Ee(s)).time = Pt.time), (o.width = s[h])),
                                Te(m ? (a * d) / 100 : a && d ? (100 / a) * d : 0)))
                        : ((a = l ? t.getBBox()[p ? "width" : "height"] : t[h]), Te(v ? (d / a) * 100 : (d / 100) * a)));
          },
          Tr = function (e, t, n, r) {
              var i;
              return (
                  En || mr(),
                  t in Kn && "transform" !== t && ~(t = Kn[t]).indexOf(",") && (t = t.split(",")[0]),
                  Gn[t] && "transform" !== t
                      ? ((i = Dr(e, r)), (i = "transformOrigin" !== t ? i[t] : i.svg ? i.origin : $r(pr(e, ur)) + " " + i.zOrigin + "px"))
                      : (!(i = e.style[t]) || "auto" === i || r || ~(i + "").indexOf("calc(")) && (i = (Pr[t] && Pr[t](e, t, n)) || pr(e, t) || xe(e, t) || ("opacity" === t ? 1 : 0)),
                  n && !~(i + "").trim().indexOf(" ") ? Sr(e, t, i, n) + n : i
              );
          },
          _r = function (e, t, n, r) {
              if (!n || "none" === n) {
                  var i = hr(t, e, 1),
                      a = i && pr(e, i, 1);
                  a && a !== n ? ((t = i), (n = a)) : "borderColor" === t && (n = pr(e, "borderTopColor"));
              }
              var s,
                  o,
                  l,
                  d,
                  u,
                  c,
                  p,
                  f,
                  h,
                  m,
                  v,
                  g,
                  y = new fn(this._pt, e.style, t, 0, 1, on),
                  w = 0,
                  b = 0;
              if (((y.b = n), (y.e = r), (n += ""), "auto" === (r += "") && ((e.style[t] = r), (r = pr(e, t) || r), (e.style[t] = n)), Mt((s = [n, r])), (r = s[1]), (l = (n = s[0]).match(ee) || []), (r.match(ee) || []).length)) {
                  for (; (o = ee.exec(r)); )
                      (p = o[0]),
                          (h = r.substring(w, o.index)),
                          u ? (u = (u + 1) % 5) : ("rgba(" !== h.substr(-5) && "hsla(" !== h.substr(-5)) || (u = 1),
                          p !== (c = l[b++] || "") &&
                              ((d = parseFloat(c) || 0),
                              (v = c.substr((d + "").length)),
                              (g = "=" === p.charAt(1) ? +(p.charAt(0) + "1") : 0) && (p = p.substr(2)),
                              (f = parseFloat(p)),
                              (m = p.substr((f + "").length)),
                              (w = ee.lastIndex - m.length),
                              m || ((m = m || I.units[t] || v), w === r.length && ((r += m), (y.e += m))),
                              v !== m && (d = Sr(e, t, c, m) || 0),
                              (y._pt = { _next: y._pt, p: h || 1 === b ? h : ",", s: d, c: g ? g * f : f - d, m: (u && u < 4) || "zIndex" === t ? Math.round : 0 }));
                  y.c = w < r.length ? r.substring(w, r.length) : "";
              } else y.r = "display" === t && "none" === r ? nr : tr;
              return ne.test(r) && (y.e = 0), (this._pt = y), y;
          },
          Cr = { top: "0%", bottom: "100%", left: "0%", right: "100%", center: "50%" },
          Mr = function (e, t) {
              if (t.tween && t.tween._time === t.tween._dur) {
                  var n,
                      r,
                      i,
                      a = t.t,
                      s = a.style,
                      o = t.u,
                      l = a._gsap;
                  if ("all" === o || !0 === o) (s.cssText = ""), (r = 1);
                  else for (i = (o = o.split(",")).length; --i > -1; ) (n = o[i]), Gn[n] && ((r = 1), (n = "transformOrigin" === n ? ur : dr)), br(a, n);
                  r && (br(a, dr), l && (l.svg && a.removeAttribute("transform"), Dr(a, 1), (l.uncache = 1)));
              }
          },
          Pr = {
              clearProps: function (e, t, n, r, i) {
                  if ("isFromStart" !== i.data) {
                      var a = (e._pt = new fn(e._pt, t, n, 0, 0, Mr));
                      return (a.u = r), (a.pr = -10), (a.tween = i), e._props.push(n), 1;
                  }
              },
          },
          Lr = [1, 0, 0, 1, 0, 0],
          Ar = {},
          kr = function (e) {
              return "matrix(1, 0, 0, 1, 0, 0)" === e || "none" === e || !e;
          },
          zr = function (e) {
              var t = pr(e, dr);
              return kr(t) ? Lr : t.substr(7).match(J).map(Te);
          },
          Ir = function (e, t) {
              var n,
                  r,
                  i,
                  a,
                  s = e._gsap || Ee(e),
                  o = e.style,
                  l = zr(e);
              return s.svg && e.getAttribute("transform")
                  ? "1,0,0,1,0,0" === (l = [(i = e.transform.baseVal.consolidate().matrix).a, i.b, i.c, i.d, i.e, i.f]).join(",")
                      ? Lr
                      : l
                  : (l !== Lr ||
                        e.offsetParent ||
                        e === bn ||
                        s.svg ||
                        ((i = o.display),
                        (o.display = "block"),
                        ((n = e.parentNode) && e.offsetParent) || ((a = 1), (r = e.nextSibling), bn.appendChild(e)),
                        (l = zr(e)),
                        i ? (o.display = i) : br(e, "display"),
                        a && (r ? n.insertBefore(e, r) : n ? n.appendChild(e) : bn.removeChild(e))),
                    t && l.length > 6 ? [l[0], l[1], l[4], l[5], l[12], l[13]] : l);
          },
          Or = function (e, t, n, r, i, a) {
              var s,
                  o,
                  l,
                  d = e._gsap,
                  u = i || Ir(e, !0),
                  c = d.xOrigin || 0,
                  p = d.yOrigin || 0,
                  f = d.xOffset || 0,
                  h = d.yOffset || 0,
                  m = u[0],
                  v = u[1],
                  g = u[2],
                  y = u[3],
                  w = u[4],
                  b = u[5],
                  E = t.split(" "),
                  x = parseFloat(E[0]) || 0,
                  S = parseFloat(E[1]) || 0;
              n
                  ? u !== Lr && (o = m * y - v * g) && ((l = x * (-v / o) + S * (m / o) - (m * b - v * w) / o), (x = x * (y / o) + S * (-g / o) + (g * b - y * w) / o), (S = l))
                  : ((x = (s = yr(e)).x + (~E[0].indexOf("%") ? (x / 100) * s.width : x)), (S = s.y + (~(E[1] || E[0]).indexOf("%") ? (S / 100) * s.height : S))),
                  r || (!1 !== r && d.smooth) ? ((w = x - c), (b = S - p), (d.xOffset = f + (w * m + b * g) - w), (d.yOffset = h + (w * v + b * y) - b)) : (d.xOffset = d.yOffset = 0),
                  (d.xOrigin = x),
                  (d.yOrigin = S),
                  (d.smooth = !!r),
                  (d.origin = t),
                  (d.originIsAbsolute = !!n),
                  (e.style[ur] = "0px 0px"),
                  a && (Er(a, d, "xOrigin", c, x), Er(a, d, "yOrigin", p, S), Er(a, d, "xOffset", f, d.xOffset), Er(a, d, "yOffset", h, d.yOffset)),
                  e.setAttribute("data-svg-origin", x + " " + S);
          },
          Dr = function (e, t) {
              var n = e._gsap || new Ht(e);
              if ("x" in n && !t && !n.uncache) return n;
              var r,
                  i,
                  a,
                  s,
                  o,
                  l,
                  d,
                  u,
                  c,
                  p,
                  f,
                  h,
                  m,
                  v,
                  g,
                  y,
                  w,
                  b,
                  E,
                  x,
                  S,
                  T,
                  _,
                  C,
                  M,
                  P,
                  L,
                  A,
                  k,
                  z,
                  O,
                  D,
                  $ = e.style,
                  B = n.scaleX < 0,
                  q = pr(e, ur) || "0";
              return (
                  (r = i = a = l = d = u = c = p = f = 0),
                  (s = o = 1),
                  (n.svg = !(!e.getCTM || !wr(e))),
                  (v = Ir(e, n.svg)),
                  n.svg && ((C = (!n.uncache || "0px 0px" === q) && !t && e.getAttribute("data-svg-origin")), Or(e, C || q, !!C || n.originIsAbsolute, !1 !== n.smooth, v)),
                  (h = n.xOrigin || 0),
                  (m = n.yOrigin || 0),
                  v !== Lr &&
                      ((b = v[0]),
                      (E = v[1]),
                      (x = v[2]),
                      (S = v[3]),
                      (r = T = v[4]),
                      (i = _ = v[5]),
                      6 === v.length
                          ? ((s = Math.sqrt(b * b + E * E)),
                            (o = Math.sqrt(S * S + x * x)),
                            (l = b || E ? Yn(E, b) * Wn : 0),
                            (c = x || S ? Yn(x, S) * Wn + l : 0) && (o *= Math.abs(Math.cos(c * Vn))),
                            n.svg && ((r -= h - (h * b + m * x)), (i -= m - (h * E + m * S))))
                          : ((D = v[6]),
                            (z = v[7]),
                            (L = v[8]),
                            (A = v[9]),
                            (k = v[10]),
                            (O = v[11]),
                            (r = v[12]),
                            (i = v[13]),
                            (a = v[14]),
                            (d = (g = Yn(D, k)) * Wn),
                            g &&
                                ((C = T * (y = Math.cos(-g)) + L * (w = Math.sin(-g))),
                                (M = _ * y + A * w),
                                (P = D * y + k * w),
                                (L = T * -w + L * y),
                                (A = _ * -w + A * y),
                                (k = D * -w + k * y),
                                (O = z * -w + O * y),
                                (T = C),
                                (_ = M),
                                (D = P)),
                            (u = (g = Yn(-x, k)) * Wn),
                            g && ((y = Math.cos(-g)), (O = S * (w = Math.sin(-g)) + O * y), (b = C = b * y - L * w), (E = M = E * y - A * w), (x = P = x * y - k * w)),
                            (l = (g = Yn(E, b)) * Wn),
                            g && ((C = b * (y = Math.cos(g)) + E * (w = Math.sin(g))), (M = T * y + _ * w), (E = E * y - b * w), (_ = _ * y - T * w), (b = C), (T = M)),
                            d && Math.abs(d) + Math.abs(l) > 359.9 && ((d = l = 0), (u = 180 - u)),
                            (s = Te(Math.sqrt(b * b + E * E + x * x))),
                            (o = Te(Math.sqrt(_ * _ + D * D))),
                            (g = Yn(T, _)),
                            (c = Math.abs(g) > 2e-4 ? g * Wn : 0),
                            (f = O ? 1 / (O < 0 ? -O : O) : 0)),
                      n.svg && ((C = e.getAttribute("transform")), (n.forceCSS = e.setAttribute("transform", "") || !kr(pr(e, dr))), C && e.setAttribute("transform", C))),
                  Math.abs(c) > 90 && Math.abs(c) < 270 && (B ? ((s *= -1), (c += l <= 0 ? 180 : -180), (l += l <= 0 ? 180 : -180)) : ((o *= -1), (c += c <= 0 ? 180 : -180))),
                  (n.x = r - ((n.xPercent = r && (n.xPercent || (Math.round(e.offsetWidth / 2) === Math.round(-r) ? -50 : 0))) ? (e.offsetWidth * n.xPercent) / 100 : 0) + "px"),
                  (n.y = i - ((n.yPercent = i && (n.yPercent || (Math.round(e.offsetHeight / 2) === Math.round(-i) ? -50 : 0))) ? (e.offsetHeight * n.yPercent) / 100 : 0) + "px"),
                  (n.z = a + "px"),
                  (n.scaleX = Te(s)),
                  (n.scaleY = Te(o)),
                  (n.rotation = Te(l) + "deg"),
                  (n.rotationX = Te(d) + "deg"),
                  (n.rotationY = Te(u) + "deg"),
                  (n.skewX = c + "deg"),
                  (n.skewY = p + "deg"),
                  (n.transformPerspective = f + "px"),
                  (n.zOrigin = parseFloat(q.split(" ")[2]) || 0) && ($[ur] = $r(q)),
                  (n.xOffset = n.yOffset = 0),
                  (n.force3D = I.force3D),
                  (n.renderTransform = n.svg ? Fr : Tn ? Rr : qr),
                  (n.uncache = 0),
                  n
              );
          },
          $r = function (e) {
              return (e = e.split(" "))[0] + " " + e[1];
          },
          Br = function (e, t, n) {
              var r = rt(t);
              return Te(parseFloat(t) + parseFloat(Sr(e, "x", n + "px", r))) + r;
          },
          qr = function (e, t) {
              (t.z = "0px"), (t.rotationY = t.rotationX = "0deg"), (t.force3D = 0), Rr(e, t);
          },
          Rr = function (e, t) {
              var n = t || this,
                  r = n.xPercent,
                  i = n.yPercent,
                  a = n.x,
                  s = n.y,
                  o = n.z,
                  l = n.rotation,
                  d = n.rotationY,
                  u = n.rotationX,
                  c = n.skewX,
                  p = n.skewY,
                  f = n.scaleX,
                  h = n.scaleY,
                  m = n.transformPerspective,
                  v = n.force3D,
                  g = n.target,
                  y = n.zOrigin,
                  w = "",
                  b = ("auto" === v && e && 1 !== e) || !0 === v;
              if (y && ("0deg" !== u || "0deg" !== d)) {
                  var E,
                      x = parseFloat(d) * Vn,
                      S = Math.sin(x),
                      T = Math.cos(x);
                  (x = parseFloat(u) * Vn), (E = Math.cos(x)), (a = Br(g, a, S * E * -y)), (s = Br(g, s, -Math.sin(x) * -y)), (o = Br(g, o, T * E * -y + y));
              }
              "0px" !== m && (w += "perspective(" + m + ") "),
                  (r || i) && (w += "translate(" + r + "%, " + i + "%) "),
                  (b || "0px" !== a || "0px" !== s || "0px" !== o) && (w += "0px" !== o || b ? "translate3d(" + a + ", " + s + ", " + o + ") " : "translate(" + a + ", " + s + ") "),
                  "0deg" !== l && (w += "rotate(" + l + ") "),
                  "0deg" !== d && (w += "rotateY(" + d + ") "),
                  "0deg" !== u && (w += "rotateX(" + u + ") "),
                  ("0deg" === c && "0deg" === p) || (w += "skew(" + c + ", " + p + ") "),
                  (1 === f && 1 === h) || (w += "scale(" + f + ", " + h + ") "),
                  (g.style[dr] = w || "translate(0, 0)");
          },
          Fr = function (e, t) {
              var n,
                  r,
                  i,
                  a,
                  s,
                  o = t || this,
                  l = o.xPercent,
                  d = o.yPercent,
                  u = o.x,
                  c = o.y,
                  p = o.rotation,
                  f = o.skewX,
                  h = o.skewY,
                  m = o.scaleX,
                  v = o.scaleY,
                  g = o.target,
                  y = o.xOrigin,
                  w = o.yOrigin,
                  b = o.xOffset,
                  E = o.yOffset,
                  x = o.forceCSS,
                  S = parseFloat(u),
                  T = parseFloat(c);
              (p = parseFloat(p)),
                  (f = parseFloat(f)),
                  (h = parseFloat(h)) && ((f += h = parseFloat(h)), (p += h)),
                  p || f
                      ? ((p *= Vn),
                        (f *= Vn),
                        (n = Math.cos(p) * m),
                        (r = Math.sin(p) * m),
                        (i = Math.sin(p - f) * -v),
                        (a = Math.cos(p - f) * v),
                        f && ((h *= Vn), (s = Math.tan(f - h)), (i *= s = Math.sqrt(1 + s * s)), (a *= s), h && ((s = Math.tan(h)), (n *= s = Math.sqrt(1 + s * s)), (r *= s))),
                        (n = Te(n)),
                        (r = Te(r)),
                        (i = Te(i)),
                        (a = Te(a)))
                      : ((n = m), (a = v), (r = i = 0)),
                  ((S && !~(u + "").indexOf("px")) || (T && !~(c + "").indexOf("px"))) && ((S = Sr(g, "x", u, "px")), (T = Sr(g, "y", c, "px"))),
                  (y || w || b || E) && ((S = Te(S + y - (y * n + w * i) + b)), (T = Te(T + w - (y * r + w * a) + E))),
                  (l || d) && ((s = g.getBBox()), (S = Te(S + (l / 100) * s.width)), (T = Te(T + (d / 100) * s.height))),
                  (s = "matrix(" + n + "," + r + "," + i + "," + a + "," + S + "," + T + ")"),
                  g.setAttribute("transform", s),
                  x && (g.style[dr] = s);
          },
          Hr = function (e, t, n, r, i, a) {
              var s,
                  o,
                  l = N(i),
                  d = parseFloat(i) * (l && ~i.indexOf("rad") ? Wn : 1),
                  u = a ? d * a : d - r,
                  c = r + u + "deg";
              return (
                  l &&
                      ("short" === (s = i.split("_")[1]) && (u %= 360) !== u % 180 && (u += u < 0 ? 360 : -360),
                      "cw" === s && u < 0 ? (u = ((u + 36e9) % 360) - 360 * ~~(u / 360)) : "ccw" === s && u > 0 && (u = ((u - 36e9) % 360) - 360 * ~~(u / 360))),
                  (e._pt = o = new fn(e._pt, t, n, r, u, Zn)),
                  (o.e = c),
                  (o.u = "deg"),
                  e._props.push(n),
                  o
              );
          },
          Nr = function (e, t) {
              for (var n in t) e[n] = t[n];
              return e;
          },
          Gr = function (e, t, n) {
              var r,
                  i,
                  a,
                  s,
                  o,
                  l,
                  d,
                  u = Nr({}, n._gsap),
                  c = n.style;
              for (i in (u.svg
                  ? ((a = n.getAttribute("transform")), n.setAttribute("transform", ""), (c[dr] = t), (r = Dr(n, 1)), br(n, dr), n.setAttribute("transform", a))
                  : ((a = getComputedStyle(n)[dr]), (c[dr] = t), (r = Dr(n, 1)), (c[dr] = a)),
              Gn))
                  (a = u[i]) !== (s = r[i]) &&
                      "perspective,force3D,transformOrigin,svgOrigin".indexOf(i) < 0 &&
                      ((o = rt(a) !== (d = rt(s)) ? Sr(n, i, a, d) : parseFloat(a)), (l = parseFloat(s)), (e._pt = new fn(e._pt, r, i, o, l - o, Qn)), (e._pt.u = d || 0), e._props.push(i));
              Nr(r, u);
          };
      /*!
       * CSSPlugin 3.7.1
       * https://greensock.com
       *
       * Copyright 2008-2021, GreenSock. All rights reserved.
       * Subject to the terms at https://greensock.com/standard-license or for
       * Club GreenSock members, the agreement issued with that membership.
       * @author: Jack Doyle, jack@greensock.com
       */ Se("padding,margin,Width,Radius", function (e, t) {
          var n = "Top",
              r = "Right",
              i = "Bottom",
              a = "Left",
              s = (t < 3 ? [n, r, i, a] : [n + a, n + r, i + r, i + a]).map(function (n) {
                  return t < 2 ? e + n : "border" + n + e;
              });
          Pr[t > 1 ? "border" + e : e] = function (e, t, n, r, i) {
              var a, o;
              if (arguments.length < 4)
                  return (
                      (a = s.map(function (t) {
                          return Tr(e, t, n);
                      })),
                      5 === (o = a.join(" ")).split(a[0]).length ? a[0] : o
                  );
              (a = (r + "").split(" ")),
                  (o = {}),
                  s.forEach(function (e, t) {
                      return (o[e] = a[t] = a[t] || a[((t - 1) / 2) | 0]);
                  }),
                  e.init(t, o, i);
          };
      });
      var Wr,
          Vr,
          Yr = {
              name: "css",
              register: mr,
              targetTest: function (e) {
                  return e.style && e.nodeType;
              },
              init: function (e, t, n, r, i) {
                  var a,
                      s,
                      o,
                      l,
                      d,
                      u,
                      c,
                      p,
                      f,
                      h,
                      m,
                      v,
                      g,
                      y,
                      w,
                      b,
                      E,
                      x,
                      S,
                      T = this._props,
                      _ = e.style,
                      C = n.vars.startAt;
                  for (c in (En || mr(), t))
                      if ("autoRound" !== c && ((s = t[c]), !me[c] || !Xt(c, t, n, r, e, i)))
                          if (((d = typeof s), (u = Pr[c]), "function" === d && (d = typeof (s = s.call(n, r, e, i))), "string" === d && ~s.indexOf("random(") && (s = ht(s)), u)) u(this, e, c, s, n) && (w = 1);
                          else if ("--" === c.substr(0, 2))
                              (a = (getComputedStyle(e).getPropertyValue(c) + "").trim()),
                                  (s += ""),
                                  (_t.lastIndex = 0),
                                  _t.test(a) || ((p = rt(a)), (f = rt(s))),
                                  f ? p !== f && (a = Sr(e, c, a, f) + f) : p && (s += p),
                                  this.add(_, "setProperty", a, s, r, i, 0, 0, c),
                                  T.push(c);
                          else if ("undefined" !== d) {
                              if (
                                  (C && c in C ? ((a = "function" == typeof C[c] ? C[c].call(n, r, e, i) : C[c]), c in I.units && !rt(a) && (a += I.units[c]), "=" === (a + "").charAt(1) && (a = Tr(e, c))) : (a = Tr(e, c)),
                                  (l = parseFloat(a)),
                                  (h = "string" === d && "=" === s.charAt(1) ? +(s.charAt(0) + "1") : 0) && (s = s.substr(2)),
                                  (o = parseFloat(s)),
                                  c in Kn &&
                                      ("autoAlpha" === c && (1 === l && "hidden" === Tr(e, "visibility") && o && (l = 0), Er(this, _, "visibility", l ? "inherit" : "hidden", o ? "inherit" : "hidden", !o)),
                                      "scale" !== c && "transform" !== c && ~(c = Kn[c]).indexOf(",") && (c = c.split(",")[0])),
                                  (m = c in Gn))
                              )
                                  if (
                                      (v ||
                                          (((g = e._gsap).renderTransform && !t.parseTransform) || Dr(e, t.parseTransform),
                                          (y = !1 !== t.smoothOrigin && g.smooth),
                                          ((v = this._pt = new fn(this._pt, _, dr, 0, 1, g.renderTransform, g, 0, -1)).dep = 1)),
                                      "scale" === c)
                                  )
                                      (this._pt = new fn(this._pt, g, "scaleY", g.scaleY, (h ? h * o : o - g.scaleY) || 0)), T.push("scaleY", c), (c += "X");
                                  else {
                                      if ("transformOrigin" === c) {
                                          (E = void 0),
                                              (x = void 0),
                                              (S = void 0),
                                              (E = (b = s).split(" ")),
                                              (x = E[0]),
                                              (S = E[1] || "50%"),
                                              ("top" !== x && "bottom" !== x && "left" !== S && "right" !== S) || ((b = x), (x = S), (S = b)),
                                              (E[0] = Cr[x] || x),
                                              (E[1] = Cr[S] || S),
                                              (s = E.join(" ")),
                                              g.svg ? Or(e, s, 0, y, 0, this) : ((f = parseFloat(s.split(" ")[2]) || 0) !== g.zOrigin && Er(this, g, "zOrigin", g.zOrigin, f), Er(this, _, c, $r(a), $r(s)));
                                          continue;
                                      }
                                      if ("svgOrigin" === c) {
                                          Or(e, s, 1, y, 0, this);
                                          continue;
                                      }
                                      if (c in Ar) {
                                          Hr(this, g, c, l, s, h);
                                          continue;
                                      }
                                      if ("smoothOrigin" === c) {
                                          Er(this, g, "smooth", g.smooth, s);
                                          continue;
                                      }
                                      if ("force3D" === c) {
                                          g[c] = s;
                                          continue;
                                      }
                                      if ("transform" === c) {
                                          Gr(this, s, e);
                                          continue;
                                      }
                                  }
                              else c in _ || (c = hr(c) || c);
                              if (m || ((o || 0 === o) && (l || 0 === l) && !Un.test(s) && c in _))
                                  o || (o = 0),
                                      (p = (a + "").substr((l + "").length)) !== (f = rt(s) || (c in I.units ? I.units[c] : p)) && (l = Sr(e, c, a, f)),
                                      (this._pt = new fn(this._pt, m ? g : _, c, l, h ? h * o : o - l, m || ("px" !== f && "zIndex" !== c) || !1 === t.autoRound ? Qn : er)),
                                      (this._pt.u = f || 0),
                                      p !== f && ((this._pt.b = a), (this._pt.r = Jn));
                              else if (c in _) _r.call(this, e, c, a, s);
                              else {
                                  if (!(c in e)) {
                                      le(c, s);
                                      continue;
                                  }
                                  this.add(e, c, a || e[c], s, r, i);
                              }
                              T.push(c);
                          }
                  w && pn(this);
              },
              get: Tr,
              aliases: Kn,
              getSetter: function (e, t, n) {
                  var r = Kn[t];
                  return (
                      r && r.indexOf(",") < 0 && (t = r),
                      t in Gn && t !== ur && (e._gsap.x || Tr(e, "x")) ? (n && Sn === n ? ("scale" === t ? sr : ar) : (Sn = n || {}) && ("scale" === t ? or : lr)) : e.style && !V(e.style[t]) ? rr : ~t.indexOf("-") ? ir : rn(e, t)
                  );
              },
              core: { _removeProperty: br, _getMatrix: Ir },
          };
      (gn.utils.checkPrefix = hr),
          (Vr = Se("x,y,z,scale,scaleX,scaleY,xPercent,yPercent," + (Wr = "rotation,rotationX,rotationY,skewX,skewY") + ",transform,transformOrigin,svgOrigin,force3D,smoothOrigin,transformPerspective", function (e) {
              Gn[e] = 1;
          })),
          Se(Wr, function (e) {
              (I.units[e] = "deg"), (Ar[e] = 1);
          }),
          (Kn[Vr[13]] = "x,y,z,scale,scaleX,scaleY,xPercent,yPercent," + Wr),
          Se("0:translateX,1:translateY,2:translateZ,8:rotate,8:rotationZ,8:rotateZ,9:rotateX,10:rotateY", function (e) {
              var t = e.split(":");
              Kn[t[1]] = Vr[t[0]];
          }),
          Se("x,y,z,top,right,bottom,left,width,height,fontSize,padding,margin,perspective", function (e) {
              I.units[e] = "px";
          }),
          gn.registerPlugin(Yr);
      var Xr = gn.registerPlugin(Yr) || gn,
          jr = Xr.core.Tween;
  },
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  function (e, t, n) {
      "use strict";
      Array.from(document.querySelectorAll(".select")).forEach(function (e) {
          var t = e.querySelector("select"),
              n = e.querySelector(".select-label");
          t.addEventListener("change", function (e) {
              var r = t.querySelector('option[value="'.concat(t.value, '"]'));
              r && (n.innerHTML = r.innerHTML);
          });
      });
  },
  function (e, t, n) {
      "use strict";
      var r = n(2);
      Object.defineProperty(t, "__esModule", { value: !0 }), (t.default = void 0);
      var i = r(n(36)),
          a = r(n(37)),
          s = (function () {
              function e(t) {
                  var n = this;
                  (0, i.default)(this, e),
                      (this.el = t),
                      (this.cards = Array.from(t.children)),
                      this.resize(),
                      window.addEventListener("resize", function () {
                          return n.resize();
                      });
              }
              return (
                  (0, a.default)(e, [
                      {
                          key: "resize",
                          value: function () {
                              var e = this;
                              (this.maxItems = 3),
                                  (this.containerWidth = this.el.parentElement.clientWidth),
                                  (this.cardM = 32),
                                  (this.cardW = (this.containerWidth - this.cardM * (this.maxItems - 1)) / this.maxItems),
                                  (this.el.style.width = "".concat(this.containerWidth + this.cardM, "px"));
                              var t = 1;
                              this.cards.forEach(function (n, r) {
                                  var i = "normal";
                                  switch ((3 !== e.maxItems || (2 !== t && 6 !== t) || (i = "big"), 3 === e.maxItems && 8 === t && (i = "full"), n.setAttribute("data-size", i), i)) {
                                      case "big":
                                          n.style.width = "".concat(2 * e.cardW + e.cardM, "px");
                                          break;
                                      case "full":
                                          n.style.width = "".concat(e.containerWidth, "px");
                                          break;
                                      default:
                                          n.style.width = "".concat(e.cardW, "px");
                                  }
                                  ("big" !== i && "full" !== i) ||
                                      (n.classList.contains("card-news") && ((n.querySelector(".card-content").style.width = "".concat(e.cardW, "px")), (n.querySelector("figure").style.width = "calc(100% - ".concat(e.cardW, "px)")))),
                                      (n.style.marginRight = "".concat(e.cardM, "px")),
                                      (n.style.marginBottom = "".concat(e.cardM, "px")),
                                      t > 7 ? (t = 1) : t++;
                              });
                          },
                      },
                  ]),
                  e
              );
          })();
      (t.default = s),
          Array.from(document.querySelectorAll(".cards-grid")).forEach(function (e) {
              window.innerWidth < 800 || new s(e);
          });
  },
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  function (e, t) {
      var n;
      n = (function () {
          return this;
      })();
      try {
          n = n || new Function("return this")();
      } catch (e) {
          "object" == typeof window && (n = window);
      }
      e.exports = n;
  },
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  function (e, t, n) {
      "use strict";
      var r;
      Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.default = void 0),
          (window.onYouTubeIframeAPIReady = function () {
              r && r();
          });
      var i = {
          init: function (e) {
              r = e;
              var t = document.createElement("script");
              t.src = "https://www.youtube.com/iframe_api";
              var n = document.getElementsByTagName("script")[0];
              n.parentNode.insertBefore(t, n);
          },
      };
      t.default = i;
  },
  function (e, t, n) {
      "use strict";
      var r = n(2);
      Object.defineProperty(t, "__esModule", { value: !0 }), (t.default = void 0);
      var i = r(n(36)),
          a = r(n(37)),
          s = (function () {
              function e() {
                  (0, i.default)(this, e), (this.appPrefix = "SWEDD2021174");
              }
              return (
                  (0, a.default)(e, [
                      {
                          key: "get",
                          value: function (e) {
                              var t = localStorage.getItem(this.appPrefix + e);
                              return "true" === t && (t = !0), "false" === t && (t = !1), t;
                          },
                      },
                      {
                          key: "set",
                          value: function (e, t) {
                              localStorage.setItem(this.appPrefix + e, t.constructor === {}.constructor || Array.isArray(t) ? JSON.stringify(t) : t);
                          },
                      },
                      {
                          key: "clear",
                          value: function () {
                              localStorage.clear();
                          },
                      },
                      {
                          key: "remove",
                          value: function (e) {
                              localStorage.removeItem(this.appPrefix + e);
                          },
                      },
                  ]),
                  e
              );
          })();
      t.default = s;
  },
  function (e, t, n) {
      "use strict";
      var r = n(2);
      Object.defineProperty(t, "__esModule", { value: !0 }), (t.default = void 0);
      var i = r(n(36)),
          a = r(n(37)),
          s = r(n(6)),
          o = (function () {
              function e(t, n) {
                  var r = this;
                  (0, i.default)(this, e),
                      (this.$el = t),
                      (this.toggleListener = n),
                      (this.cover = this.$el.querySelector(".video-cover")),
                      (this.button = this.$el.querySelector(".video-button")),
                      (this.src = this.$el.getAttribute("data-src")),
                      (this.playing = !1),
                      (this.passive = !0),
                      (null !== this.$el.getAttribute("data-passive") && "false" !== this.$el.getAttribute("data-passive")) || (this.passive = !1),
                      (this.native = s.default.isVideoNative(this.src)),
                      this.resize(),
                      this.addMedia(),
                      this.$el.addEventListener("click", function (e) {
                          r.play();
                      });
              }
              return (
                  (0, a.default)(e, [
                      {
                          key: "resize",
                          value: function () {
                              (this.width = this.$el.clientWidth), (this.height = this.$el.clientHeight);
                          },
                      },
                      {
                          key: "play",
                          value: function () {
                              var e = this;
                              this.$el.classList.contains("playing") ||
                                  this.native ||
                                  (this.player
                                      ? this.player.getPlayerState() != YT.PlayerState.PLAYING && this.player.playVideo()
                                      : ((this.$el.style.pointerEvent = "none"),
                                        this.initYT(function () {
                                            e.player.getPlayerState() != YT.PlayerState.PLAYING && e.player.playVideo(), (e.$el.style.pointerEvent = "all");
                                        })));
                          },
                      },
                      {
                          key: "stop",
                          value: function () {
                              this.$el.classList.contains("playing") &&
                                  (this.native || (this.player.getPlayerState() === YT.PlayerState.PLAYING && (this.$el.classList.remove("playing"), this.player.stopVideo(), this.toggleListener && this.toggleListener(!1))));
                          },
                      },
                      {
                          key: "addMedia",
                          value: function () {
                              var e;
                              this.native ? (((e = document.createElement("video")).src = this.src), (e.controls = !0), this.$el.appendChild(e)) : this.passive || this.initYT();
                          },
                      },
                      {
                          key: "initYT",
                          value: function (e) {
                              var t = this,
                                  n = document.createElement("div");
                              Array.from(n.querySelectorAll("video, iframe")).forEach(function (e) {
                                  return e.remove();
                              }),
                                  this.$el.appendChild(n),
                                  (this.id = s.default.getEmbedURL(this.src, !0).id),
                                  (this.player = new YT.Player(n, {
                                      height: this.width,
                                      width: this.height,
                                      videoId: this.id,
                                      playerVars: { controls: 0, disablekb: 1, playsinline: 1, showinfo: 0, rel: 0, modestbranding: 1 },
                                      events: {
                                          onReady: function (n) {
                                              t.onPlayerReady(n), e && e();
                                          },
                                          onStateChange: function (e) {
                                              t.onPlayerStateChange(e);
                                          },
                                      },
                                  }));
                          },
                      },
                      { key: "onPlayerReady", value: function (e) {} },
                      {
                          key: "onPlayerStateChange",
                          value: function (e) {
                              var t = this.player.getPlayerState();
                              void 0 === this.stared && t === YT.PlayerState.PLAYING && (this.stared = !0),
                                  (t !== YT.PlayerState.PLAYING && t !== YT.PlayerState.BUFFERING) || (this.$el.classList.add("playing"), this.toggleListener && this.toggleListener(!0)),
                                  !this.stared || (t !== YT.PlayerState.PAUSED && t !== YT.PlayerState.ENDED) || t === YT.PlayerState.BUFFERING || (this.$el.classList.remove("playing"), this.toggleListener && this.toggleListener(!1)),
                                  t === YT.PlayerState.ENDED && (this.stared = void 0),
                                  (this.playing = t === YT.PlayerState.PLAYING);
                          },
                      },
                  ]),
                  e
              );
          })();
      t.default = o;
  },
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  function (e, t) {
      (e.exports = function (e, t) {
          (null == t || t > e.length) && (t = e.length);
          for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
          return r;
      }),
          (e.exports.default = e.exports),
          (e.exports.__esModule = !0);
  },
  function (e, t) {
      function n(t) {
          return (
              "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
                  ? ((e.exports = n = function (e) {
                        return typeof e;
                    }),
                    (e.exports.default = e.exports),
                    (e.exports.__esModule = !0))
                  : ((e.exports = n = function (e) {
                        return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e;
                    }),
                    (e.exports.default = e.exports),
                    (e.exports.__esModule = !0)),
              n(t)
          );
      }
      (e.exports = n), (e.exports.default = e.exports), (e.exports.__esModule = !0);
  },
  function (e, t, n) {
      "use strict";
      n(159);
  },
  function (e, t, n) {
      "use strict";
      var r, i, a, s, o;
      (window.fbAsyncInit = function () {
          FB.init({ appId: "903576040391946", xfbml: !0, version: "v8.0" }), FB.AppEvents.logPageView();
      }),
          (r = document),
          (i = "script"),
          (a = "facebook-jssdk"),
          (o = r.getElementsByTagName(i)[0]),
          r.getElementById(a) || (((s = r.createElement(i)).id = a), (s.src = "https://connect.facebook.net/en_US/sdk.js"), o.parentNode.insertBefore(s, o));
  },
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  ,
  function (e, t, n) {
      n(152), n(161), n(162), n(163), n(164), n(165), n(166), n(167), n(168), n(169), n(170), n(171), n(172), n(173), n(174), n(175), n(176), n(177), n(178), n(179), n(180), n(181), n(182), (e.exports = n(183));
  },
  function (e, t, n) {
      "use strict";
      var r = n(2),
          i = r(n(7));
      n(10);
      var a = r(n(6)),
          s = r(n(81)),
          o = r(n(82));
      n(16), n(113);
      var l,
          d,
          u = r(n(8)),
          c = r(n(11)),
          p = r(n(12)),
          f = r(n(13)),
          h = r(n(83)),
          m = document.getElementById("overlay"),
          v = [].concat((0, i.default)(Array.from(document.querySelectorAll(".fade-in"))), (0, i.default)(Array.from(document.querySelectorAll(".fade-in-y")))),
          g = (new o.default(), []);
      function y(e) {
          v.forEach(function (e) {
              !e.classList.contains("show") && a.default.isInViewportDom(e, 220) && e.classList.add("show");
          });
      }
      function w() {
          window.innerWidth;
          var e = 0.01 * window.innerHeight;
          (l = window.innerWidth <= 1024) && !d ? ((d = !0), document.documentElement.style.setProperty("--vh", "".concat(e, "px"))) : l || document.documentElement.style.setProperty("--vh", "".concat(e, "px"));
          var t = document.querySelector(".container");
          if (t) {
              var n = t.getBoundingClientRect();
              document.documentElement.style.setProperty("--container-margin", "".concat(n.left, "px")), document.documentElement.style.setProperty("--container-width", "".concat(n.width, "px"));
          }
      }
      a.default.waitForLoader(function () {
          (window.scroll = new u.default(y)), new c.default(), new p.default(), new f.default(), y();
          var e = document.querySelector(".scrollDown");
          if(e){
          e.addEventListener("click", function () {
              window.scroll.goTo(e.dataset.to);
          });
        }
      }),
          document.documentElement.setAttribute("data-browser", a.default.getBrowser()),
          (function () {
              function e(t) {
                  Array.from(document.querySelectorAll(".video-component .video-container")).forEach(function (t) {
                      t.removeEventListener("click", e);
                  }),
                      s.default.init(function () {
                          var e;
                          (e = function () {
                              t.click();
                          }),
                              Array.from(document.querySelectorAll(".video-component .video-container")).forEach(function (e) {
                                  g.push(
                                      new h.default(e, function () {
                                          g.forEach(function (t) {
                                              t.$el !== e && t.stop();
                                          });
                                      })
                                  );
                              }),
                              setTimeout(function () {
                                  e && e();
                              }, 1e3);
                      });
              }
              Array.from(document.querySelectorAll(".video-component .video-container")).forEach(function (t) {
                  t.addEventListener("click", function () {
                      e(t);
                  });
              }),
                  !0;
          })(),
          w(),
          window.addEventListener("resize", w),
          Array.from(document.querySelectorAll(".inner-link")).forEach(function (e) {
              e.addEventListener("click", function (t) {
                  t.preventDefault(),
                      m.classList.add("show"),
                      setTimeout(function () {
                          location.href = e.getAttribute("href");
                      }, 350);
              });
          }),
          window.addEventListener("beforeunload", function (e) {
              m.classList.add("show");
          });
  },
  function (e, t, n) {
      var r = n(111);
      (e.exports = function (e) {
          if (Array.isArray(e)) return r(e);
      }),
          (e.exports.default = e.exports),
          (e.exports.__esModule = !0);
  },
  function (e, t) {
      (e.exports = function (e) {
          if ("undefined" != typeof Symbol && Symbol.iterator in Object(e)) return Array.from(e);
      }),
          (e.exports.default = e.exports),
          (e.exports.__esModule = !0);
  },
  function (e, t, n) {
      var r = n(111);
      (e.exports = function (e, t) {
          if (e) {
              if ("string" == typeof e) return r(e, t);
              var n = Object.prototype.toString.call(e).slice(8, -1);
              return "Object" === n && e.constructor && (n = e.constructor.name), "Map" === n || "Set" === n ? Array.from(e) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? r(e, t) : void 0;
          }
      }),
          (e.exports.default = e.exports),
          (e.exports.__esModule = !0);
  },
  function (e, t) {
      (e.exports = function () {
          throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
      }),
          (e.exports.default = e.exports),
          (e.exports.__esModule = !0);
  },
  function (e, t, n) {
      "use strict";
      (function (e) {
          var t = n(2)(n(112));
          !(function (e) {
              var n = (function () {
                      try {
                          return !!Symbol.iterator;
                      } catch (e) {
                          return !1;
                      }
                  })(),
                  r = function (e) {
                      var t = {
                          next: function () {
                              var t = e.shift();
                              return { done: void 0 === t, value: t };
                          },
                      };
                      return (
                          n &&
                              (t[Symbol.iterator] = function () {
                                  return t;
                              }),
                          t
                      );
                  },
                  i = function (e) {
                      return encodeURIComponent(e).replace(/%20/g, "+");
                  },
                  a = function (e) {
                      return decodeURIComponent(String(e).replace(/\+/g, " "));
                  };
              (function () {
                  try {
                      var t = e.URLSearchParams;
                      return "a=1" === new t("?a=1").toString() && "function" == typeof t.prototype.set && "function" == typeof t.prototype.entries;
                  } catch (t) {
                      return !1;
                  }
              })() ||
                  (function () {
                      var a = function e(n) {
                              Object.defineProperty(this, "_entries", { writable: !0, value: {} });
                              var r = (0, t.default)(n);
                              if ("undefined" === r);
                              else if ("string" === r) "" !== n && this._fromString(n);
                              else if (n instanceof e) {
                                  var i = this;
                                  n.forEach(function (e, t) {
                                      i.append(t, e);
                                  });
                              } else {
                                  if (null === n || "object" !== r) throw new TypeError("Unsupported input's type for URLSearchParams");
                                  if ("[object Array]" === Object.prototype.toString.call(n))
                                      for (var a = 0; a < n.length; a++) {
                                          var s = n[a];
                                          if ("[object Array]" !== Object.prototype.toString.call(s) && 2 === s.length) throw new TypeError("Expected [string, any] as entry at index " + a + " of URLSearchParams's input");
                                          this.append(s[0], s[1]);
                                      }
                                  else for (var o in n) n.hasOwnProperty(o) && this.append(o, n[o]);
                              }
                          },
                          s = a.prototype;
                      (s.append = function (e, t) {
                          e in this._entries ? this._entries[e].push(String(t)) : (this._entries[e] = [String(t)]);
                      }),
                          (s.delete = function (e) {
                              delete this._entries[e];
                          }),
                          (s.get = function (e) {
                              return e in this._entries ? this._entries[e][0] : null;
                          }),
                          (s.getAll = function (e) {
                              return e in this._entries ? this._entries[e].slice(0) : [];
                          }),
                          (s.has = function (e) {
                              return e in this._entries;
                          }),
                          (s.set = function (e, t) {
                              this._entries[e] = [String(t)];
                          }),
                          (s.forEach = function (e, t) {
                              var n;
                              for (var r in this._entries)
                                  if (this._entries.hasOwnProperty(r)) {
                                      n = this._entries[r];
                                      for (var i = 0; i < n.length; i++) e.call(t, n[i], r, this);
                                  }
                          }),
                          (s.keys = function () {
                              var e = [];
                              return (
                                  this.forEach(function (t, n) {
                                      e.push(n);
                                  }),
                                  r(e)
                              );
                          }),
                          (s.values = function () {
                              var e = [];
                              return (
                                  this.forEach(function (t) {
                                      e.push(t);
                                  }),
                                  r(e)
                              );
                          }),
                          (s.entries = function () {
                              var e = [];
                              return (
                                  this.forEach(function (t, n) {
                                      e.push([n, t]);
                                  }),
                                  r(e)
                              );
                          }),
                          n && (s[Symbol.iterator] = s.entries),
                          (s.toString = function () {
                              var e = [];
                              return (
                                  this.forEach(function (t, n) {
                                      e.push(i(n) + "=" + i(t));
                                  }),
                                  e.join("&")
                              );
                          }),
                          (e.URLSearchParams = a);
                  })();
              var s = e.URLSearchParams.prototype;
              "function" != typeof s.sort &&
                  (s.sort = function () {
                      var e = this,
                          t = [];
                      this.forEach(function (n, r) {
                          t.push([r, n]), e._entries || e.delete(r);
                      }),
                          t.sort(function (e, t) {
                              return e[0] < t[0] ? -1 : e[0] > t[0] ? 1 : 0;
                          }),
                          e._entries && (e._entries = {});
                      for (var n = 0; n < t.length; n++) this.append(t[n][0], t[n][1]);
                  }),
                  "function" != typeof s._fromString &&
                      Object.defineProperty(s, "_fromString", {
                          enumerable: !1,
                          configurable: !1,
                          writable: !1,
                          value: function (e) {
                              if (this._entries) this._entries = {};
                              else {
                                  var t = [];
                                  this.forEach(function (e, n) {
                                      t.push(n);
                                  });
                                  for (var n = 0; n < t.length; n++) this.delete(t[n]);
                              }
                              var r,
                                  i = (e = e.replace(/^\?/, "")).split("&");
                              for (n = 0; n < i.length; n++) (r = i[n].split("=")), this.append(a(r[0]), r.length > 1 ? a(r[1]) : "");
                          },
                      });
          })(void 0 !== e ? e : "undefined" != typeof window ? window : "undefined" != typeof self ? self : void 0),
              (function (e) {
                  if (
                      ((function () {
                          try {
                              var t = new e.URL("b", "http://a");
                              return (t.pathname = "c d"), "http://a/c%20d" === t.href && t.searchParams;
                          } catch (t) {
                              return !1;
                          }
                      })() ||
                          (function () {
                              var t = e.URL,
                                  n = function t(n, r) {
                                      "string" != typeof n && (n = String(n));
                                      var i,
                                          a = document;
                                      if (r && (void 0 === e.location || r !== e.location.href)) {
                                          (r = r.toLowerCase()), ((i = (a = document.implementation.createHTMLDocument("")).createElement("base")).href = r), a.head.appendChild(i);
                                          try {
                                              if (0 !== i.href.indexOf(r)) throw new Error(i.href);
                                          } catch (t) {
                                              throw new Error("URL unable to set base " + r + " due to " + t);
                                          }
                                      }
                                      var s = a.createElement("a");
                                      (s.href = n), i && (a.body.appendChild(s), (s.href = s.href));
                                      var o = a.createElement("input");
                                      if (((o.type = "url"), (o.value = n), ":" === s.protocol || !/:/.test(s.href) || (!o.checkValidity() && !r))) throw new TypeError("Invalid URL");
                                      Object.defineProperty(this, "_anchorElement", { value: s });
                                      var l = new e.URLSearchParams(this.search),
                                          d = !0,
                                          u = !0,
                                          c = this;
                                      ["append", "delete", "set"].forEach(function (e) {
                                          var t = l[e];
                                          l[e] = function () {
                                              t.apply(l, arguments), d && ((u = !1), (c.search = l.toString()), (u = !0));
                                          };
                                      }),
                                          Object.defineProperty(this, "searchParams", { value: l, enumerable: !0 });
                                      var p = void 0;
                                      Object.defineProperty(this, "_updateSearchParams", {
                                          enumerable: !1,
                                          configurable: !1,
                                          writable: !1,
                                          value: function () {
                                              this.search !== p && ((p = this.search), u && ((d = !1), this.searchParams._fromString(this.search), (d = !0)));
                                          },
                                      });
                                  },
                                  r = n.prototype;
                              ["hash", "host", "hostname", "port", "protocol"].forEach(function (e) {
                                  !(function (e) {
                                      Object.defineProperty(r, e, {
                                          get: function () {
                                              return this._anchorElement[e];
                                          },
                                          set: function (t) {
                                              this._anchorElement[e] = t;
                                          },
                                          enumerable: !0,
                                      });
                                  })(e);
                              }),
                                  Object.defineProperty(r, "search", {
                                      get: function () {
                                          return this._anchorElement.search;
                                      },
                                      set: function (e) {
                                          (this._anchorElement.search = e), this._updateSearchParams();
                                      },
                                      enumerable: !0,
                                  }),
                                  Object.defineProperties(r, {
                                      toString: {
                                          get: function () {
                                              var e = this;
                                              return function () {
                                                  return e.href;
                                              };
                                          },
                                      },
                                      href: {
                                          get: function () {
                                              return this._anchorElement.href.replace(/\?$/, "");
                                          },
                                          set: function (e) {
                                              (this._anchorElement.href = e), this._updateSearchParams();
                                          },
                                          enumerable: !0,
                                      },
                                      pathname: {
                                          get: function () {
                                              return this._anchorElement.pathname.replace(/(^\/?)/, "/");
                                          },
                                          set: function (e) {
                                              this._anchorElement.pathname = e;
                                          },
                                          enumerable: !0,
                                      },
                                      origin: {
                                          get: function () {
                                              var e = { "http:": 80, "https:": 443, "ftp:": 21 }[this._anchorElement.protocol],
                                                  t = this._anchorElement.port != e && "" !== this._anchorElement.port;
                                              return this._anchorElement.protocol + "//" + this._anchorElement.hostname + (t ? ":" + this._anchorElement.port : "");
                                          },
                                          enumerable: !0,
                                      },
                                      password: {
                                          get: function () {
                                              return "";
                                          },
                                          set: function (e) {},
                                          enumerable: !0,
                                      },
                                      username: {
                                          get: function () {
                                              return "";
                                          },
                                          set: function (e) {},
                                          enumerable: !0,
                                      },
                                  }),
                                  (n.createObjectURL = function (e) {
                                      return t.createObjectURL.apply(t, arguments);
                                  }),
                                  (n.revokeObjectURL = function (e) {
                                      return t.revokeObjectURL.apply(t, arguments);
                                  }),
                                  (e.URL = n);
                          })(),
                      void 0 !== e.location && !("origin" in e.location))
                  ) {
                      var t = function () {
                          return e.location.protocol + "//" + e.location.hostname + (e.location.port ? ":" + e.location.port : "");
                      };
                      try {
                          Object.defineProperty(e.location, "origin", { get: t, enumerable: !0 });
                      } catch (n) {
                          setInterval(function () {
                              e.location.origin = t();
                          }, 100);
                      }
                  }
              })(void 0 !== e ? e : "undefined" != typeof window ? window : "undefined" != typeof self ? self : void 0);
      }.call(this, n(66)));
  },
  function (e, t, n) {
      "use strict";
      var r,
          i,
          a = n(2)(n(112));
      !(function (s, o) {
          "object" == (0, a.default)(t) && void 0 !== e ? (e.exports = o()) : void 0 === (i = "function" == typeof (r = o) ? r.call(t, n, t, e) : r) || (e.exports = i);
      })(0, function () {
          function e(e, t) {
              for (var n = 0; n < t.length; n++) {
                  var r = t[n];
                  (r.enumerable = r.enumerable || !1), (r.configurable = !0), "value" in r && (r.writable = !0), Object.defineProperty(e, r.key, r);
              }
          }
          function t() {
              return (t =
                  Object.assign ||
                  function (e) {
                      for (var t = 1; t < arguments.length; t++) {
                          var n = arguments[t];
                          for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r]);
                      }
                      return e;
                  }).apply(this, arguments);
          }
          function n(e) {
              return null !== e && "object" == (0, a.default)(e) && "constructor" in e && e.constructor === Object;
          }
          function r(e, t) {
              void 0 === e && (e = {}),
                  void 0 === t && (t = {}),
                  Object.keys(t).forEach(function (i) {
                      void 0 === e[i] ? (e[i] = t[i]) : n(t[i]) && n(e[i]) && Object.keys(t[i]).length > 0 && r(e[i], t[i]);
                  });
          }
          var i = {
              body: {},
              addEventListener: function () {},
              removeEventListener: function () {},
              activeElement: { blur: function () {}, nodeName: "" },
              querySelector: function () {
                  return null;
              },
              querySelectorAll: function () {
                  return [];
              },
              getElementById: function () {
                  return null;
              },
              createEvent: function () {
                  return { initEvent: function () {} };
              },
              createElement: function () {
                  return {
                      children: [],
                      childNodes: [],
                      style: {},
                      setAttribute: function () {},
                      getElementsByTagName: function () {
                          return [];
                      },
                  };
              },
              createElementNS: function () {
                  return {};
              },
              importNode: function () {
                  return null;
              },
              location: { hash: "", host: "", hostname: "", href: "", origin: "", pathname: "", protocol: "", search: "" },
          };
          function s() {
              var e = "undefined" != typeof document ? document : {};
              return r(e, i), e;
          }
          var o = {
              document: i,
              navigator: { userAgent: "" },
              location: { hash: "", host: "", hostname: "", href: "", origin: "", pathname: "", protocol: "", search: "" },
              history: { replaceState: function () {}, pushState: function () {}, go: function () {}, back: function () {} },
              CustomEvent: function () {
                  return this;
              },
              addEventListener: function () {},
              removeEventListener: function () {},
              getComputedStyle: function () {
                  return {
                      getPropertyValue: function () {
                          return "";
                      },
                  };
              },
              Image: function () {},
              Date: function () {},
              screen: {},
              setTimeout: function () {},
              clearTimeout: function () {},
              matchMedia: function () {
                  return {};
              },
              requestAnimationFrame: function (e) {
                  return "undefined" == typeof setTimeout ? (e(), null) : setTimeout(e, 0);
              },
              cancelAnimationFrame: function (e) {
                  "undefined" != typeof setTimeout && clearTimeout(e);
              },
          };
          function l() {
              var e = "undefined" != typeof window ? window : {};
              return r(e, o), e;
          }
          function d(e) {
              return (d = Object.setPrototypeOf
                  ? Object.getPrototypeOf
                  : function (e) {
                        return e.__proto__ || Object.getPrototypeOf(e);
                    })(e);
          }
          function u(e, t) {
              return (u =
                  Object.setPrototypeOf ||
                  function (e, t) {
                      return (e.__proto__ = t), e;
                  })(e, t);
          }
          function c() {
              if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
              if (Reflect.construct.sham) return !1;
              if ("function" == typeof Proxy) return !0;
              try {
                  return Date.prototype.toString.call(Reflect.construct(Date, [], function () {})), !0;
              } catch (e) {
                  return !1;
              }
          }
          function p(e, t, n) {
              return (p = c()
                  ? Reflect.construct
                  : function (e, t, n) {
                        var r = [null];
                        r.push.apply(r, t);
                        var i = new (Function.bind.apply(e, r))();
                        return n && u(i, n.prototype), i;
                    }).apply(null, arguments);
          }
          function f(e) {
              var t = "function" == typeof Map ? new Map() : void 0;
              return (f = function (e) {
                  if (null === e || ((n = e), -1 === Function.toString.call(n).indexOf("[native code]"))) return e;
                  var n;
                  if ("function" != typeof e) throw new TypeError("Super expression must either be null or a function");
                  if (void 0 !== t) {
                      if (t.has(e)) return t.get(e);
                      t.set(e, r);
                  }
                  function r() {
                      return p(e, arguments, d(this).constructor);
                  }
                  return (r.prototype = Object.create(e.prototype, { constructor: { value: r, enumerable: !1, writable: !0, configurable: !0 } })), u(r, e);
              })(e);
          }
          var h = (function (e) {
              var t, n;
              function r(t) {
                  var n, r, i;
                  return (
                      (r = (function (e) {
                          if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
                          return e;
                      })((n = e.call.apply(e, [this].concat(t)) || this))),
                      (i = r.__proto__),
                      Object.defineProperty(r, "__proto__", {
                          get: function () {
                              return i;
                          },
                          set: function (e) {
                              i.__proto__ = e;
                          },
                      }),
                      n
                  );
              }
              return (n = e), ((t = r).prototype = Object.create(n.prototype)), (t.prototype.constructor = t), (t.__proto__ = n), r;
          })(f(Array));
          function m(e) {
              void 0 === e && (e = []);
              var t = [];
              return (
                  e.forEach(function (e) {
                      Array.isArray(e) ? t.push.apply(t, m(e)) : t.push(e);
                  }),
                  t
              );
          }
          function v(e, t) {
              return Array.prototype.filter.call(e, t);
          }
          function g(e, t) {
              var n = l(),
                  r = s(),
                  i = [];
              if (!t && e instanceof h) return e;
              if (!e) return new h(i);
              if ("string" == typeof e) {
                  var a = e.trim();
                  if (a.indexOf("<") >= 0 && a.indexOf(">") >= 0) {
                      var o = "div";
                      0 === a.indexOf("<li") && (o = "ul"),
                          0 === a.indexOf("<tr") && (o = "tbody"),
                          (0 !== a.indexOf("<td") && 0 !== a.indexOf("<th")) || (o = "tr"),
                          0 === a.indexOf("<tbody") && (o = "table"),
                          0 === a.indexOf("<option") && (o = "select");
                      var d = r.createElement(o);
                      d.innerHTML = a;
                      for (var u = 0; u < d.childNodes.length; u += 1) i.push(d.childNodes[u]);
                  } else
                      i = (function (e, t) {
                          if ("string" != typeof e) return [e];
                          for (var n = [], r = t.querySelectorAll(e), i = 0; i < r.length; i += 1) n.push(r[i]);
                          return n;
                      })(e.trim(), t || r);
              } else if (e.nodeType || e === n || e === r) i.push(e);
              else if (Array.isArray(e)) {
                  if (e instanceof h) return e;
                  i = e;
              }
              return new h(
                  (function (e) {
                      for (var t = [], n = 0; n < e.length; n += 1) -1 === t.indexOf(e[n]) && t.push(e[n]);
                      return t;
                  })(i)
              );
          }
          g.fn = h.prototype;
          var y,
              w,
              b,
              E = {
                  addClass: function () {
                      for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++) t[n] = arguments[n];
                      var r = m(
                          t.map(function (e) {
                              return e.split(" ");
                          })
                      );
                      return (
                          this.forEach(function (e) {
                              var t;
                              (t = e.classList).add.apply(t, r);
                          }),
                          this
                      );
                  },
                  removeClass: function () {
                      for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++) t[n] = arguments[n];
                      var r = m(
                          t.map(function (e) {
                              return e.split(" ");
                          })
                      );
                      return (
                          this.forEach(function (e) {
                              var t;
                              (t = e.classList).remove.apply(t, r);
                          }),
                          this
                      );
                  },
                  hasClass: function () {
                      for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++) t[n] = arguments[n];
                      var r = m(
                          t.map(function (e) {
                              return e.split(" ");
                          })
                      );
                      return (
                          v(this, function (e) {
                              return (
                                  r.filter(function (t) {
                                      return e.classList.contains(t);
                                  }).length > 0
                              );
                          }).length > 0
                      );
                  },
                  toggleClass: function () {
                      for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++) t[n] = arguments[n];
                      var r = m(
                          t.map(function (e) {
                              return e.split(" ");
                          })
                      );
                      this.forEach(function (e) {
                          r.forEach(function (t) {
                              e.classList.toggle(t);
                          });
                      });
                  },
                  attr: function (e, t) {
                      if (1 === arguments.length && "string" == typeof e) return this[0] ? this[0].getAttribute(e) : void 0;
                      for (var n = 0; n < this.length; n += 1)
                          if (2 === arguments.length) this[n].setAttribute(e, t);
                          else for (var r in e) (this[n][r] = e[r]), this[n].setAttribute(r, e[r]);
                      return this;
                  },
                  removeAttr: function (e) {
                      for (var t = 0; t < this.length; t += 1) this[t].removeAttribute(e);
                      return this;
                  },
                  transform: function (e) {
                      for (var t = 0; t < this.length; t += 1) this[t].style.transform = e;
                      return this;
                  },
                  transition: function (e) {
                      for (var t = 0; t < this.length; t += 1) this[t].style.transitionDuration = "string" != typeof e ? e + "ms" : e;
                      return this;
                  },
                  on: function () {
                      for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++) t[n] = arguments[n];
                      var r = t[0],
                          i = t[1],
                          a = t[2],
                          s = t[3];
                      function o(e) {
                          var t = e.target;
                          if (t) {
                              var n = e.target.dom7EventData || [];
                              if ((n.indexOf(e) < 0 && n.unshift(e), g(t).is(i))) a.apply(t, n);
                              else for (var r = g(t).parents(), s = 0; s < r.length; s += 1) g(r[s]).is(i) && a.apply(r[s], n);
                          }
                      }
                      function l(e) {
                          var t = (e && e.target && e.target.dom7EventData) || [];
                          t.indexOf(e) < 0 && t.unshift(e), a.apply(this, t);
                      }
                      "function" == typeof t[1] && ((r = t[0]), (a = t[1]), (s = t[2]), (i = void 0)), s || (s = !1);
                      for (var d, u = r.split(" "), c = 0; c < this.length; c += 1) {
                          var p = this[c];
                          if (i)
                              for (d = 0; d < u.length; d += 1) {
                                  var f = u[d];
                                  p.dom7LiveListeners || (p.dom7LiveListeners = {}), p.dom7LiveListeners[f] || (p.dom7LiveListeners[f] = []), p.dom7LiveListeners[f].push({ listener: a, proxyListener: o }), p.addEventListener(f, o, s);
                              }
                          else
                              for (d = 0; d < u.length; d += 1) {
                                  var h = u[d];
                                  p.dom7Listeners || (p.dom7Listeners = {}), p.dom7Listeners[h] || (p.dom7Listeners[h] = []), p.dom7Listeners[h].push({ listener: a, proxyListener: l }), p.addEventListener(h, l, s);
                              }
                      }
                      return this;
                  },
                  off: function () {
                      for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++) t[n] = arguments[n];
                      var r = t[0],
                          i = t[1],
                          a = t[2],
                          s = t[3];
                      "function" == typeof t[1] && ((r = t[0]), (a = t[1]), (s = t[2]), (i = void 0)), s || (s = !1);
                      for (var o = r.split(" "), l = 0; l < o.length; l += 1)
                          for (var d = o[l], u = 0; u < this.length; u += 1) {
                              var c = this[u],
                                  p = void 0;
                              if ((!i && c.dom7Listeners ? (p = c.dom7Listeners[d]) : i && c.dom7LiveListeners && (p = c.dom7LiveListeners[d]), p && p.length))
                                  for (var f = p.length - 1; f >= 0; f -= 1) {
                                      var h = p[f];
                                      (a && h.listener === a) || (a && h.listener && h.listener.dom7proxy && h.listener.dom7proxy === a)
                                          ? (c.removeEventListener(d, h.proxyListener, s), p.splice(f, 1))
                                          : a || (c.removeEventListener(d, h.proxyListener, s), p.splice(f, 1));
                                  }
                          }
                      return this;
                  },
                  trigger: function () {
                      for (var e = l(), t = arguments.length, n = new Array(t), r = 0; r < t; r++) n[r] = arguments[r];
                      for (var i = n[0].split(" "), a = n[1], s = 0; s < i.length; s += 1)
                          for (var o = i[s], d = 0; d < this.length; d += 1) {
                              var u = this[d];
                              if (e.CustomEvent) {
                                  var c = new e.CustomEvent(o, { detail: a, bubbles: !0, cancelable: !0 });
                                  (u.dom7EventData = n.filter(function (e, t) {
                                      return t > 0;
                                  })),
                                      u.dispatchEvent(c),
                                      (u.dom7EventData = []),
                                      delete u.dom7EventData;
                              }
                          }
                      return this;
                  },
                  transitionEnd: function (e) {
                      var t = this;
                      return (
                          e &&
                              t.on("transitionend", function n(r) {
                                  r.target === this && (e.call(this, r), t.off("transitionend", n));
                              }),
                          this
                      );
                  },
                  outerWidth: function (e) {
                      if (this.length > 0) {
                          if (e) {
                              var t = this.styles();
                              return this[0].offsetWidth + parseFloat(t.getPropertyValue("margin-right")) + parseFloat(t.getPropertyValue("margin-left"));
                          }
                          return this[0].offsetWidth;
                      }
                      return null;
                  },
                  outerHeight: function (e) {
                      if (this.length > 0) {
                          if (e) {
                              var t = this.styles();
                              return this[0].offsetHeight + parseFloat(t.getPropertyValue("margin-top")) + parseFloat(t.getPropertyValue("margin-bottom"));
                          }
                          return this[0].offsetHeight;
                      }
                      return null;
                  },
                  styles: function () {
                      var e = l();
                      return this[0] ? e.getComputedStyle(this[0], null) : {};
                  },
                  offset: function () {
                      if (this.length > 0) {
                          var e = l(),
                              t = s(),
                              n = this[0],
                              r = n.getBoundingClientRect(),
                              i = t.body,
                              a = n.clientTop || i.clientTop || 0,
                              o = n.clientLeft || i.clientLeft || 0,
                              d = n === e ? e.scrollY : n.scrollTop,
                              u = n === e ? e.scrollX : n.scrollLeft;
                          return { top: r.top + d - a, left: r.left + u - o };
                      }
                      return null;
                  },
                  css: function (e, t) {
                      var n,
                          r = l();
                      if (1 === arguments.length) {
                          if ("string" != typeof e) {
                              for (n = 0; n < this.length; n += 1) for (var i in e) this[n].style[i] = e[i];
                              return this;
                          }
                          if (this[0]) return r.getComputedStyle(this[0], null).getPropertyValue(e);
                      }
                      if (2 === arguments.length && "string" == typeof e) {
                          for (n = 0; n < this.length; n += 1) this[n].style[e] = t;
                          return this;
                      }
                      return this;
                  },
                  each: function (e) {
                      return e
                          ? (this.forEach(function (t, n) {
                                e.apply(t, [t, n]);
                            }),
                            this)
                          : this;
                  },
                  html: function (e) {
                      if (void 0 === e) return this[0] ? this[0].innerHTML : null;
                      for (var t = 0; t < this.length; t += 1) this[t].innerHTML = e;
                      return this;
                  },
                  text: function (e) {
                      if (void 0 === e) return this[0] ? this[0].textContent.trim() : null;
                      for (var t = 0; t < this.length; t += 1) this[t].textContent = e;
                      return this;
                  },
                  is: function (e) {
                      var t,
                          n,
                          r = l(),
                          i = s(),
                          a = this[0];
                      if (!a || void 0 === e) return !1;
                      if ("string" == typeof e) {
                          if (a.matches) return a.matches(e);
                          if (a.webkitMatchesSelector) return a.webkitMatchesSelector(e);
                          if (a.msMatchesSelector) return a.msMatchesSelector(e);
                          for (t = g(e), n = 0; n < t.length; n += 1) if (t[n] === a) return !0;
                          return !1;
                      }
                      if (e === i) return a === i;
                      if (e === r) return a === r;
                      if (e.nodeType || e instanceof h) {
                          for (t = e.nodeType ? [e] : e, n = 0; n < t.length; n += 1) if (t[n] === a) return !0;
                          return !1;
                      }
                      return !1;
                  },
                  index: function () {
                      var e,
                          t = this[0];
                      if (t) {
                          for (e = 0; null !== (t = t.previousSibling); ) 1 === t.nodeType && (e += 1);
                          return e;
                      }
                  },
                  eq: function (e) {
                      if (void 0 === e) return this;
                      var t = this.length;
                      if (e > t - 1) return g([]);
                      if (e < 0) {
                          var n = t + e;
                          return g(n < 0 ? [] : [this[n]]);
                      }
                      return g([this[e]]);
                  },
                  append: function () {
                      for (var e, t = s(), n = 0; n < arguments.length; n += 1) {
                          e = n < 0 || arguments.length <= n ? void 0 : arguments[n];
                          for (var r = 0; r < this.length; r += 1)
                              if ("string" == typeof e) {
                                  var i = t.createElement("div");
                                  for (i.innerHTML = e; i.firstChild; ) this[r].appendChild(i.firstChild);
                              } else if (e instanceof h) for (var a = 0; a < e.length; a += 1) this[r].appendChild(e[a]);
                              else this[r].appendChild(e);
                      }
                      return this;
                  },
                  prepend: function (e) {
                      var t,
                          n,
                          r = s();
                      for (t = 0; t < this.length; t += 1)
                          if ("string" == typeof e) {
                              var i = r.createElement("div");
                              for (i.innerHTML = e, n = i.childNodes.length - 1; n >= 0; n -= 1) this[t].insertBefore(i.childNodes[n], this[t].childNodes[0]);
                          } else if (e instanceof h) for (n = 0; n < e.length; n += 1) this[t].insertBefore(e[n], this[t].childNodes[0]);
                          else this[t].insertBefore(e, this[t].childNodes[0]);
                      return this;
                  },
                  next: function (e) {
                      return this.length > 0
                          ? e
                              ? this[0].nextElementSibling && g(this[0].nextElementSibling).is(e)
                                  ? g([this[0].nextElementSibling])
                                  : g([])
                              : this[0].nextElementSibling
                              ? g([this[0].nextElementSibling])
                              : g([])
                          : g([]);
                  },
                  nextAll: function (e) {
                      var t = [],
                          n = this[0];
                      if (!n) return g([]);
                      for (; n.nextElementSibling; ) {
                          var r = n.nextElementSibling;
                          e ? g(r).is(e) && t.push(r) : t.push(r), (n = r);
                      }
                      return g(t);
                  },
                  prev: function (e) {
                      if (this.length > 0) {
                          var t = this[0];
                          return e ? (t.previousElementSibling && g(t.previousElementSibling).is(e) ? g([t.previousElementSibling]) : g([])) : t.previousElementSibling ? g([t.previousElementSibling]) : g([]);
                      }
                      return g([]);
                  },
                  prevAll: function (e) {
                      var t = [],
                          n = this[0];
                      if (!n) return g([]);
                      for (; n.previousElementSibling; ) {
                          var r = n.previousElementSibling;
                          e ? g(r).is(e) && t.push(r) : t.push(r), (n = r);
                      }
                      return g(t);
                  },
                  parent: function (e) {
                      for (var t = [], n = 0; n < this.length; n += 1) null !== this[n].parentNode && (e ? g(this[n].parentNode).is(e) && t.push(this[n].parentNode) : t.push(this[n].parentNode));
                      return g(t);
                  },
                  parents: function (e) {
                      for (var t = [], n = 0; n < this.length; n += 1) for (var r = this[n].parentNode; r; ) e ? g(r).is(e) && t.push(r) : t.push(r), (r = r.parentNode);
                      return g(t);
                  },
                  closest: function (e) {
                      var t = this;
                      return void 0 === e ? g([]) : (t.is(e) || (t = t.parents(e).eq(0)), t);
                  },
                  find: function (e) {
                      for (var t = [], n = 0; n < this.length; n += 1) for (var r = this[n].querySelectorAll(e), i = 0; i < r.length; i += 1) t.push(r[i]);
                      return g(t);
                  },
                  children: function (e) {
                      for (var t = [], n = 0; n < this.length; n += 1) for (var r = this[n].children, i = 0; i < r.length; i += 1) (e && !g(r[i]).is(e)) || t.push(r[i]);
                      return g(t);
                  },
                  filter: function (e) {
                      return g(v(this, e));
                  },
                  remove: function () {
                      for (var e = 0; e < this.length; e += 1) this[e].parentNode && this[e].parentNode.removeChild(this[e]);
                      return this;
                  },
              };
          function x(e, t) {
              return void 0 === t && (t = 0), setTimeout(e, t);
          }
          function S() {
              return Date.now();
          }
          function T(e, t) {
              void 0 === t && (t = "x");
              var n,
                  r,
                  i,
                  a = l(),
                  s = a.getComputedStyle(e, null);
              return (
                  a.WebKitCSSMatrix
                      ? ((r = s.transform || s.webkitTransform).split(",").length > 6 &&
                            (r = r
                                .split(", ")
                                .map(function (e) {
                                    return e.replace(",", ".");
                                })
                                .join(", ")),
                        (i = new a.WebKitCSSMatrix("none" === r ? "" : r)))
                      : (n = (i = s.MozTransform || s.OTransform || s.MsTransform || s.msTransform || s.transform || s.getPropertyValue("transform").replace("translate(", "matrix(1, 0, 0, 1,")).toString().split(",")),
                  "x" === t && (r = a.WebKitCSSMatrix ? i.m41 : 16 === n.length ? parseFloat(n[12]) : parseFloat(n[4])),
                  "y" === t && (r = a.WebKitCSSMatrix ? i.m42 : 16 === n.length ? parseFloat(n[13]) : parseFloat(n[5])),
                  r || 0
              );
          }
          function _(e) {
              return "object" == (0, a.default)(e) && null !== e && e.constructor && e.constructor === Object;
          }
          function C() {
              for (var e = Object(arguments.length <= 0 ? void 0 : arguments[0]), t = 1; t < arguments.length; t += 1) {
                  var n = t < 0 || arguments.length <= t ? void 0 : arguments[t];
                  if (null != n)
                      for (var r = Object.keys(Object(n)), i = 0, a = r.length; i < a; i += 1) {
                          var s = r[i],
                              o = Object.getOwnPropertyDescriptor(n, s);
                          void 0 !== o && o.enumerable && (_(e[s]) && _(n[s]) ? C(e[s], n[s]) : !_(e[s]) && _(n[s]) ? ((e[s] = {}), C(e[s], n[s])) : (e[s] = n[s]));
                      }
              }
              return e;
          }
          function M(e, t) {
              Object.keys(t).forEach(function (n) {
                  _(t[n]) &&
                      Object.keys(t[n]).forEach(function (r) {
                          "function" == typeof t[n][r] && (t[n][r] = t[n][r].bind(e));
                      }),
                      (e[n] = t[n]);
              });
          }
          function P() {
              return (
                  y ||
                      (y = (function () {
                          var e = l(),
                              t = s();
                          return {
                              touch: !!("ontouchstart" in e || (e.DocumentTouch && t instanceof e.DocumentTouch)),
                              pointerEvents: !!e.PointerEvent && "maxTouchPoints" in e.navigator && e.navigator.maxTouchPoints >= 0,
                              observer: "MutationObserver" in e || "WebkitMutationObserver" in e,
                              passiveListener: (function () {
                                  var t = !1;
                                  try {
                                      var n = Object.defineProperty({}, "passive", {
                                          get: function () {
                                              t = !0;
                                          },
                                      });
                                      e.addEventListener("testPassiveListener", null, n);
                                  } catch (e) {}
                                  return t;
                              })(),
                              gestures: "ongesturestart" in e,
                          };
                      })()),
                  y
              );
          }
          function L(e) {
              return (
                  void 0 === e && (e = {}),
                  w ||
                      (w = (function (e) {
                          var t = (void 0 === e ? {} : e).userAgent,
                              n = P(),
                              r = l(),
                              i = r.navigator.platform,
                              a = t || r.navigator.userAgent,
                              s = { ios: !1, android: !1 },
                              o = r.screen.width,
                              d = r.screen.height,
                              u = a.match(/(Android);?[\s\/]+([\d.]+)?/),
                              c = a.match(/(iPad).*OS\s([\d_]+)/),
                              p = a.match(/(iPod)(.*OS\s([\d_]+))?/),
                              f = !c && a.match(/(iPhone\sOS|iOS)\s([\d_]+)/),
                              h = "Win32" === i,
                              m = "MacIntel" === i;
                          return (
                              !c &&
                                  m &&
                                  n.touch &&
                                  ["1024x1366", "1366x1024", "834x1194", "1194x834", "834x1112", "1112x834", "768x1024", "1024x768", "820x1180", "1180x820", "810x1080", "1080x810"].indexOf(o + "x" + d) >= 0 &&
                                  ((c = a.match(/(Version)\/([\d.]+)/)) || (c = [0, 1, "13_0_0"]), (m = !1)),
                              u && !h && ((s.os = "android"), (s.android = !0)),
                              (c || f || p) && ((s.os = "ios"), (s.ios = !0)),
                              s
                          );
                      })(e)),
                  w
              );
          }
          function A() {
              return (
                  b ||
                      (b = (function () {
                          var e,
                              t = l();
                          return {
                              isEdge: !!t.navigator.userAgent.match(/Edge/g),
                              isSafari: ((e = t.navigator.userAgent.toLowerCase()), e.indexOf("safari") >= 0 && e.indexOf("chrome") < 0 && e.indexOf("android") < 0),
                              isWebView: /(iPhone|iPod|iPad).*AppleWebKit(?!.*Safari)/i.test(t.navigator.userAgent),
                          };
                      })()),
                  b
              );
          }
          Object.keys(E).forEach(function (e) {
              g.fn[e] = E[e];
          });
          var k = {
                  name: "resize",
                  create: function () {
                      var e = this;
                      C(e, {
                          resize: {
                              resizeHandler: function () {
                                  e && !e.destroyed && e.initialized && (e.emit("beforeResize"), e.emit("resize"));
                              },
                              orientationChangeHandler: function () {
                                  e && !e.destroyed && e.initialized && e.emit("orientationchange");
                              },
                          },
                      });
                  },
                  on: {
                      init: function (e) {
                          var t = l();
                          t.addEventListener("resize", e.resize.resizeHandler), t.addEventListener("orientationchange", e.resize.orientationChangeHandler);
                      },
                      destroy: function (e) {
                          var t = l();
                          t.removeEventListener("resize", e.resize.resizeHandler), t.removeEventListener("orientationchange", e.resize.orientationChangeHandler);
                      },
                  },
              },
              z = {
                  attach: function (e, t) {
                      void 0 === t && (t = {});
                      var n = l(),
                          r = this,
                          i = new (n.MutationObserver || n.WebkitMutationObserver)(function (e) {
                              if (1 !== e.length) {
                                  var t = function () {
                                      r.emit("observerUpdate", e[0]);
                                  };
                                  n.requestAnimationFrame ? n.requestAnimationFrame(t) : n.setTimeout(t, 0);
                              } else r.emit("observerUpdate", e[0]);
                          });
                      i.observe(e, { attributes: void 0 === t.attributes || t.attributes, childList: void 0 === t.childList || t.childList, characterData: void 0 === t.characterData || t.characterData }), r.observer.observers.push(i);
                  },
                  init: function () {
                      var e = this;
                      if (e.support.observer && e.params.observer) {
                          if (e.params.observeParents) for (var t = e.$el.parents(), n = 0; n < t.length; n += 1) e.observer.attach(t[n]);
                          e.observer.attach(e.$el[0], { childList: e.params.observeSlideChildren }), e.observer.attach(e.$wrapperEl[0], { attributes: !1 });
                      }
                  },
                  destroy: function () {
                      this.observer.observers.forEach(function (e) {
                          e.disconnect();
                      }),
                          (this.observer.observers = []);
                  },
              },
              I = {
                  name: "observer",
                  params: { observer: !1, observeParents: !1, observeSlideChildren: !1 },
                  create: function () {
                      M(this, { observer: t({}, z, { observers: [] }) });
                  },
                  on: {
                      init: function (e) {
                          e.observer.init();
                      },
                      destroy: function (e) {
                          e.observer.destroy();
                      },
                  },
              };
          function O(e) {
              var t = this,
                  n = s(),
                  r = l(),
                  i = t.touchEventsData,
                  a = t.params,
                  o = t.touches;
              if (!t.animating || !a.preventInteractionOnTransition) {
                  var d = e;
                  d.originalEvent && (d = d.originalEvent);
                  var u = g(d.target);
                  if (
                      ("wrapper" !== a.touchEventsTarget || u.closest(t.wrapperEl).length) &&
                      ((i.isTouchEvent = "touchstart" === d.type), (i.isTouchEvent || !("which" in d) || 3 !== d.which) && !((!i.isTouchEvent && "button" in d && d.button > 0) || (i.isTouched && i.isMoved)))
                  )
                      if (
                          (!!a.noSwipingClass && "" !== a.noSwipingClass && d.target && d.target.shadowRoot && e.path && e.path[0] && (u = g(e.path[0])),
                          a.noSwiping && u.closest(a.noSwipingSelector ? a.noSwipingSelector : "." + a.noSwipingClass)[0])
                      )
                          t.allowClick = !0;
                      else if (!a.swipeHandler || u.closest(a.swipeHandler)[0]) {
                          (o.currentX = "touchstart" === d.type ? d.targetTouches[0].pageX : d.pageX), (o.currentY = "touchstart" === d.type ? d.targetTouches[0].pageY : d.pageY);
                          var c = o.currentX,
                              p = o.currentY,
                              f = a.edgeSwipeDetection || a.iOSEdgeSwipeDetection,
                              h = a.edgeSwipeThreshold || a.iOSEdgeSwipeThreshold;
                          if (f && (c <= h || c >= r.innerWidth - h)) {
                              if ("prevent" !== f) return;
                              e.preventDefault();
                          }
                          if (
                              (C(i, { isTouched: !0, isMoved: !1, allowTouchCallbacks: !0, isScrolling: void 0, startMoving: void 0 }),
                              (o.startX = c),
                              (o.startY = p),
                              (i.touchStartTime = S()),
                              (t.allowClick = !0),
                              t.updateSize(),
                              (t.swipeDirection = void 0),
                              a.threshold > 0 && (i.allowThresholdMove = !1),
                              "touchstart" !== d.type)
                          ) {
                              var m = !0;
                              u.is(i.formElements) && (m = !1), n.activeElement && g(n.activeElement).is(i.formElements) && n.activeElement !== u[0] && n.activeElement.blur();
                              var v = m && t.allowTouchMove && a.touchStartPreventDefault;
                              (!a.touchStartForcePreventDefault && !v) || u[0].isContentEditable || d.preventDefault();
                          }
                          t.emit("touchStart", d);
                      }
              }
          }
          function D(e) {
              var t = s(),
                  n = this,
                  r = n.touchEventsData,
                  i = n.params,
                  a = n.touches,
                  o = n.rtlTranslate,
                  l = e;
              if ((l.originalEvent && (l = l.originalEvent), r.isTouched)) {
                  if (!r.isTouchEvent || "touchmove" === l.type) {
                      var d = "touchmove" === l.type && l.targetTouches && (l.targetTouches[0] || l.changedTouches[0]),
                          u = "touchmove" === l.type ? d.pageX : l.pageX,
                          c = "touchmove" === l.type ? d.pageY : l.pageY;
                      if (l.preventedByNestedSwiper) return (a.startX = u), void (a.startY = c);
                      if (!n.allowTouchMove) return (n.allowClick = !1), void (r.isTouched && (C(a, { startX: u, startY: c, currentX: u, currentY: c }), (r.touchStartTime = S())));
                      if (r.isTouchEvent && i.touchReleaseOnEdges && !i.loop)
                          if (n.isVertical()) {
                              if ((c < a.startY && n.translate <= n.maxTranslate()) || (c > a.startY && n.translate >= n.minTranslate())) return (r.isTouched = !1), void (r.isMoved = !1);
                          } else if ((u < a.startX && n.translate <= n.maxTranslate()) || (u > a.startX && n.translate >= n.minTranslate())) return;
                      if (r.isTouchEvent && t.activeElement && l.target === t.activeElement && g(l.target).is(r.formElements)) return (r.isMoved = !0), void (n.allowClick = !1);
                      if ((r.allowTouchCallbacks && n.emit("touchMove", l), !(l.targetTouches && l.targetTouches.length > 1))) {
                          (a.currentX = u), (a.currentY = c);
                          var p,
                              f = a.currentX - a.startX,
                              h = a.currentY - a.startY;
                          if (!(n.params.threshold && Math.sqrt(Math.pow(f, 2) + Math.pow(h, 2)) < n.params.threshold))
                              if (
                                  (void 0 === r.isScrolling &&
                                      ((n.isHorizontal() && a.currentY === a.startY) || (n.isVertical() && a.currentX === a.startX)
                                          ? (r.isScrolling = !1)
                                          : f * f + h * h >= 25 && ((p = (180 * Math.atan2(Math.abs(h), Math.abs(f))) / Math.PI), (r.isScrolling = n.isHorizontal() ? p > i.touchAngle : 90 - p > i.touchAngle))),
                                  r.isScrolling && n.emit("touchMoveOpposite", l),
                                  void 0 === r.startMoving && ((a.currentX === a.startX && a.currentY === a.startY) || (r.startMoving = !0)),
                                  r.isScrolling)
                              )
                                  r.isTouched = !1;
                              else if (r.startMoving) {
                                  (n.allowClick = !1),
                                      !i.cssMode && l.cancelable && l.preventDefault(),
                                      i.touchMoveStopPropagation && !i.nested && l.stopPropagation(),
                                      r.isMoved ||
                                          (i.loop && n.loopFix(),
                                          (r.startTranslate = n.getTranslate()),
                                          n.setTransition(0),
                                          n.animating && n.$wrapperEl.trigger("webkitTransitionEnd transitionend"),
                                          (r.allowMomentumBounce = !1),
                                          !i.grabCursor || (!0 !== n.allowSlideNext && !0 !== n.allowSlidePrev) || n.setGrabCursor(!0),
                                          n.emit("sliderFirstMove", l)),
                                      n.emit("sliderMove", l),
                                      (r.isMoved = !0);
                                  var m = n.isHorizontal() ? f : h;
                                  (a.diff = m), (m *= i.touchRatio), o && (m = -m), (n.swipeDirection = m > 0 ? "prev" : "next"), (r.currentTranslate = m + r.startTranslate);
                                  var v = !0,
                                      y = i.resistanceRatio;
                                  if (
                                      (i.touchReleaseOnEdges && (y = 0),
                                      m > 0 && r.currentTranslate > n.minTranslate()
                                          ? ((v = !1), i.resistance && (r.currentTranslate = n.minTranslate() - 1 + Math.pow(-n.minTranslate() + r.startTranslate + m, y)))
                                          : m < 0 && r.currentTranslate < n.maxTranslate() && ((v = !1), i.resistance && (r.currentTranslate = n.maxTranslate() + 1 - Math.pow(n.maxTranslate() - r.startTranslate - m, y))),
                                      v && (l.preventedByNestedSwiper = !0),
                                      !n.allowSlideNext && "next" === n.swipeDirection && r.currentTranslate < r.startTranslate && (r.currentTranslate = r.startTranslate),
                                      !n.allowSlidePrev && "prev" === n.swipeDirection && r.currentTranslate > r.startTranslate && (r.currentTranslate = r.startTranslate),
                                      i.threshold > 0)
                                  ) {
                                      if (!(Math.abs(m) > i.threshold || r.allowThresholdMove)) return void (r.currentTranslate = r.startTranslate);
                                      if (!r.allowThresholdMove)
                                          return (
                                              (r.allowThresholdMove = !0),
                                              (a.startX = a.currentX),
                                              (a.startY = a.currentY),
                                              (r.currentTranslate = r.startTranslate),
                                              void (a.diff = n.isHorizontal() ? a.currentX - a.startX : a.currentY - a.startY)
                                          );
                                  }
                                  i.followFinger &&
                                      !i.cssMode &&
                                      ((i.freeMode || i.watchSlidesProgress || i.watchSlidesVisibility) && (n.updateActiveIndex(), n.updateSlidesClasses()),
                                      i.freeMode &&
                                          (0 === r.velocities.length && r.velocities.push({ position: a[n.isHorizontal() ? "startX" : "startY"], time: r.touchStartTime }),
                                          r.velocities.push({ position: a[n.isHorizontal() ? "currentX" : "currentY"], time: S() })),
                                      n.updateProgress(r.currentTranslate),
                                      n.setTranslate(r.currentTranslate));
                              }
                      }
                  }
              } else r.startMoving && r.isScrolling && n.emit("touchMoveOpposite", l);
          }
          function $(e) {
              var t = this,
                  n = t.touchEventsData,
                  r = t.params,
                  i = t.touches,
                  a = t.rtlTranslate,
                  s = t.$wrapperEl,
                  o = t.slidesGrid,
                  l = t.snapGrid,
                  d = e;
              if ((d.originalEvent && (d = d.originalEvent), n.allowTouchCallbacks && t.emit("touchEnd", d), (n.allowTouchCallbacks = !1), !n.isTouched))
                  return n.isMoved && r.grabCursor && t.setGrabCursor(!1), (n.isMoved = !1), void (n.startMoving = !1);
              r.grabCursor && n.isMoved && n.isTouched && (!0 === t.allowSlideNext || !0 === t.allowSlidePrev) && t.setGrabCursor(!1);
              var u,
                  c = S(),
                  p = c - n.touchStartTime;
              if (
                  (t.allowClick && (t.updateClickedSlide(d), t.emit("tap click", d), p < 300 && c - n.lastClickTime < 300 && t.emit("doubleTap doubleClick", d)),
                  (n.lastClickTime = S()),
                  x(function () {
                      t.destroyed || (t.allowClick = !0);
                  }),
                  !n.isTouched || !n.isMoved || !t.swipeDirection || 0 === i.diff || n.currentTranslate === n.startTranslate)
              )
                  return (n.isTouched = !1), (n.isMoved = !1), void (n.startMoving = !1);
              if (((n.isTouched = !1), (n.isMoved = !1), (n.startMoving = !1), (u = r.followFinger ? (a ? t.translate : -t.translate) : -n.currentTranslate), !r.cssMode))
                  if (r.freeMode) {
                      if (u < -t.minTranslate()) return void t.slideTo(t.activeIndex);
                      if (u > -t.maxTranslate()) return void (t.slides.length < l.length ? t.slideTo(l.length - 1) : t.slideTo(t.slides.length - 1));
                      if (r.freeModeMomentum) {
                          if (n.velocities.length > 1) {
                              var f = n.velocities.pop(),
                                  h = n.velocities.pop(),
                                  m = f.position - h.position,
                                  v = f.time - h.time;
                              (t.velocity = m / v), (t.velocity /= 2), Math.abs(t.velocity) < r.freeModeMinimumVelocity && (t.velocity = 0), (v > 150 || S() - f.time > 300) && (t.velocity = 0);
                          } else t.velocity = 0;
                          (t.velocity *= r.freeModeMomentumVelocityRatio), (n.velocities.length = 0);
                          var g = 1e3 * r.freeModeMomentumRatio,
                              y = t.velocity * g,
                              w = t.translate + y;
                          a && (w = -w);
                          var b,
                              E,
                              T = !1,
                              _ = 20 * Math.abs(t.velocity) * r.freeModeMomentumBounceRatio;
                          if (w < t.maxTranslate())
                              r.freeModeMomentumBounce ? (w + t.maxTranslate() < -_ && (w = t.maxTranslate() - _), (b = t.maxTranslate()), (T = !0), (n.allowMomentumBounce = !0)) : (w = t.maxTranslate()),
                                  r.loop && r.centeredSlides && (E = !0);
                          else if (w > t.minTranslate())
                              r.freeModeMomentumBounce ? (w - t.minTranslate() > _ && (w = t.minTranslate() + _), (b = t.minTranslate()), (T = !0), (n.allowMomentumBounce = !0)) : (w = t.minTranslate()),
                                  r.loop && r.centeredSlides && (E = !0);
                          else if (r.freeModeSticky) {
                              for (var C, M = 0; M < l.length; M += 1)
                                  if (l[M] > -w) {
                                      C = M;
                                      break;
                                  }
                              w = -(w = Math.abs(l[C] - w) < Math.abs(l[C - 1] - w) || "next" === t.swipeDirection ? l[C] : l[C - 1]);
                          }
                          if (
                              (E &&
                                  t.once("transitionEnd", function () {
                                      t.loopFix();
                                  }),
                              0 !== t.velocity)
                          ) {
                              if (((g = a ? Math.abs((-w - t.translate) / t.velocity) : Math.abs((w - t.translate) / t.velocity)), r.freeModeSticky)) {
                                  var P = Math.abs((a ? -w : w) - t.translate),
                                      L = t.slidesSizesGrid[t.activeIndex];
                                  g = P < L ? r.speed : P < 2 * L ? 1.5 * r.speed : 2.5 * r.speed;
                              }
                          } else if (r.freeModeSticky) return void t.slideToClosest();
                          r.freeModeMomentumBounce && T
                              ? (t.updateProgress(b),
                                t.setTransition(g),
                                t.setTranslate(w),
                                t.transitionStart(!0, t.swipeDirection),
                                (t.animating = !0),
                                s.transitionEnd(function () {
                                    t &&
                                        !t.destroyed &&
                                        n.allowMomentumBounce &&
                                        (t.emit("momentumBounce"),
                                        t.setTransition(r.speed),
                                        setTimeout(function () {
                                            t.setTranslate(b),
                                                s.transitionEnd(function () {
                                                    t && !t.destroyed && t.transitionEnd();
                                                });
                                        }, 0));
                                }))
                              : t.velocity
                              ? (t.updateProgress(w),
                                t.setTransition(g),
                                t.setTranslate(w),
                                t.transitionStart(!0, t.swipeDirection),
                                t.animating ||
                                    ((t.animating = !0),
                                    s.transitionEnd(function () {
                                        t && !t.destroyed && t.transitionEnd();
                                    })))
                              : t.updateProgress(w),
                              t.updateActiveIndex(),
                              t.updateSlidesClasses();
                      } else if (r.freeModeSticky) return void t.slideToClosest();
                      (!r.freeModeMomentum || p >= r.longSwipesMs) && (t.updateProgress(), t.updateActiveIndex(), t.updateSlidesClasses());
                  } else {
                      for (var A = 0, k = t.slidesSizesGrid[0], z = 0; z < o.length; z += z < r.slidesPerGroupSkip ? 1 : r.slidesPerGroup) {
                          var I = z < r.slidesPerGroupSkip - 1 ? 1 : r.slidesPerGroup;
                          void 0 !== o[z + I] ? u >= o[z] && u < o[z + I] && ((A = z), (k = o[z + I] - o[z])) : u >= o[z] && ((A = z), (k = o[o.length - 1] - o[o.length - 2]));
                      }
                      var O = (u - o[A]) / k,
                          D = A < r.slidesPerGroupSkip - 1 ? 1 : r.slidesPerGroup;
                      if (p > r.longSwipesMs) {
                          if (!r.longSwipes) return void t.slideTo(t.activeIndex);
                          "next" === t.swipeDirection && (O >= r.longSwipesRatio ? t.slideTo(A + D) : t.slideTo(A)), "prev" === t.swipeDirection && (O > 1 - r.longSwipesRatio ? t.slideTo(A + D) : t.slideTo(A));
                      } else {
                          if (!r.shortSwipes) return void t.slideTo(t.activeIndex);
                          !t.navigation || (d.target !== t.navigation.nextEl && d.target !== t.navigation.prevEl)
                              ? ("next" === t.swipeDirection && t.slideTo(A + D), "prev" === t.swipeDirection && t.slideTo(A))
                              : d.target === t.navigation.nextEl
                              ? t.slideTo(A + D)
                              : t.slideTo(A);
                      }
                  }
          }
          function B() {
              var e = this,
                  t = e.params,
                  n = e.el;
              if (!n || 0 !== n.offsetWidth) {
                  t.breakpoints && e.setBreakpoint();
                  var r = e.allowSlideNext,
                      i = e.allowSlidePrev,
                      a = e.snapGrid;
                  (e.allowSlideNext = !0),
                      (e.allowSlidePrev = !0),
                      e.updateSize(),
                      e.updateSlides(),
                      e.updateSlidesClasses(),
                      ("auto" === t.slidesPerView || t.slidesPerView > 1) && e.isEnd && !e.isBeginning && !e.params.centeredSlides ? e.slideTo(e.slides.length - 1, 0, !1, !0) : e.slideTo(e.activeIndex, 0, !1, !0),
                      e.autoplay && e.autoplay.running && e.autoplay.paused && e.autoplay.run(),
                      (e.allowSlidePrev = i),
                      (e.allowSlideNext = r),
                      e.params.watchOverflow && a !== e.snapGrid && e.checkOverflow();
              }
          }
          function q(e) {
              var t = this;
              t.allowClick || (t.params.preventClicks && e.preventDefault(), t.params.preventClicksPropagation && t.animating && (e.stopPropagation(), e.stopImmediatePropagation()));
          }
          function R() {
              var e = this,
                  t = e.wrapperEl,
                  n = e.rtlTranslate;
              (e.previousTranslate = e.translate),
                  e.isHorizontal() ? (e.translate = n ? t.scrollWidth - t.offsetWidth - t.scrollLeft : -t.scrollLeft) : (e.translate = -t.scrollTop),
                  -0 === e.translate && (e.translate = 0),
                  e.updateActiveIndex(),
                  e.updateSlidesClasses();
              var r = e.maxTranslate() - e.minTranslate();
              (0 === r ? 0 : (e.translate - e.minTranslate()) / r) !== e.progress && e.updateProgress(n ? -e.translate : e.translate), e.emit("setTranslate", e.translate, !1);
          }
          var F = !1;
          function H() {}
          var N = {
                  init: !0,
                  direction: "horizontal",
                  touchEventsTarget: "container",
                  initialSlide: 0,
                  speed: 300,
                  cssMode: !1,
                  updateOnWindowResize: !0,
                  nested: !1,
                  width: null,
                  height: null,
                  preventInteractionOnTransition: !1,
                  userAgent: null,
                  url: null,
                  edgeSwipeDetection: !1,
                  edgeSwipeThreshold: 20,
                  freeMode: !1,
                  freeModeMomentum: !0,
                  freeModeMomentumRatio: 1,
                  freeModeMomentumBounce: !0,
                  freeModeMomentumBounceRatio: 1,
                  freeModeMomentumVelocityRatio: 1,
                  freeModeSticky: !1,
                  freeModeMinimumVelocity: 0.02,
                  autoHeight: !1,
                  setWrapperSize: !1,
                  virtualTranslate: !1,
                  effect: "slide",
                  breakpoints: void 0,
                  spaceBetween: 0,
                  slidesPerView: 1,
                  slidesPerColumn: 1,
                  slidesPerColumnFill: "column",
                  slidesPerGroup: 1,
                  slidesPerGroupSkip: 0,
                  centeredSlides: !1,
                  centeredSlidesBounds: !1,
                  slidesOffsetBefore: 0,
                  slidesOffsetAfter: 0,
                  normalizeSlideIndex: !0,
                  centerInsufficientSlides: !1,
                  watchOverflow: !1,
                  roundLengths: !1,
                  touchRatio: 1,
                  touchAngle: 45,
                  simulateTouch: !0,
                  shortSwipes: !0,
                  longSwipes: !0,
                  longSwipesRatio: 0.5,
                  longSwipesMs: 300,
                  followFinger: !0,
                  allowTouchMove: !0,
                  threshold: 0,
                  touchMoveStopPropagation: !1,
                  touchStartPreventDefault: !0,
                  touchStartForcePreventDefault: !1,
                  touchReleaseOnEdges: !1,
                  uniqueNavElements: !0,
                  resistance: !0,
                  resistanceRatio: 0.85,
                  watchSlidesProgress: !1,
                  watchSlidesVisibility: !1,
                  grabCursor: !1,
                  preventClicks: !0,
                  preventClicksPropagation: !0,
                  slideToClickedSlide: !1,
                  preloadImages: !0,
                  updateOnImagesReady: !0,
                  loop: !1,
                  loopAdditionalSlides: 0,
                  loopedSlides: null,
                  loopFillGroupWithBlank: !1,
                  loopPreventsSlide: !0,
                  allowSlidePrev: !0,
                  allowSlideNext: !0,
                  swipeHandler: null,
                  noSwiping: !0,
                  noSwipingClass: "swiper-no-swiping",
                  noSwipingSelector: null,
                  passiveListeners: !0,
                  containerModifierClass: "swiper-container-",
                  slideClass: "swiper-slide",
                  slideBlankClass: "swiper-slide-invisible-blank",
                  slideActiveClass: "swiper-slide-active",
                  slideDuplicateActiveClass: "swiper-slide-duplicate-active",
                  slideVisibleClass: "swiper-slide-visible",
                  slideDuplicateClass: "swiper-slide-duplicate",
                  slideNextClass: "swiper-slide-next",
                  slideDuplicateNextClass: "swiper-slide-duplicate-next",
                  slidePrevClass: "swiper-slide-prev",
                  slideDuplicatePrevClass: "swiper-slide-duplicate-prev",
                  wrapperClass: "swiper-wrapper",
                  runCallbacksOnInit: !0,
                  _emitClasses: !1,
              },
              G = {
                  modular: {
                      useParams: function (e) {
                          var t = this;
                          t.modules &&
                              Object.keys(t.modules).forEach(function (n) {
                                  var r = t.modules[n];
                                  r.params && C(e, r.params);
                              });
                      },
                      useModules: function (e) {
                          void 0 === e && (e = {});
                          var t = this;
                          t.modules &&
                              Object.keys(t.modules).forEach(function (n) {
                                  var r = t.modules[n],
                                      i = e[n] || {};
                                  r.on &&
                                      t.on &&
                                      Object.keys(r.on).forEach(function (e) {
                                          t.on(e, r.on[e]);
                                      }),
                                      r.create && r.create.bind(t)(i);
                              });
                      },
                  },
                  eventsEmitter: {
                      on: function (e, t, n) {
                          var r = this;
                          if ("function" != typeof t) return r;
                          var i = n ? "unshift" : "push";
                          return (
                              e.split(" ").forEach(function (e) {
                                  r.eventsListeners[e] || (r.eventsListeners[e] = []), r.eventsListeners[e][i](t);
                              }),
                              r
                          );
                      },
                      once: function (e, t, n) {
                          var r = this;
                          if ("function" != typeof t) return r;
                          function i() {
                              r.off(e, i), i.__emitterProxy && delete i.__emitterProxy;
                              for (var n = arguments.length, a = new Array(n), s = 0; s < n; s++) a[s] = arguments[s];
                              t.apply(r, a);
                          }
                          return (i.__emitterProxy = t), r.on(e, i, n);
                      },
                      onAny: function (e, t) {
                          var n = this;
                          if ("function" != typeof e) return n;
                          var r = t ? "unshift" : "push";
                          return n.eventsAnyListeners.indexOf(e) < 0 && n.eventsAnyListeners[r](e), n;
                      },
                      offAny: function (e) {
                          var t = this;
                          if (!t.eventsAnyListeners) return t;
                          var n = t.eventsAnyListeners.indexOf(e);
                          return n >= 0 && t.eventsAnyListeners.splice(n, 1), t;
                      },
                      off: function (e, t) {
                          var n = this;
                          return n.eventsListeners
                              ? (e.split(" ").forEach(function (e) {
                                    void 0 === t
                                        ? (n.eventsListeners[e] = [])
                                        : n.eventsListeners[e] &&
                                          n.eventsListeners[e].forEach(function (r, i) {
                                              (r === t || (r.__emitterProxy && r.__emitterProxy === t)) && n.eventsListeners[e].splice(i, 1);
                                          });
                                }),
                                n)
                              : n;
                      },
                      emit: function () {
                          var e,
                              t,
                              n,
                              r = this;
                          if (!r.eventsListeners) return r;
                          for (var i = arguments.length, a = new Array(i), s = 0; s < i; s++) a[s] = arguments[s];
                          "string" == typeof a[0] || Array.isArray(a[0]) ? ((e = a[0]), (t = a.slice(1, a.length)), (n = r)) : ((e = a[0].events), (t = a[0].data), (n = a[0].context || r)), t.unshift(n);
                          var o = Array.isArray(e) ? e : e.split(" ");
                          return (
                              o.forEach(function (e) {
                                  r.eventsAnyListeners &&
                                      r.eventsAnyListeners.length &&
                                      r.eventsAnyListeners.forEach(function (r) {
                                          r.apply(n, [e].concat(t));
                                      }),
                                      r.eventsListeners &&
                                          r.eventsListeners[e] &&
                                          r.eventsListeners[e].forEach(function (e) {
                                              e.apply(n, t);
                                          });
                              }),
                              r
                          );
                      },
                  },
                  update: {
                      updateSize: function () {
                          var e,
                              t,
                              n = this,
                              r = n.$el;
                          (e = void 0 !== n.params.width && null !== n.params.width ? n.params.width : r[0].clientWidth),
                              (t = void 0 !== n.params.height && null !== n.params.height ? n.params.height : r[0].clientHeight),
                              (0 === e && n.isHorizontal()) ||
                                  (0 === t && n.isVertical()) ||
                                  ((e = e - parseInt(r.css("padding-left") || 0, 10) - parseInt(r.css("padding-right") || 0, 10)),
                                  (t = t - parseInt(r.css("padding-top") || 0, 10) - parseInt(r.css("padding-bottom") || 0, 10)),
                                  Number.isNaN(e) && (e = 0),
                                  Number.isNaN(t) && (t = 0),
                                  C(n, { width: e, height: t, size: n.isHorizontal() ? e : t }));
                      },
                      updateSlides: function () {
                          var e = this,
                              t = l(),
                              n = e.params,
                              r = e.$wrapperEl,
                              i = e.size,
                              a = e.rtlTranslate,
                              s = e.wrongRTL,
                              o = e.virtual && n.virtual.enabled,
                              d = o ? e.virtual.slides.length : e.slides.length,
                              u = r.children("." + e.params.slideClass),
                              c = o ? e.virtual.slides.length : u.length,
                              p = [],
                              f = [],
                              h = [];
                          function m(e, t) {
                              return !n.cssMode || t !== u.length - 1;
                          }
                          var v = n.slidesOffsetBefore;
                          "function" == typeof v && (v = n.slidesOffsetBefore.call(e));
                          var g = n.slidesOffsetAfter;
                          "function" == typeof g && (g = n.slidesOffsetAfter.call(e));
                          var y = e.snapGrid.length,
                              w = e.slidesGrid.length,
                              b = n.spaceBetween,
                              E = -v,
                              x = 0,
                              S = 0;
                          if (void 0 !== i) {
                              var T, _;
                              "string" == typeof b && b.indexOf("%") >= 0 && (b = (parseFloat(b.replace("%", "")) / 100) * i),
                                  (e.virtualSize = -b),
                                  a ? u.css({ marginLeft: "", marginTop: "" }) : u.css({ marginRight: "", marginBottom: "" }),
                                  n.slidesPerColumn > 1 &&
                                      ((T = Math.floor(c / n.slidesPerColumn) === c / e.params.slidesPerColumn ? c : Math.ceil(c / n.slidesPerColumn) * n.slidesPerColumn),
                                      "auto" !== n.slidesPerView && "row" === n.slidesPerColumnFill && (T = Math.max(T, n.slidesPerView * n.slidesPerColumn)));
                              for (var M, P = n.slidesPerColumn, L = T / P, A = Math.floor(c / n.slidesPerColumn), k = 0; k < c; k += 1) {
                                  _ = 0;
                                  var z = u.eq(k);
                                  if (n.slidesPerColumn > 1) {
                                      var I = void 0,
                                          O = void 0,
                                          D = void 0;
                                      if ("row" === n.slidesPerColumnFill && n.slidesPerGroup > 1) {
                                          var $ = Math.floor(k / (n.slidesPerGroup * n.slidesPerColumn)),
                                              B = k - n.slidesPerColumn * n.slidesPerGroup * $,
                                              q = 0 === $ ? n.slidesPerGroup : Math.min(Math.ceil((c - $ * P * n.slidesPerGroup) / P), n.slidesPerGroup);
                                          (I = (O = B - (D = Math.floor(B / q)) * q + $ * n.slidesPerGroup) + (D * T) / P),
                                              z.css({ "-webkit-box-ordinal-group": I, "-moz-box-ordinal-group": I, "-ms-flex-order": I, "-webkit-order": I, order: I });
                                      } else
                                          "column" === n.slidesPerColumnFill ? ((D = k - (O = Math.floor(k / P)) * P), (O > A || (O === A && D === P - 1)) && (D += 1) >= P && ((D = 0), (O += 1))) : (O = k - (D = Math.floor(k / L)) * L);
                                      z.css("margin-" + (e.isHorizontal() ? "top" : "left"), 0 !== D && n.spaceBetween && n.spaceBetween + "px");
                                  }
                                  if ("none" !== z.css("display")) {
                                      if ("auto" === n.slidesPerView) {
                                          var R = t.getComputedStyle(z[0], null),
                                              F = z[0].style.transform,
                                              H = z[0].style.webkitTransform;
                                          if ((F && (z[0].style.transform = "none"), H && (z[0].style.webkitTransform = "none"), n.roundLengths)) _ = e.isHorizontal() ? z.outerWidth(!0) : z.outerHeight(!0);
                                          else if (e.isHorizontal()) {
                                              var N = parseFloat(R.getPropertyValue("width") || 0),
                                                  G = parseFloat(R.getPropertyValue("padding-left") || 0),
                                                  W = parseFloat(R.getPropertyValue("padding-right") || 0),
                                                  V = parseFloat(R.getPropertyValue("margin-left") || 0),
                                                  Y = parseFloat(R.getPropertyValue("margin-right") || 0),
                                                  X = R.getPropertyValue("box-sizing");
                                              if (X && "border-box" === X) _ = N + V + Y;
                                              else {
                                                  var j = z[0],
                                                      U = j.clientWidth;
                                                  _ = N + G + W + V + Y + (j.offsetWidth - U);
                                              }
                                          } else {
                                              var K = parseFloat(R.getPropertyValue("height") || 0),
                                                  Q = parseFloat(R.getPropertyValue("padding-top") || 0),
                                                  Z = parseFloat(R.getPropertyValue("padding-bottom") || 0),
                                                  J = parseFloat(R.getPropertyValue("margin-top") || 0),
                                                  ee = parseFloat(R.getPropertyValue("margin-bottom") || 0),
                                                  te = R.getPropertyValue("box-sizing");
                                              if (te && "border-box" === te) _ = K + J + ee;
                                              else {
                                                  var ne = z[0],
                                                      re = ne.clientHeight;
                                                  _ = K + Q + Z + J + ee + (ne.offsetHeight - re);
                                              }
                                          }
                                          F && (z[0].style.transform = F), H && (z[0].style.webkitTransform = H), n.roundLengths && (_ = Math.floor(_));
                                      } else (_ = (i - (n.slidesPerView - 1) * b) / n.slidesPerView), n.roundLengths && (_ = Math.floor(_)), u[k] && (e.isHorizontal() ? (u[k].style.width = _ + "px") : (u[k].style.height = _ + "px"));
                                      u[k] && (u[k].swiperSlideSize = _),
                                          h.push(_),
                                          n.centeredSlides
                                              ? ((E = E + _ / 2 + x / 2 + b),
                                                0 === x && 0 !== k && (E = E - i / 2 - b),
                                                0 === k && (E = E - i / 2 - b),
                                                Math.abs(E) < 0.001 && (E = 0),
                                                n.roundLengths && (E = Math.floor(E)),
                                                S % n.slidesPerGroup == 0 && p.push(E),
                                                f.push(E))
                                              : (n.roundLengths && (E = Math.floor(E)), (S - Math.min(e.params.slidesPerGroupSkip, S)) % e.params.slidesPerGroup == 0 && p.push(E), f.push(E), (E = E + _ + b)),
                                          (e.virtualSize += _ + b),
                                          (x = _),
                                          (S += 1);
                                  }
                              }
                              if (
                                  ((e.virtualSize = Math.max(e.virtualSize, i) + g),
                                  a && s && ("slide" === n.effect || "coverflow" === n.effect) && r.css({ width: e.virtualSize + n.spaceBetween + "px" }),
                                  n.setWrapperSize && (e.isHorizontal() ? r.css({ width: e.virtualSize + n.spaceBetween + "px" }) : r.css({ height: e.virtualSize + n.spaceBetween + "px" })),
                                  n.slidesPerColumn > 1 &&
                                      ((e.virtualSize = (_ + n.spaceBetween) * T),
                                      (e.virtualSize = Math.ceil(e.virtualSize / n.slidesPerColumn) - n.spaceBetween),
                                      e.isHorizontal() ? r.css({ width: e.virtualSize + n.spaceBetween + "px" }) : r.css({ height: e.virtualSize + n.spaceBetween + "px" }),
                                      n.centeredSlides))
                              ) {
                                  M = [];
                                  for (var ie = 0; ie < p.length; ie += 1) {
                                      var ae = p[ie];
                                      n.roundLengths && (ae = Math.floor(ae)), p[ie] < e.virtualSize + p[0] && M.push(ae);
                                  }
                                  p = M;
                              }
                              if (!n.centeredSlides) {
                                  M = [];
                                  for (var se = 0; se < p.length; se += 1) {
                                      var oe = p[se];
                                      n.roundLengths && (oe = Math.floor(oe)), p[se] <= e.virtualSize - i && M.push(oe);
                                  }
                                  (p = M), Math.floor(e.virtualSize - i) - Math.floor(p[p.length - 1]) > 1 && p.push(e.virtualSize - i);
                              }
                              if (
                                  (0 === p.length && (p = [0]),
                                  0 !== n.spaceBetween && (e.isHorizontal() ? (a ? u.filter(m).css({ marginLeft: b + "px" }) : u.filter(m).css({ marginRight: b + "px" })) : u.filter(m).css({ marginBottom: b + "px" })),
                                  n.centeredSlides && n.centeredSlidesBounds)
                              ) {
                                  var le = 0;
                                  h.forEach(function (e) {
                                      le += e + (n.spaceBetween ? n.spaceBetween : 0);
                                  });
                                  var de = (le -= n.spaceBetween) - i;
                                  p = p.map(function (e) {
                                      return e < 0 ? -v : e > de ? de + g : e;
                                  });
                              }
                              if (n.centerInsufficientSlides) {
                                  var ue = 0;
                                  if (
                                      (h.forEach(function (e) {
                                          ue += e + (n.spaceBetween ? n.spaceBetween : 0);
                                      }),
                                      (ue -= n.spaceBetween) < i)
                                  ) {
                                      var ce = (i - ue) / 2;
                                      p.forEach(function (e, t) {
                                          p[t] = e - ce;
                                      }),
                                          f.forEach(function (e, t) {
                                              f[t] = e + ce;
                                          });
                                  }
                              }
                              C(e, { slides: u, snapGrid: p, slidesGrid: f, slidesSizesGrid: h }),
                                  c !== d && e.emit("slidesLengthChange"),
                                  p.length !== y && (e.params.watchOverflow && e.checkOverflow(), e.emit("snapGridLengthChange")),
                                  f.length !== w && e.emit("slidesGridLengthChange"),
                                  (n.watchSlidesProgress || n.watchSlidesVisibility) && e.updateSlidesOffset();
                          }
                      },
                      updateAutoHeight: function (e) {
                          var t,
                              n = this,
                              r = [],
                              i = 0;
                          if (("number" == typeof e ? n.setTransition(e) : !0 === e && n.setTransition(n.params.speed), "auto" !== n.params.slidesPerView && n.params.slidesPerView > 1))
                              if (n.params.centeredSlides)
                                  n.visibleSlides.each(function (e) {
                                      r.push(e);
                                  });
                              else
                                  for (t = 0; t < Math.ceil(n.params.slidesPerView); t += 1) {
                                      var a = n.activeIndex + t;
                                      if (a > n.slides.length) break;
                                      r.push(n.slides.eq(a)[0]);
                                  }
                          else r.push(n.slides.eq(n.activeIndex)[0]);
                          for (t = 0; t < r.length; t += 1)
                              if (void 0 !== r[t]) {
                                  var s = r[t].offsetHeight;
                                  i = s > i ? s : i;
                              }
                          i && n.$wrapperEl.css("height", i + "px");
                      },
                      updateSlidesOffset: function () {
                          for (var e = this.slides, t = 0; t < e.length; t += 1) e[t].swiperSlideOffset = this.isHorizontal() ? e[t].offsetLeft : e[t].offsetTop;
                      },
                      updateSlidesProgress: function (e) {
                          void 0 === e && (e = (this && this.translate) || 0);
                          var t = this,
                              n = t.params,
                              r = t.slides,
                              i = t.rtlTranslate;
                          if (0 !== r.length) {
                              void 0 === r[0].swiperSlideOffset && t.updateSlidesOffset();
                              var a = -e;
                              i && (a = e), r.removeClass(n.slideVisibleClass), (t.visibleSlidesIndexes = []), (t.visibleSlides = []);
                              for (var s = 0; s < r.length; s += 1) {
                                  var o = r[s],
                                      l = (a + (n.centeredSlides ? t.minTranslate() : 0) - o.swiperSlideOffset) / (o.swiperSlideSize + n.spaceBetween);
                                  if (n.watchSlidesVisibility || (n.centeredSlides && n.autoHeight)) {
                                      var d = -(a - o.swiperSlideOffset),
                                          u = d + t.slidesSizesGrid[s];
                                      ((d >= 0 && d < t.size - 1) || (u > 1 && u <= t.size) || (d <= 0 && u >= t.size)) && (t.visibleSlides.push(o), t.visibleSlidesIndexes.push(s), r.eq(s).addClass(n.slideVisibleClass));
                                  }
                                  o.progress = i ? -l : l;
                              }
                              t.visibleSlides = g(t.visibleSlides);
                          }
                      },
                      updateProgress: function (e) {
                          var t = this;
                          if (void 0 === e) {
                              var n = t.rtlTranslate ? -1 : 1;
                              e = (t && t.translate && t.translate * n) || 0;
                          }
                          var r = t.params,
                              i = t.maxTranslate() - t.minTranslate(),
                              a = t.progress,
                              s = t.isBeginning,
                              o = t.isEnd,
                              l = s,
                              d = o;
                          0 === i ? ((a = 0), (s = !0), (o = !0)) : ((s = (a = (e - t.minTranslate()) / i) <= 0), (o = a >= 1)),
                              C(t, { progress: a, isBeginning: s, isEnd: o }),
                              (r.watchSlidesProgress || r.watchSlidesVisibility || (r.centeredSlides && r.autoHeight)) && t.updateSlidesProgress(e),
                              s && !l && t.emit("reachBeginning toEdge"),
                              o && !d && t.emit("reachEnd toEdge"),
                              ((l && !s) || (d && !o)) && t.emit("fromEdge"),
                              t.emit("progress", a);
                      },
                      updateSlidesClasses: function () {
                          var e,
                              t = this,
                              n = t.slides,
                              r = t.params,
                              i = t.$wrapperEl,
                              a = t.activeIndex,
                              s = t.realIndex,
                              o = t.virtual && r.virtual.enabled;
                          n.removeClass(r.slideActiveClass + " " + r.slideNextClass + " " + r.slidePrevClass + " " + r.slideDuplicateActiveClass + " " + r.slideDuplicateNextClass + " " + r.slideDuplicatePrevClass),
                              (e = o ? t.$wrapperEl.find("." + r.slideClass + '[data-swiper-slide-index="' + a + '"]') : n.eq(a)).addClass(r.slideActiveClass),
                              r.loop &&
                                  (e.hasClass(r.slideDuplicateClass)
                                      ? i.children("." + r.slideClass + ":not(." + r.slideDuplicateClass + ')[data-swiper-slide-index="' + s + '"]').addClass(r.slideDuplicateActiveClass)
                                      : i.children("." + r.slideClass + "." + r.slideDuplicateClass + '[data-swiper-slide-index="' + s + '"]').addClass(r.slideDuplicateActiveClass));
                          var l = e
                              .nextAll("." + r.slideClass)
                              .eq(0)
                              .addClass(r.slideNextClass);
                          r.loop && 0 === l.length && (l = n.eq(0)).addClass(r.slideNextClass);
                          var d = e
                              .prevAll("." + r.slideClass)
                              .eq(0)
                              .addClass(r.slidePrevClass);
                          r.loop && 0 === d.length && (d = n.eq(-1)).addClass(r.slidePrevClass),
                              r.loop &&
                                  (l.hasClass(r.slideDuplicateClass)
                                      ? i.children("." + r.slideClass + ":not(." + r.slideDuplicateClass + ')[data-swiper-slide-index="' + l.attr("data-swiper-slide-index") + '"]').addClass(r.slideDuplicateNextClass)
                                      : i.children("." + r.slideClass + "." + r.slideDuplicateClass + '[data-swiper-slide-index="' + l.attr("data-swiper-slide-index") + '"]').addClass(r.slideDuplicateNextClass),
                                  d.hasClass(r.slideDuplicateClass)
                                      ? i.children("." + r.slideClass + ":not(." + r.slideDuplicateClass + ')[data-swiper-slide-index="' + d.attr("data-swiper-slide-index") + '"]').addClass(r.slideDuplicatePrevClass)
                                      : i.children("." + r.slideClass + "." + r.slideDuplicateClass + '[data-swiper-slide-index="' + d.attr("data-swiper-slide-index") + '"]').addClass(r.slideDuplicatePrevClass)),
                              t.emitSlidesClasses();
                      },
                      updateActiveIndex: function (e) {
                          var t,
                              n = this,
                              r = n.rtlTranslate ? n.translate : -n.translate,
                              i = n.slidesGrid,
                              a = n.snapGrid,
                              s = n.params,
                              o = n.activeIndex,
                              l = n.realIndex,
                              d = n.snapIndex,
                              u = e;
                          if (void 0 === u) {
                              for (var c = 0; c < i.length; c += 1) void 0 !== i[c + 1] ? (r >= i[c] && r < i[c + 1] - (i[c + 1] - i[c]) / 2 ? (u = c) : r >= i[c] && r < i[c + 1] && (u = c + 1)) : r >= i[c] && (u = c);
                              s.normalizeSlideIndex && (u < 0 || void 0 === u) && (u = 0);
                          }
                          if (a.indexOf(r) >= 0) t = a.indexOf(r);
                          else {
                              var p = Math.min(s.slidesPerGroupSkip, u);
                              t = p + Math.floor((u - p) / s.slidesPerGroup);
                          }
                          if ((t >= a.length && (t = a.length - 1), u !== o)) {
                              var f = parseInt(n.slides.eq(u).attr("data-swiper-slide-index") || u, 10);
                              C(n, { snapIndex: t, realIndex: f, previousIndex: o, activeIndex: u }),
                                  n.emit("activeIndexChange"),
                                  n.emit("snapIndexChange"),
                                  l !== f && n.emit("realIndexChange"),
                                  (n.initialized || n.params.runCallbacksOnInit) && n.emit("slideChange");
                          } else t !== d && ((n.snapIndex = t), n.emit("snapIndexChange"));
                      },
                      updateClickedSlide: function (e) {
                          var t = this,
                              n = t.params,
                              r = g(e.target).closest("." + n.slideClass)[0],
                              i = !1;
                          if (r) for (var a = 0; a < t.slides.length; a += 1) t.slides[a] === r && (i = !0);
                          if (!r || !i) return (t.clickedSlide = void 0), void (t.clickedIndex = void 0);
                          (t.clickedSlide = r),
                              t.virtual && t.params.virtual.enabled ? (t.clickedIndex = parseInt(g(r).attr("data-swiper-slide-index"), 10)) : (t.clickedIndex = g(r).index()),
                              n.slideToClickedSlide && void 0 !== t.clickedIndex && t.clickedIndex !== t.activeIndex && t.slideToClickedSlide();
                      },
                  },
                  translate: {
                      getTranslate: function (e) {
                          void 0 === e && (e = this.isHorizontal() ? "x" : "y");
                          var t = this,
                              n = t.params,
                              r = t.rtlTranslate,
                              i = t.translate,
                              a = t.$wrapperEl;
                          if (n.virtualTranslate) return r ? -i : i;
                          if (n.cssMode) return i;
                          var s = T(a[0], e);
                          return r && (s = -s), s || 0;
                      },
                      setTranslate: function (e, t) {
                          var n = this,
                              r = n.rtlTranslate,
                              i = n.params,
                              a = n.$wrapperEl,
                              s = n.wrapperEl,
                              o = n.progress,
                              l = 0,
                              d = 0;
                          n.isHorizontal() ? (l = r ? -e : e) : (d = e),
                              i.roundLengths && ((l = Math.floor(l)), (d = Math.floor(d))),
                              i.cssMode ? (s[n.isHorizontal() ? "scrollLeft" : "scrollTop"] = n.isHorizontal() ? -l : -d) : i.virtualTranslate || a.transform("translate3d(" + l + "px, " + d + "px, 0px)"),
                              (n.previousTranslate = n.translate),
                              (n.translate = n.isHorizontal() ? l : d);
                          var u = n.maxTranslate() - n.minTranslate();
                          (0 === u ? 0 : (e - n.minTranslate()) / u) !== o && n.updateProgress(e), n.emit("setTranslate", n.translate, t);
                      },
                      minTranslate: function () {
                          return -this.snapGrid[0];
                      },
                      maxTranslate: function () {
                          return -this.snapGrid[this.snapGrid.length - 1];
                      },
                      translateTo: function (e, t, n, r, i) {
                          void 0 === e && (e = 0), void 0 === t && (t = this.params.speed), void 0 === n && (n = !0), void 0 === r && (r = !0);
                          var a = this,
                              s = a.params,
                              o = a.wrapperEl;
                          if (a.animating && s.preventInteractionOnTransition) return !1;
                          var l,
                              d = a.minTranslate(),
                              u = a.maxTranslate();
                          if (((l = r && e > d ? d : r && e < u ? u : e), a.updateProgress(l), s.cssMode)) {
                              var c,
                                  p = a.isHorizontal();
                              return 0 === t ? (o[p ? "scrollLeft" : "scrollTop"] = -l) : o.scrollTo ? o.scrollTo((((c = {})[p ? "left" : "top"] = -l), (c.behavior = "smooth"), c)) : (o[p ? "scrollLeft" : "scrollTop"] = -l), !0;
                          }
                          return (
                              0 === t
                                  ? (a.setTransition(0), a.setTranslate(l), n && (a.emit("beforeTransitionStart", t, i), a.emit("transitionEnd")))
                                  : (a.setTransition(t),
                                    a.setTranslate(l),
                                    n && (a.emit("beforeTransitionStart", t, i), a.emit("transitionStart")),
                                    a.animating ||
                                        ((a.animating = !0),
                                        a.onTranslateToWrapperTransitionEnd ||
                                            (a.onTranslateToWrapperTransitionEnd = function (e) {
                                                a &&
                                                    !a.destroyed &&
                                                    e.target === this &&
                                                    (a.$wrapperEl[0].removeEventListener("transitionend", a.onTranslateToWrapperTransitionEnd),
                                                    a.$wrapperEl[0].removeEventListener("webkitTransitionEnd", a.onTranslateToWrapperTransitionEnd),
                                                    (a.onTranslateToWrapperTransitionEnd = null),
                                                    delete a.onTranslateToWrapperTransitionEnd,
                                                    n && a.emit("transitionEnd"));
                                            }),
                                        a.$wrapperEl[0].addEventListener("transitionend", a.onTranslateToWrapperTransitionEnd),
                                        a.$wrapperEl[0].addEventListener("webkitTransitionEnd", a.onTranslateToWrapperTransitionEnd))),
                              !0
                          );
                      },
                  },
                  transition: {
                      setTransition: function (e, t) {
                          var n = this;
                          n.params.cssMode || n.$wrapperEl.transition(e), n.emit("setTransition", e, t);
                      },
                      transitionStart: function (e, t) {
                          void 0 === e && (e = !0);
                          var n = this,
                              r = n.activeIndex,
                              i = n.params,
                              a = n.previousIndex;
                          if (!i.cssMode) {
                              i.autoHeight && n.updateAutoHeight();
                              var s = t;
                              if ((s || (s = r > a ? "next" : r < a ? "prev" : "reset"), n.emit("transitionStart"), e && r !== a)) {
                                  if ("reset" === s) return void n.emit("slideResetTransitionStart");
                                  n.emit("slideChangeTransitionStart"), "next" === s ? n.emit("slideNextTransitionStart") : n.emit("slidePrevTransitionStart");
                              }
                          }
                      },
                      transitionEnd: function (e, t) {
                          void 0 === e && (e = !0);
                          var n = this,
                              r = n.activeIndex,
                              i = n.previousIndex,
                              a = n.params;
                          if (((n.animating = !1), !a.cssMode)) {
                              n.setTransition(0);
                              var s = t;
                              if ((s || (s = r > i ? "next" : r < i ? "prev" : "reset"), n.emit("transitionEnd"), e && r !== i)) {
                                  if ("reset" === s) return void n.emit("slideResetTransitionEnd");
                                  n.emit("slideChangeTransitionEnd"), "next" === s ? n.emit("slideNextTransitionEnd") : n.emit("slidePrevTransitionEnd");
                              }
                          }
                      },
                  },
                  slide: {
                      slideTo: function (e, t, n, r) {
                          if ((void 0 === e && (e = 0), void 0 === t && (t = this.params.speed), void 0 === n && (n = !0), "number" != typeof e && "string" != typeof e))
                              throw new Error("The 'index' argument cannot have type other than 'number' or 'string'. [" + (0, a.default)(e) + "] given.");
                          if ("string" == typeof e) {
                              var i = parseInt(e, 10);
                              if (!isFinite(i)) throw new Error("The passed-in 'index' (string) couldn't be converted to 'number'. [" + e + "] given.");
                              e = i;
                          }
                          var s = this,
                              o = e;
                          o < 0 && (o = 0);
                          var l = s.params,
                              d = s.snapGrid,
                              u = s.slidesGrid,
                              c = s.previousIndex,
                              p = s.activeIndex,
                              f = s.rtlTranslate,
                              h = s.wrapperEl;
                          if (s.animating && l.preventInteractionOnTransition) return !1;
                          var m = Math.min(s.params.slidesPerGroupSkip, o),
                              v = m + Math.floor((o - m) / s.params.slidesPerGroup);
                          v >= d.length && (v = d.length - 1), (p || l.initialSlide || 0) === (c || 0) && n && s.emit("beforeSlideChangeStart");
                          var g,
                              y = -d[v];
                          if ((s.updateProgress(y), l.normalizeSlideIndex))
                              for (var w = 0; w < u.length; w += 1) {
                                  var b = -Math.floor(100 * y),
                                      E = Math.floor(100 * u[w]),
                                      x = Math.floor(100 * u[w + 1]);
                                  void 0 !== u[w + 1] ? (b >= E && b < x - (x - E) / 2 ? (o = w) : b >= E && b < x && (o = w + 1)) : b >= E && (o = w);
                              }
                          if (s.initialized && o !== p) {
                              if (!s.allowSlideNext && y < s.translate && y < s.minTranslate()) return !1;
                              if (!s.allowSlidePrev && y > s.translate && y > s.maxTranslate() && (p || 0) !== o) return !1;
                          }
                          if (((g = o > p ? "next" : o < p ? "prev" : "reset"), (f && -y === s.translate) || (!f && y === s.translate)))
                              return s.updateActiveIndex(o), l.autoHeight && s.updateAutoHeight(), s.updateSlidesClasses(), "slide" !== l.effect && s.setTranslate(y), "reset" !== g && (s.transitionStart(n, g), s.transitionEnd(n, g)), !1;
                          if (l.cssMode) {
                              var S,
                                  T = s.isHorizontal(),
                                  _ = -y;
                              return (
                                  f && (_ = h.scrollWidth - h.offsetWidth - _),
                                  0 === t ? (h[T ? "scrollLeft" : "scrollTop"] = _) : h.scrollTo ? h.scrollTo((((S = {})[T ? "left" : "top"] = _), (S.behavior = "smooth"), S)) : (h[T ? "scrollLeft" : "scrollTop"] = _),
                                  !0
                              );
                          }
                          return (
                              0 === t
                                  ? (s.setTransition(0), s.setTranslate(y), s.updateActiveIndex(o), s.updateSlidesClasses(), s.emit("beforeTransitionStart", t, r), s.transitionStart(n, g), s.transitionEnd(n, g))
                                  : (s.setTransition(t),
                                    s.setTranslate(y),
                                    s.updateActiveIndex(o),
                                    s.updateSlidesClasses(),
                                    s.emit("beforeTransitionStart", t, r),
                                    s.transitionStart(n, g),
                                    s.animating ||
                                        ((s.animating = !0),
                                        s.onSlideToWrapperTransitionEnd ||
                                            (s.onSlideToWrapperTransitionEnd = function (e) {
                                                s &&
                                                    !s.destroyed &&
                                                    e.target === this &&
                                                    (s.$wrapperEl[0].removeEventListener("transitionend", s.onSlideToWrapperTransitionEnd),
                                                    s.$wrapperEl[0].removeEventListener("webkitTransitionEnd", s.onSlideToWrapperTransitionEnd),
                                                    (s.onSlideToWrapperTransitionEnd = null),
                                                    delete s.onSlideToWrapperTransitionEnd,
                                                    s.transitionEnd(n, g));
                                            }),
                                        s.$wrapperEl[0].addEventListener("transitionend", s.onSlideToWrapperTransitionEnd),
                                        s.$wrapperEl[0].addEventListener("webkitTransitionEnd", s.onSlideToWrapperTransitionEnd))),
                              !0
                          );
                      },
                      slideToLoop: function (e, t, n, r) {
                          void 0 === e && (e = 0), void 0 === t && (t = this.params.speed), void 0 === n && (n = !0);
                          var i = this,
                              a = e;
                          return i.params.loop && (a += i.loopedSlides), i.slideTo(a, t, n, r);
                      },
                      slideNext: function (e, t, n) {
                          void 0 === e && (e = this.params.speed), void 0 === t && (t = !0);
                          var r = this,
                              i = r.params,
                              a = r.animating,
                              s = r.activeIndex < i.slidesPerGroupSkip ? 1 : i.slidesPerGroup;
                          if (i.loop) {
                              if (a && i.loopPreventsSlide) return !1;
                              r.loopFix(), (r._clientLeft = r.$wrapperEl[0].clientLeft);
                          }
                          return r.slideTo(r.activeIndex + s, e, t, n);
                      },
                      slidePrev: function (e, t, n) {
                          void 0 === e && (e = this.params.speed), void 0 === t && (t = !0);
                          var r = this,
                              i = r.params,
                              a = r.animating,
                              s = r.snapGrid,
                              o = r.slidesGrid,
                              l = r.rtlTranslate;
                          if (i.loop) {
                              if (a && i.loopPreventsSlide) return !1;
                              r.loopFix(), (r._clientLeft = r.$wrapperEl[0].clientLeft);
                          }
                          function d(e) {
                              return e < 0 ? -Math.floor(Math.abs(e)) : Math.floor(e);
                          }
                          var u,
                              c = d(l ? r.translate : -r.translate),
                              p = s.map(function (e) {
                                  return d(e);
                              }),
                              f = (s[p.indexOf(c)], s[p.indexOf(c) - 1]);
                          return (
                              void 0 === f &&
                                  i.cssMode &&
                                  s.forEach(function (e) {
                                      !f && c >= e && (f = e);
                                  }),
                              void 0 !== f && (u = o.indexOf(f)) < 0 && (u = r.activeIndex - 1),
                              r.slideTo(u, e, t, n)
                          );
                      },
                      slideReset: function (e, t, n) {
                          return void 0 === e && (e = this.params.speed), void 0 === t && (t = !0), this.slideTo(this.activeIndex, e, t, n);
                      },
                      slideToClosest: function (e, t, n, r) {
                          void 0 === e && (e = this.params.speed), void 0 === t && (t = !0), void 0 === r && (r = 0.5);
                          var i = this,
                              a = i.activeIndex,
                              s = Math.min(i.params.slidesPerGroupSkip, a),
                              o = s + Math.floor((a - s) / i.params.slidesPerGroup),
                              l = i.rtlTranslate ? i.translate : -i.translate;
                          if (l >= i.snapGrid[o]) {
                              var d = i.snapGrid[o];
                              l - d > (i.snapGrid[o + 1] - d) * r && (a += i.params.slidesPerGroup);
                          } else {
                              var u = i.snapGrid[o - 1];
                              l - u <= (i.snapGrid[o] - u) * r && (a -= i.params.slidesPerGroup);
                          }
                          return (a = Math.max(a, 0)), (a = Math.min(a, i.slidesGrid.length - 1)), i.slideTo(a, e, t, n);
                      },
                      slideToClickedSlide: function () {
                          var e,
                              t = this,
                              n = t.params,
                              r = t.$wrapperEl,
                              i = "auto" === n.slidesPerView ? t.slidesPerViewDynamic() : n.slidesPerView,
                              a = t.clickedIndex;
                          if (n.loop) {
                              if (t.animating) return;
                              (e = parseInt(g(t.clickedSlide).attr("data-swiper-slide-index"), 10)),
                                  n.centeredSlides
                                      ? a < t.loopedSlides - i / 2 || a > t.slides.length - t.loopedSlides + i / 2
                                          ? (t.loopFix(),
                                            (a = r
                                                .children("." + n.slideClass + '[data-swiper-slide-index="' + e + '"]:not(.' + n.slideDuplicateClass + ")")
                                                .eq(0)
                                                .index()),
                                            x(function () {
                                                t.slideTo(a);
                                            }))
                                          : t.slideTo(a)
                                      : a > t.slides.length - i
                                      ? (t.loopFix(),
                                        (a = r
                                            .children("." + n.slideClass + '[data-swiper-slide-index="' + e + '"]:not(.' + n.slideDuplicateClass + ")")
                                            .eq(0)
                                            .index()),
                                        x(function () {
                                            t.slideTo(a);
                                        }))
                                      : t.slideTo(a);
                          } else t.slideTo(a);
                      },
                  },
                  loop: {
                      loopCreate: function () {
                          var e = this,
                              t = s(),
                              n = e.params,
                              r = e.$wrapperEl;
                          r.children("." + n.slideClass + "." + n.slideDuplicateClass).remove();
                          var i = r.children("." + n.slideClass);
                          if (n.loopFillGroupWithBlank) {
                              var a = n.slidesPerGroup - (i.length % n.slidesPerGroup);
                              if (a !== n.slidesPerGroup) {
                                  for (var o = 0; o < a; o += 1) {
                                      var l = g(t.createElement("div")).addClass(n.slideClass + " " + n.slideBlankClass);
                                      r.append(l);
                                  }
                                  i = r.children("." + n.slideClass);
                              }
                          }
                          "auto" !== n.slidesPerView || n.loopedSlides || (n.loopedSlides = i.length),
                              (e.loopedSlides = Math.ceil(parseFloat(n.loopedSlides || n.slidesPerView, 10))),
                              (e.loopedSlides += n.loopAdditionalSlides),
                              e.loopedSlides > i.length && (e.loopedSlides = i.length);
                          var d = [],
                              u = [];
                          i.each(function (t, n) {
                              var r = g(t);
                              n < e.loopedSlides && u.push(t), n < i.length && n >= i.length - e.loopedSlides && d.push(t), r.attr("data-swiper-slide-index", n);
                          });
                          for (var c = 0; c < u.length; c += 1) r.append(g(u[c].cloneNode(!0)).addClass(n.slideDuplicateClass));
                          for (var p = d.length - 1; p >= 0; p -= 1) r.prepend(g(d[p].cloneNode(!0)).addClass(n.slideDuplicateClass));
                      },
                      loopFix: function () {
                          var e = this;
                          e.emit("beforeLoopFix");
                          var t,
                              n = e.activeIndex,
                              r = e.slides,
                              i = e.loopedSlides,
                              a = e.allowSlidePrev,
                              s = e.allowSlideNext,
                              o = e.snapGrid,
                              l = e.rtlTranslate;
                          (e.allowSlidePrev = !0), (e.allowSlideNext = !0);
                          var d = -o[n] - e.getTranslate();
                          n < i
                              ? ((t = r.length - 3 * i + n), (t += i), e.slideTo(t, 0, !1, !0) && 0 !== d && e.setTranslate((l ? -e.translate : e.translate) - d))
                              : n >= r.length - i && ((t = -r.length + n + i), (t += i), e.slideTo(t, 0, !1, !0) && 0 !== d && e.setTranslate((l ? -e.translate : e.translate) - d)),
                              (e.allowSlidePrev = a),
                              (e.allowSlideNext = s),
                              e.emit("loopFix");
                      },
                      loopDestroy: function () {
                          var e = this,
                              t = e.$wrapperEl,
                              n = e.params,
                              r = e.slides;
                          t.children("." + n.slideClass + "." + n.slideDuplicateClass + ",." + n.slideClass + "." + n.slideBlankClass).remove(), r.removeAttr("data-swiper-slide-index");
                      },
                  },
                  grabCursor: {
                      setGrabCursor: function (e) {
                          var t = this;
                          if (!(t.support.touch || !t.params.simulateTouch || (t.params.watchOverflow && t.isLocked) || t.params.cssMode)) {
                              var n = t.el;
                              (n.style.cursor = "move"), (n.style.cursor = e ? "-webkit-grabbing" : "-webkit-grab"), (n.style.cursor = e ? "-moz-grabbin" : "-moz-grab"), (n.style.cursor = e ? "grabbing" : "grab");
                          }
                      },
                      unsetGrabCursor: function () {
                          var e = this;
                          e.support.touch || (e.params.watchOverflow && e.isLocked) || e.params.cssMode || (e.el.style.cursor = "");
                      },
                  },
                  manipulation: {
                      appendSlide: function (e) {
                          var t = this,
                              n = t.$wrapperEl,
                              r = t.params;
                          if ((r.loop && t.loopDestroy(), "object" == (0, a.default)(e) && "length" in e)) for (var i = 0; i < e.length; i += 1) e[i] && n.append(e[i]);
                          else n.append(e);
                          r.loop && t.loopCreate(), (r.observer && t.support.observer) || t.update();
                      },
                      prependSlide: function (e) {
                          var t = this,
                              n = t.params,
                              r = t.$wrapperEl,
                              i = t.activeIndex;
                          n.loop && t.loopDestroy();
                          var s = i + 1;
                          if ("object" == (0, a.default)(e) && "length" in e) {
                              for (var o = 0; o < e.length; o += 1) e[o] && r.prepend(e[o]);
                              s = i + e.length;
                          } else r.prepend(e);
                          n.loop && t.loopCreate(), (n.observer && t.support.observer) || t.update(), t.slideTo(s, 0, !1);
                      },
                      addSlide: function (e, t) {
                          var n = this,
                              r = n.$wrapperEl,
                              i = n.params,
                              s = n.activeIndex;
                          i.loop && ((s -= n.loopedSlides), n.loopDestroy(), (n.slides = r.children("." + i.slideClass)));
                          var o = n.slides.length;
                          if (e <= 0) n.prependSlide(t);
                          else if (e >= o) n.appendSlide(t);
                          else {
                              for (var l = s > e ? s + 1 : s, d = [], u = o - 1; u >= e; u -= 1) {
                                  var c = n.slides.eq(u);
                                  c.remove(), d.unshift(c);
                              }
                              if ("object" == (0, a.default)(t) && "length" in t) {
                                  for (var p = 0; p < t.length; p += 1) t[p] && r.append(t[p]);
                                  l = s > e ? s + t.length : s;
                              } else r.append(t);
                              for (var f = 0; f < d.length; f += 1) r.append(d[f]);
                              i.loop && n.loopCreate(), (i.observer && n.support.observer) || n.update(), i.loop ? n.slideTo(l + n.loopedSlides, 0, !1) : n.slideTo(l, 0, !1);
                          }
                      },
                      removeSlide: function (e) {
                          var t = this,
                              n = t.params,
                              r = t.$wrapperEl,
                              i = t.activeIndex;
                          n.loop && ((i -= t.loopedSlides), t.loopDestroy(), (t.slides = r.children("." + n.slideClass)));
                          var s,
                              o = i;
                          if ("object" == (0, a.default)(e) && "length" in e) {
                              for (var l = 0; l < e.length; l += 1) (s = e[l]), t.slides[s] && t.slides.eq(s).remove(), s < o && (o -= 1);
                              o = Math.max(o, 0);
                          } else (s = e), t.slides[s] && t.slides.eq(s).remove(), s < o && (o -= 1), (o = Math.max(o, 0));
                          n.loop && t.loopCreate(), (n.observer && t.support.observer) || t.update(), n.loop ? t.slideTo(o + t.loopedSlides, 0, !1) : t.slideTo(o, 0, !1);
                      },
                      removeAllSlides: function () {
                          for (var e = [], t = 0; t < this.slides.length; t += 1) e.push(t);
                          this.removeSlide(e);
                      },
                  },
                  events: {
                      attachEvents: function () {
                          var e = this,
                              t = s(),
                              n = e.params,
                              r = e.touchEvents,
                              i = e.el,
                              a = e.wrapperEl,
                              o = e.device,
                              l = e.support;
                          (e.onTouchStart = O.bind(e)), (e.onTouchMove = D.bind(e)), (e.onTouchEnd = $.bind(e)), n.cssMode && (e.onScroll = R.bind(e)), (e.onClick = q.bind(e));
                          var d = !!n.nested;
                          if (!l.touch && l.pointerEvents) i.addEventListener(r.start, e.onTouchStart, !1), t.addEventListener(r.move, e.onTouchMove, d), t.addEventListener(r.end, e.onTouchEnd, !1);
                          else {
                              if (l.touch) {
                                  var u = !("touchstart" !== r.start || !l.passiveListener || !n.passiveListeners) && { passive: !0, capture: !1 };
                                  i.addEventListener(r.start, e.onTouchStart, u),
                                      i.addEventListener(r.move, e.onTouchMove, l.passiveListener ? { passive: !1, capture: d } : d),
                                      i.addEventListener(r.end, e.onTouchEnd, u),
                                      r.cancel && i.addEventListener(r.cancel, e.onTouchEnd, u),
                                      F || (t.addEventListener("touchstart", H), (F = !0));
                              }
                              ((n.simulateTouch && !o.ios && !o.android) || (n.simulateTouch && !l.touch && o.ios)) &&
                                  (i.addEventListener("mousedown", e.onTouchStart, !1), t.addEventListener("mousemove", e.onTouchMove, d), t.addEventListener("mouseup", e.onTouchEnd, !1));
                          }
                          (n.preventClicks || n.preventClicksPropagation) && i.addEventListener("click", e.onClick, !0),
                              n.cssMode && a.addEventListener("scroll", e.onScroll),
                              n.updateOnWindowResize ? e.on(o.ios || o.android ? "resize orientationchange observerUpdate" : "resize observerUpdate", B, !0) : e.on("observerUpdate", B, !0);
                      },
                      detachEvents: function () {
                          var e = this,
                              t = s(),
                              n = e.params,
                              r = e.touchEvents,
                              i = e.el,
                              a = e.wrapperEl,
                              o = e.device,
                              l = e.support,
                              d = !!n.nested;
                          if (!l.touch && l.pointerEvents) i.removeEventListener(r.start, e.onTouchStart, !1), t.removeEventListener(r.move, e.onTouchMove, d), t.removeEventListener(r.end, e.onTouchEnd, !1);
                          else {
                              if (l.touch) {
                                  var u = !("onTouchStart" !== r.start || !l.passiveListener || !n.passiveListeners) && { passive: !0, capture: !1 };
                                  i.removeEventListener(r.start, e.onTouchStart, u),
                                      i.removeEventListener(r.move, e.onTouchMove, d),
                                      i.removeEventListener(r.end, e.onTouchEnd, u),
                                      r.cancel && i.removeEventListener(r.cancel, e.onTouchEnd, u);
                              }
                              ((n.simulateTouch && !o.ios && !o.android) || (n.simulateTouch && !l.touch && o.ios)) &&
                                  (i.removeEventListener("mousedown", e.onTouchStart, !1), t.removeEventListener("mousemove", e.onTouchMove, d), t.removeEventListener("mouseup", e.onTouchEnd, !1));
                          }
                          (n.preventClicks || n.preventClicksPropagation) && i.removeEventListener("click", e.onClick, !0),
                              n.cssMode && a.removeEventListener("scroll", e.onScroll),
                              e.off(o.ios || o.android ? "resize orientationchange observerUpdate" : "resize observerUpdate", B);
                      },
                  },
                  breakpoints: {
                      setBreakpoint: function () {
                          var e = this,
                              t = e.activeIndex,
                              n = e.initialized,
                              r = e.loopedSlides,
                              i = void 0 === r ? 0 : r,
                              a = e.params,
                              s = e.$el,
                              o = a.breakpoints;
                          if (o && (!o || 0 !== Object.keys(o).length)) {
                              var l = e.getBreakpoint(o);
                              if (l && e.currentBreakpoint !== l) {
                                  var d = l in o ? o[l] : void 0;
                                  d &&
                                      ["slidesPerView", "spaceBetween", "slidesPerGroup", "slidesPerGroupSkip", "slidesPerColumn"].forEach(function (e) {
                                          var t = d[e];
                                          void 0 !== t && (d[e] = "slidesPerView" !== e || ("AUTO" !== t && "auto" !== t) ? ("slidesPerView" === e ? parseFloat(t) : parseInt(t, 10)) : "auto");
                                      });
                                  var u = d || e.originalParams,
                                      c = a.slidesPerColumn > 1,
                                      p = u.slidesPerColumn > 1;
                                  c && !p
                                      ? (s.removeClass(a.containerModifierClass + "multirow " + a.containerModifierClass + "multirow-column"), e.emitContainerClasses())
                                      : !c && p && (s.addClass(a.containerModifierClass + "multirow"), "column" === u.slidesPerColumnFill && s.addClass(a.containerModifierClass + "multirow-column"), e.emitContainerClasses());
                                  var f = u.direction && u.direction !== a.direction,
                                      h = a.loop && (u.slidesPerView !== a.slidesPerView || f);
                                  f && n && e.changeDirection(),
                                      C(e.params, u),
                                      C(e, { allowTouchMove: e.params.allowTouchMove, allowSlideNext: e.params.allowSlideNext, allowSlidePrev: e.params.allowSlidePrev }),
                                      (e.currentBreakpoint = l),
                                      e.emit("_beforeBreakpoint", u),
                                      h && n && (e.loopDestroy(), e.loopCreate(), e.updateSlides(), e.slideTo(t - i + e.loopedSlides, 0, !1)),
                                      e.emit("breakpoint", u);
                              }
                          }
                      },
                      getBreakpoint: function (e) {
                          var t = l();
                          if (e) {
                              var n = !1,
                                  r = Object.keys(e).map(function (e) {
                                      if ("string" == typeof e && 0 === e.indexOf("@")) {
                                          var n = parseFloat(e.substr(1));
                                          return { value: t.innerHeight * n, point: e };
                                      }
                                      return { value: e, point: e };
                                  });
                              r.sort(function (e, t) {
                                  return parseInt(e.value, 10) - parseInt(t.value, 10);
                              });
                              for (var i = 0; i < r.length; i += 1) {
                                  var a = r[i],
                                      s = a.point;
                                  a.value <= t.innerWidth && (n = s);
                              }
                              return n || "max";
                          }
                      },
                  },
                  checkOverflow: {
                      checkOverflow: function () {
                          var e = this,
                              t = e.params,
                              n = e.isLocked,
                              r = e.slides.length > 0 && t.slidesOffsetBefore + t.spaceBetween * (e.slides.length - 1) + e.slides[0].offsetWidth * e.slides.length;
                          t.slidesOffsetBefore && t.slidesOffsetAfter && r ? (e.isLocked = r <= e.size) : (e.isLocked = 1 === e.snapGrid.length),
                              (e.allowSlideNext = !e.isLocked),
                              (e.allowSlidePrev = !e.isLocked),
                              n !== e.isLocked && e.emit(e.isLocked ? "lock" : "unlock"),
                              n && n !== e.isLocked && ((e.isEnd = !1), e.navigation && e.navigation.update());
                      },
                  },
                  classes: {
                      addClasses: function () {
                          var e = this,
                              t = e.classNames,
                              n = e.params,
                              r = e.rtl,
                              i = e.$el,
                              a = e.device,
                              s = [];
                          s.push("initialized"),
                              s.push(n.direction),
                              n.freeMode && s.push("free-mode"),
                              n.autoHeight && s.push("autoheight"),
                              r && s.push("rtl"),
                              n.slidesPerColumn > 1 && (s.push("multirow"), "column" === n.slidesPerColumnFill && s.push("multirow-column")),
                              a.android && s.push("android"),
                              a.ios && s.push("ios"),
                              n.cssMode && s.push("css-mode"),
                              s.forEach(function (e) {
                                  t.push(n.containerModifierClass + e);
                              }),
                              i.addClass(t.join(" ")),
                              e.emitContainerClasses();
                      },
                      removeClasses: function () {
                          var e = this,
                              t = e.$el,
                              n = e.classNames;
                          t.removeClass(n.join(" ")), e.emitContainerClasses();
                      },
                  },
                  images: {
                      loadImage: function (e, t, n, r, i, a) {
                          var s,
                              o = l();
                          function d() {
                              a && a();
                          }
                          g(e).parent("picture")[0] || (e.complete && i) ? d() : t ? (((s = new o.Image()).onload = d), (s.onerror = d), r && (s.sizes = r), n && (s.srcset = n), t && (s.src = t)) : d();
                      },
                      preloadImages: function () {
                          var e = this;
                          function t() {
                              null != e && e && !e.destroyed && (void 0 !== e.imagesLoaded && (e.imagesLoaded += 1), e.imagesLoaded === e.imagesToLoad.length && (e.params.updateOnImagesReady && e.update(), e.emit("imagesReady")));
                          }
                          e.imagesToLoad = e.$el.find("img");
                          for (var n = 0; n < e.imagesToLoad.length; n += 1) {
                              var r = e.imagesToLoad[n];
                              e.loadImage(r, r.currentSrc || r.getAttribute("src"), r.srcset || r.getAttribute("srcset"), r.sizes || r.getAttribute("sizes"), !0, t);
                          }
                      },
                  },
              },
              W = {},
              V = (function () {
                  function t() {
                      for (var e, n, r = arguments.length, i = new Array(r), s = 0; s < r; s++) i[s] = arguments[s];
                      1 === i.length && i[0].constructor && i[0].constructor === Object ? (n = i[0]) : ((e = i[0]), (n = i[1])), n || (n = {}), (n = C({}, n)), e && !n.el && (n.el = e);
                      var o = this;
                      (o.support = P()),
                          (o.device = L({ userAgent: n.userAgent })),
                          (o.browser = A()),
                          (o.eventsListeners = {}),
                          (o.eventsAnyListeners = []),
                          void 0 === o.modules && (o.modules = {}),
                          Object.keys(o.modules).forEach(function (e) {
                              var t = o.modules[e];
                              if (t.params) {
                                  var r = Object.keys(t.params)[0],
                                      i = t.params[r];
                                  if ("object" != (0, a.default)(i) || null === i) return;
                                  if (!(r in n) || !("enabled" in i)) return;
                                  !0 === n[r] && (n[r] = { enabled: !0 }), "object" != (0, a.default)(n[r]) || "enabled" in n[r] || (n[r].enabled = !0), n[r] || (n[r] = { enabled: !1 });
                              }
                          });
                      var l = C({}, N);
                      o.useParams(l),
                          (o.params = C({}, l, W, n)),
                          (o.originalParams = C({}, o.params)),
                          (o.passedParams = C({}, n)),
                          o.params &&
                              o.params.on &&
                              Object.keys(o.params.on).forEach(function (e) {
                                  o.on(e, o.params.on[e]);
                              }),
                          o.params && o.params.onAny && o.onAny(o.params.onAny),
                          (o.$ = g);
                      var d = g(o.params.el);
                      if ((e = d[0])) {
                          if (d.length > 1) {
                              var u = [];
                              return (
                                  d.each(function (e) {
                                      var r = C({}, n, { el: e });
                                      u.push(new t(r));
                                  }),
                                  u
                              );
                          }
                          var c, p, f;
                          return (
                              (e.swiper = o),
                              e && e.shadowRoot && e.shadowRoot.querySelector
                                  ? ((c = g(e.shadowRoot.querySelector("." + o.params.wrapperClass))).children = function (e) {
                                        return d.children(e);
                                    })
                                  : (c = d.children("." + o.params.wrapperClass)),
                              C(o, {
                                  $el: d,
                                  el: e,
                                  $wrapperEl: c,
                                  wrapperEl: c[0],
                                  classNames: [],
                                  slides: g(),
                                  slidesGrid: [],
                                  snapGrid: [],
                                  slidesSizesGrid: [],
                                  isHorizontal: function () {
                                      return "horizontal" === o.params.direction;
                                  },
                                  isVertical: function () {
                                      return "vertical" === o.params.direction;
                                  },
                                  rtl: "rtl" === e.dir.toLowerCase() || "rtl" === d.css("direction"),
                                  rtlTranslate: "horizontal" === o.params.direction && ("rtl" === e.dir.toLowerCase() || "rtl" === d.css("direction")),
                                  wrongRTL: "-webkit-box" === c.css("display"),
                                  activeIndex: 0,
                                  realIndex: 0,
                                  isBeginning: !0,
                                  isEnd: !1,
                                  translate: 0,
                                  previousTranslate: 0,
                                  progress: 0,
                                  velocity: 0,
                                  animating: !1,
                                  allowSlideNext: o.params.allowSlideNext,
                                  allowSlidePrev: o.params.allowSlidePrev,
                                  touchEvents:
                                      ((p = ["touchstart", "touchmove", "touchend", "touchcancel"]),
                                      (f = ["mousedown", "mousemove", "mouseup"]),
                                      o.support.pointerEvents && (f = ["pointerdown", "pointermove", "pointerup"]),
                                      (o.touchEventsTouch = { start: p[0], move: p[1], end: p[2], cancel: p[3] }),
                                      (o.touchEventsDesktop = { start: f[0], move: f[1], end: f[2] }),
                                      o.support.touch || !o.params.simulateTouch ? o.touchEventsTouch : o.touchEventsDesktop),
                                  touchEventsData: {
                                      isTouched: void 0,
                                      isMoved: void 0,
                                      allowTouchCallbacks: void 0,
                                      touchStartTime: void 0,
                                      isScrolling: void 0,
                                      currentTranslate: void 0,
                                      startTranslate: void 0,
                                      allowThresholdMove: void 0,
                                      formElements: "input, select, option, textarea, button, video, label",
                                      lastClickTime: S(),
                                      clickTimeout: void 0,
                                      velocities: [],
                                      allowMomentumBounce: void 0,
                                      isTouchEvent: void 0,
                                      startMoving: void 0,
                                  },
                                  allowClick: !0,
                                  allowTouchMove: o.params.allowTouchMove,
                                  touches: { startX: 0, startY: 0, currentX: 0, currentY: 0, diff: 0 },
                                  imagesToLoad: [],
                                  imagesLoaded: 0,
                              }),
                              o.useModules(),
                              o.emit("_swiper"),
                              o.params.init && o.init(),
                              o
                          );
                      }
                  }
                  var n,
                      r,
                      i = t.prototype;
                  return (
                      (i.emitContainerClasses = function () {
                          var e = this;
                          if (e.params._emitClasses && e.el) {
                              var t = e.el.className.split(" ").filter(function (t) {
                                  return 0 === t.indexOf("swiper-container") || 0 === t.indexOf(e.params.containerModifierClass);
                              });
                              e.emit("_containerClasses", t.join(" "));
                          }
                      }),
                      (i.getSlideClasses = function (e) {
                          var t = this;
                          return e.className
                              .split(" ")
                              .filter(function (e) {
                                  return 0 === e.indexOf("swiper-slide") || 0 === e.indexOf(t.params.slideClass);
                              })
                              .join(" ");
                      }),
                      (i.emitSlidesClasses = function () {
                          var e = this;
                          e.params._emitClasses &&
                              e.el &&
                              e.slides.each(function (t) {
                                  var n = e.getSlideClasses(t);
                                  e.emit("_slideClass", t, n);
                              });
                      }),
                      (i.slidesPerViewDynamic = function () {
                          var e = this,
                              t = e.params,
                              n = e.slides,
                              r = e.slidesGrid,
                              i = e.size,
                              a = e.activeIndex,
                              s = 1;
                          if (t.centeredSlides) {
                              for (var o, l = n[a].swiperSlideSize, d = a + 1; d < n.length; d += 1) n[d] && !o && ((s += 1), (l += n[d].swiperSlideSize) > i && (o = !0));
                              for (var u = a - 1; u >= 0; u -= 1) n[u] && !o && ((s += 1), (l += n[u].swiperSlideSize) > i && (o = !0));
                          } else for (var c = a + 1; c < n.length; c += 1) r[c] - r[a] < i && (s += 1);
                          return s;
                      }),
                      (i.update = function () {
                          var e = this;
                          if (e && !e.destroyed) {
                              var t = e.snapGrid,
                                  n = e.params;
                              n.breakpoints && e.setBreakpoint(),
                                  e.updateSize(),
                                  e.updateSlides(),
                                  e.updateProgress(),
                                  e.updateSlidesClasses(),
                                  e.params.freeMode
                                      ? (r(), e.params.autoHeight && e.updateAutoHeight())
                                      : (("auto" === e.params.slidesPerView || e.params.slidesPerView > 1) && e.isEnd && !e.params.centeredSlides ? e.slideTo(e.slides.length - 1, 0, !1, !0) : e.slideTo(e.activeIndex, 0, !1, !0)) || r(),
                                  n.watchOverflow && t !== e.snapGrid && e.checkOverflow(),
                                  e.emit("update");
                          }
                          function r() {
                              var t = e.rtlTranslate ? -1 * e.translate : e.translate,
                                  n = Math.min(Math.max(t, e.maxTranslate()), e.minTranslate());
                              e.setTranslate(n), e.updateActiveIndex(), e.updateSlidesClasses();
                          }
                      }),
                      (i.changeDirection = function (e, t) {
                          void 0 === t && (t = !0);
                          var n = this,
                              r = n.params.direction;
                          return (
                              e || (e = "horizontal" === r ? "vertical" : "horizontal"),
                              e === r ||
                                  ("horizontal" !== e && "vertical" !== e) ||
                                  (n.$el.removeClass("" + n.params.containerModifierClass + r).addClass("" + n.params.containerModifierClass + e),
                                  n.emitContainerClasses(),
                                  (n.params.direction = e),
                                  n.slides.each(function (t) {
                                      "vertical" === e ? (t.style.width = "") : (t.style.height = "");
                                  }),
                                  n.emit("changeDirection"),
                                  t && n.update()),
                              n
                          );
                      }),
                      (i.init = function () {
                          var e = this;
                          e.initialized ||
                              (e.emit("beforeInit"),
                              e.params.breakpoints && e.setBreakpoint(),
                              e.addClasses(),
                              e.params.loop && e.loopCreate(),
                              e.updateSize(),
                              e.updateSlides(),
                              e.params.watchOverflow && e.checkOverflow(),
                              e.params.grabCursor && e.setGrabCursor(),
                              e.params.preloadImages && e.preloadImages(),
                              e.params.loop ? e.slideTo(e.params.initialSlide + e.loopedSlides, 0, e.params.runCallbacksOnInit) : e.slideTo(e.params.initialSlide, 0, e.params.runCallbacksOnInit),
                              e.attachEvents(),
                              (e.initialized = !0),
                              e.emit("init"),
                              e.emit("afterInit"));
                      }),
                      (i.destroy = function (e, t) {
                          void 0 === e && (e = !0), void 0 === t && (t = !0);
                          var n,
                              r = this,
                              i = r.params,
                              a = r.$el,
                              s = r.$wrapperEl,
                              o = r.slides;
                          return (
                              void 0 === r.params ||
                                  r.destroyed ||
                                  (r.emit("beforeDestroy"),
                                  (r.initialized = !1),
                                  r.detachEvents(),
                                  i.loop && r.loopDestroy(),
                                  t &&
                                      (r.removeClasses(),
                                      a.removeAttr("style"),
                                      s.removeAttr("style"),
                                      o && o.length && o.removeClass([i.slideVisibleClass, i.slideActiveClass, i.slideNextClass, i.slidePrevClass].join(" ")).removeAttr("style").removeAttr("data-swiper-slide-index")),
                                  r.emit("destroy"),
                                  Object.keys(r.eventsListeners).forEach(function (e) {
                                      r.off(e);
                                  }),
                                  !1 !== e &&
                                      ((r.$el[0].swiper = null),
                                      (n = r),
                                      Object.keys(n).forEach(function (e) {
                                          try {
                                              n[e] = null;
                                          } catch (e) {}
                                          try {
                                              delete n[e];
                                          } catch (e) {}
                                      })),
                                  (r.destroyed = !0)),
                              null
                          );
                      }),
                      (t.extendDefaults = function (e) {
                          C(W, e);
                      }),
                      (t.installModule = function (e) {
                          t.prototype.modules || (t.prototype.modules = {});
                          var n = e.name || Object.keys(t.prototype.modules).length + "_" + S();
                          t.prototype.modules[n] = e;
                      }),
                      (t.use = function (e) {
                          return Array.isArray(e)
                              ? (e.forEach(function (e) {
                                    return t.installModule(e);
                                }),
                                t)
                              : (t.installModule(e), t);
                      }),
                      (n = t),
                      (r = [
                          {
                              key: "extendedDefaults",
                              get: function () {
                                  return W;
                              },
                          },
                          {
                              key: "defaults",
                              get: function () {
                                  return N;
                              },
                          },
                      ]),
                      null && e(n.prototype, null),
                      r && e(n, r),
                      t
                  );
              })();
          Object.keys(G).forEach(function (e) {
              Object.keys(G[e]).forEach(function (t) {
                  V.prototype[t] = G[e][t];
              });
          }),
              V.use([k, I]);
          var Y = {
                  update: function (e) {
                      var t = this,
                          n = t.params,
                          r = n.slidesPerView,
                          i = n.slidesPerGroup,
                          a = n.centeredSlides,
                          s = t.params.virtual,
                          o = s.addSlidesBefore,
                          l = s.addSlidesAfter,
                          d = t.virtual,
                          u = d.from,
                          c = d.to,
                          p = d.slides,
                          f = d.slidesGrid,
                          h = d.renderSlide,
                          m = d.offset;
                      t.updateActiveIndex();
                      var v,
                          g,
                          y,
                          w = t.activeIndex || 0;
                      (v = t.rtlTranslate ? "right" : t.isHorizontal() ? "left" : "top"), a ? ((g = Math.floor(r / 2) + i + l), (y = Math.floor(r / 2) + i + o)) : ((g = r + (i - 1) + l), (y = i + o));
                      var b = Math.max((w || 0) - y, 0),
                          E = Math.min((w || 0) + g, p.length - 1),
                          x = (t.slidesGrid[b] || 0) - (t.slidesGrid[0] || 0);
                      function S() {
                          t.updateSlides(), t.updateProgress(), t.updateSlidesClasses(), t.lazy && t.params.lazy.enabled && t.lazy.load();
                      }
                      if ((C(t.virtual, { from: b, to: E, offset: x, slidesGrid: t.slidesGrid }), u === b && c === E && !e)) return t.slidesGrid !== f && x !== m && t.slides.css(v, x + "px"), void t.updateProgress();
                      if (t.params.virtual.renderExternal)
                          return (
                              t.params.virtual.renderExternal.call(t, {
                                  offset: x,
                                  from: b,
                                  to: E,
                                  slides: (function () {
                                      for (var e = [], t = b; t <= E; t += 1) e.push(p[t]);
                                      return e;
                                  })(),
                              }),
                              void (t.params.virtual.renderExternalUpdate && S())
                          );
                      var T = [],
                          _ = [];
                      if (e) t.$wrapperEl.find("." + t.params.slideClass).remove();
                      else for (var M = u; M <= c; M += 1) (M < b || M > E) && t.$wrapperEl.find("." + t.params.slideClass + '[data-swiper-slide-index="' + M + '"]').remove();
                      for (var P = 0; P < p.length; P += 1) P >= b && P <= E && (void 0 === c || e ? _.push(P) : (P > c && _.push(P), P < u && T.push(P)));
                      _.forEach(function (e) {
                          t.$wrapperEl.append(h(p[e], e));
                      }),
                          T.sort(function (e, t) {
                              return t - e;
                          }).forEach(function (e) {
                              t.$wrapperEl.prepend(h(p[e], e));
                          }),
                          t.$wrapperEl.children(".swiper-slide").css(v, x + "px"),
                          S();
                  },
                  renderSlide: function (e, t) {
                      var n = this,
                          r = n.params.virtual;
                      if (r.cache && n.virtual.cache[t]) return n.virtual.cache[t];
                      var i = r.renderSlide ? g(r.renderSlide.call(n, e, t)) : g('<div class="' + n.params.slideClass + '" data-swiper-slide-index="' + t + '">' + e + "</div>");
                      return i.attr("data-swiper-slide-index") || i.attr("data-swiper-slide-index", t), r.cache && (n.virtual.cache[t] = i), i;
                  },
                  appendSlide: function (e) {
                      var t = this;
                      if ("object" == (0, a.default)(e) && "length" in e) for (var n = 0; n < e.length; n += 1) e[n] && t.virtual.slides.push(e[n]);
                      else t.virtual.slides.push(e);
                      t.virtual.update(!0);
                  },
                  prependSlide: function (e) {
                      var t = this,
                          n = t.activeIndex,
                          r = n + 1,
                          i = 1;
                      if (Array.isArray(e)) {
                          for (var a = 0; a < e.length; a += 1) e[a] && t.virtual.slides.unshift(e[a]);
                          (r = n + e.length), (i = e.length);
                      } else t.virtual.slides.unshift(e);
                      if (t.params.virtual.cache) {
                          var s = t.virtual.cache,
                              o = {};
                          Object.keys(s).forEach(function (e) {
                              var t = s[e],
                                  n = t.attr("data-swiper-slide-index");
                              n && t.attr("data-swiper-slide-index", parseInt(n, 10) + 1), (o[parseInt(e, 10) + i] = t);
                          }),
                              (t.virtual.cache = o);
                      }
                      t.virtual.update(!0), t.slideTo(r, 0);
                  },
                  removeSlide: function (e) {
                      var t = this;
                      if (null != e) {
                          var n = t.activeIndex;
                          if (Array.isArray(e)) for (var r = e.length - 1; r >= 0; r -= 1) t.virtual.slides.splice(e[r], 1), t.params.virtual.cache && delete t.virtual.cache[e[r]], e[r] < n && (n -= 1), (n = Math.max(n, 0));
                          else t.virtual.slides.splice(e, 1), t.params.virtual.cache && delete t.virtual.cache[e], e < n && (n -= 1), (n = Math.max(n, 0));
                          t.virtual.update(!0), t.slideTo(n, 0);
                      }
                  },
                  removeAllSlides: function () {
                      var e = this;
                      (e.virtual.slides = []), e.params.virtual.cache && (e.virtual.cache = {}), e.virtual.update(!0), e.slideTo(0, 0);
                  },
              },
              X = {
                  name: "virtual",
                  params: { virtual: { enabled: !1, slides: [], cache: !0, renderSlide: null, renderExternal: null, renderExternalUpdate: !0, addSlidesBefore: 0, addSlidesAfter: 0 } },
                  create: function () {
                      M(this, { virtual: t({}, Y, { slides: this.params.virtual.slides, cache: {} }) });
                  },
                  on: {
                      beforeInit: function (e) {
                          if (e.params.virtual.enabled) {
                              e.classNames.push(e.params.containerModifierClass + "virtual");
                              var t = { watchSlidesProgress: !0 };
                              C(e.params, t), C(e.originalParams, t), e.params.initialSlide || e.virtual.update();
                          }
                      },
                      setTranslate: function (e) {
                          e.params.virtual.enabled && e.virtual.update();
                      },
                  },
              },
              j = {
                  handle: function (e) {
                      var t = this,
                          n = l(),
                          r = s(),
                          i = t.rtlTranslate,
                          a = e;
                      a.originalEvent && (a = a.originalEvent);
                      var o = a.keyCode || a.charCode,
                          d = t.params.keyboard.pageUpDown,
                          u = d && 33 === o,
                          c = d && 34 === o,
                          p = 37 === o,
                          f = 39 === o,
                          h = 38 === o,
                          m = 40 === o;
                      if (!t.allowSlideNext && ((t.isHorizontal() && f) || (t.isVertical() && m) || c)) return !1;
                      if (!t.allowSlidePrev && ((t.isHorizontal() && p) || (t.isVertical() && h) || u)) return !1;
                      if (
                          !(
                              a.shiftKey ||
                              a.altKey ||
                              a.ctrlKey ||
                              a.metaKey ||
                              (r.activeElement && r.activeElement.nodeName && ("input" === r.activeElement.nodeName.toLowerCase() || "textarea" === r.activeElement.nodeName.toLowerCase()))
                          )
                      ) {
                          if (t.params.keyboard.onlyInViewport && (u || c || p || f || h || m)) {
                              var v = !1;
                              if (t.$el.parents("." + t.params.slideClass).length > 0 && 0 === t.$el.parents("." + t.params.slideActiveClass).length) return;
                              var g = n.innerWidth,
                                  y = n.innerHeight,
                                  w = t.$el.offset();
                              i && (w.left -= t.$el[0].scrollLeft);
                              for (
                                  var b = [
                                          [w.left, w.top],
                                          [w.left + t.width, w.top],
                                          [w.left, w.top + t.height],
                                          [w.left + t.width, w.top + t.height],
                                      ],
                                      E = 0;
                                  E < b.length;
                                  E += 1
                              ) {
                                  var x = b[E];
                                  if (x[0] >= 0 && x[0] <= g && x[1] >= 0 && x[1] <= y) {
                                      if (0 === x[0] && 0 === x[1]) continue;
                                      v = !0;
                                  }
                              }
                              if (!v) return;
                          }
                          t.isHorizontal()
                              ? ((u || c || p || f) && (a.preventDefault ? a.preventDefault() : (a.returnValue = !1)), (((c || f) && !i) || ((u || p) && i)) && t.slideNext(), (((u || p) && !i) || ((c || f) && i)) && t.slidePrev())
                              : ((u || c || h || m) && (a.preventDefault ? a.preventDefault() : (a.returnValue = !1)), (c || m) && t.slideNext(), (u || h) && t.slidePrev()),
                              t.emit("keyPress", o);
                      }
                  },
                  enable: function () {
                      var e = this,
                          t = s();
                      e.keyboard.enabled || (g(t).on("keydown", e.keyboard.handle), (e.keyboard.enabled = !0));
                  },
                  disable: function () {
                      var e = this,
                          t = s();
                      e.keyboard.enabled && (g(t).off("keydown", e.keyboard.handle), (e.keyboard.enabled = !1));
                  },
              },
              U = {
                  name: "keyboard",
                  params: { keyboard: { enabled: !1, onlyInViewport: !0, pageUpDown: !0 } },
                  create: function () {
                      M(this, { keyboard: t({ enabled: !1 }, j) });
                  },
                  on: {
                      init: function (e) {
                          e.params.keyboard.enabled && e.keyboard.enable();
                      },
                      destroy: function (e) {
                          e.keyboard.enabled && e.keyboard.disable();
                      },
                  },
              },
              K = {
                  lastScrollTime: S(),
                  lastEventBeforeSnap: void 0,
                  recentWheelEvents: [],
                  event: function () {
                      return l().navigator.userAgent.indexOf("firefox") > -1
                          ? "DOMMouseScroll"
                          : (function () {
                                var e = s(),
                                    t = "onwheel",
                                    n = t in e;
                                if (!n) {
                                    var r = e.createElement("div");
                                    r.setAttribute(t, "return;"), (n = "function" == typeof r.onwheel);
                                }
                                return !n && e.implementation && e.implementation.hasFeature && !0 !== e.implementation.hasFeature("", "") && (n = e.implementation.hasFeature("Events.wheel", "3.0")), n;
                            })()
                          ? "wheel"
                          : "mousewheel";
                  },
                  normalize: function (e) {
                      var t = 0,
                          n = 0,
                          r = 0,
                          i = 0;
                      return (
                          "detail" in e && (n = e.detail),
                          "wheelDelta" in e && (n = -e.wheelDelta / 120),
                          "wheelDeltaY" in e && (n = -e.wheelDeltaY / 120),
                          "wheelDeltaX" in e && (t = -e.wheelDeltaX / 120),
                          "axis" in e && e.axis === e.HORIZONTAL_AXIS && ((t = n), (n = 0)),
                          (r = 10 * t),
                          (i = 10 * n),
                          "deltaY" in e && (i = e.deltaY),
                          "deltaX" in e && (r = e.deltaX),
                          e.shiftKey && !r && ((r = i), (i = 0)),
                          (r || i) && e.deltaMode && (1 === e.deltaMode ? ((r *= 40), (i *= 40)) : ((r *= 800), (i *= 800))),
                          r && !t && (t = r < 1 ? -1 : 1),
                          i && !n && (n = i < 1 ? -1 : 1),
                          { spinX: t, spinY: n, pixelX: r, pixelY: i }
                      );
                  },
                  handleMouseEnter: function () {
                      this.mouseEntered = !0;
                  },
                  handleMouseLeave: function () {
                      this.mouseEntered = !1;
                  },
                  handle: function (e) {
                      var t = e,
                          n = this,
                          r = n.params.mousewheel;
                      n.params.cssMode && t.preventDefault();
                      var i = n.$el;
                      if (("container" !== n.params.mousewheel.eventsTarget && (i = g(n.params.mousewheel.eventsTarget)), !n.mouseEntered && !i[0].contains(t.target) && !r.releaseOnEdges)) return !0;
                      t.originalEvent && (t = t.originalEvent);
                      var a = 0,
                          s = n.rtlTranslate ? -1 : 1,
                          o = K.normalize(t);
                      if (r.forceToAxis)
                          if (n.isHorizontal()) {
                              if (!(Math.abs(o.pixelX) > Math.abs(o.pixelY))) return !0;
                              a = -o.pixelX * s;
                          } else {
                              if (!(Math.abs(o.pixelY) > Math.abs(o.pixelX))) return !0;
                              a = -o.pixelY;
                          }
                      else a = Math.abs(o.pixelX) > Math.abs(o.pixelY) ? -o.pixelX * s : -o.pixelY;
                      if (0 === a) return !0;
                      r.invert && (a = -a);
                      var l = n.getTranslate() + a * r.sensitivity;
                      if (
                          (l >= n.minTranslate() && (l = n.minTranslate()),
                          l <= n.maxTranslate() && (l = n.maxTranslate()),
                          (!!n.params.loop || !(l === n.minTranslate() || l === n.maxTranslate())) && n.params.nested && t.stopPropagation(),
                          n.params.freeMode)
                      ) {
                          var d = { time: S(), delta: Math.abs(a), direction: Math.sign(a) },
                              u = n.mousewheel.lastEventBeforeSnap,
                              c = u && d.time < u.time + 500 && d.delta <= u.delta && d.direction === u.direction;
                          if (!c) {
                              (n.mousewheel.lastEventBeforeSnap = void 0), n.params.loop && n.loopFix();
                              var p = n.getTranslate() + a * r.sensitivity,
                                  f = n.isBeginning,
                                  h = n.isEnd;
                              if (
                                  (p >= n.minTranslate() && (p = n.minTranslate()),
                                  p <= n.maxTranslate() && (p = n.maxTranslate()),
                                  n.setTransition(0),
                                  n.setTranslate(p),
                                  n.updateProgress(),
                                  n.updateActiveIndex(),
                                  n.updateSlidesClasses(),
                                  ((!f && n.isBeginning) || (!h && n.isEnd)) && n.updateSlidesClasses(),
                                  n.params.freeModeSticky)
                              ) {
                                  clearTimeout(n.mousewheel.timeout), (n.mousewheel.timeout = void 0);
                                  var m = n.mousewheel.recentWheelEvents;
                                  m.length >= 15 && m.shift();
                                  var v = m.length ? m[m.length - 1] : void 0,
                                      y = m[0];
                                  if ((m.push(d), v && (d.delta > v.delta || d.direction !== v.direction))) m.splice(0);
                                  else if (m.length >= 15 && d.time - y.time < 500 && y.delta - d.delta >= 1 && d.delta <= 6) {
                                      var w = a > 0 ? 0.8 : 0.2;
                                      (n.mousewheel.lastEventBeforeSnap = d),
                                          m.splice(0),
                                          (n.mousewheel.timeout = x(function () {
                                              n.slideToClosest(n.params.speed, !0, void 0, w);
                                          }, 0));
                                  }
                                  n.mousewheel.timeout ||
                                      (n.mousewheel.timeout = x(function () {
                                          (n.mousewheel.lastEventBeforeSnap = d), m.splice(0), n.slideToClosest(n.params.speed, !0, void 0, 0.5);
                                      }, 500));
                              }
                              if ((c || n.emit("scroll", t), n.params.autoplay && n.params.autoplayDisableOnInteraction && n.autoplay.stop(), p === n.minTranslate() || p === n.maxTranslate())) return !0;
                          }
                      } else {
                          var b = { time: S(), delta: Math.abs(a), direction: Math.sign(a), raw: e },
                              E = n.mousewheel.recentWheelEvents;
                          E.length >= 2 && E.shift();
                          var T = E.length ? E[E.length - 1] : void 0;
                          if ((E.push(b), T ? (b.direction !== T.direction || b.delta > T.delta || b.time > T.time + 150) && n.mousewheel.animateSlider(b) : n.mousewheel.animateSlider(b), n.mousewheel.releaseScroll(b))) return !0;
                      }
                      return t.preventDefault ? t.preventDefault() : (t.returnValue = !1), !1;
                  },
                  animateSlider: function (e) {
                      var t = this,
                          n = l();
                      return !(
                          (this.params.mousewheel.thresholdDelta && e.delta < this.params.mousewheel.thresholdDelta) ||
                          (this.params.mousewheel.thresholdTime && S() - t.mousewheel.lastScrollTime < this.params.mousewheel.thresholdTime) ||
                          (!(e.delta >= 6 && S() - t.mousewheel.lastScrollTime < 60) &&
                              (e.direction < 0 ? (t.isEnd && !t.params.loop) || t.animating || (t.slideNext(), t.emit("scroll", e.raw)) : (t.isBeginning && !t.params.loop) || t.animating || (t.slidePrev(), t.emit("scroll", e.raw)),
                              (t.mousewheel.lastScrollTime = new n.Date().getTime()),
                              1))
                      );
                  },
                  releaseScroll: function (e) {
                      var t = this,
                          n = t.params.mousewheel;
                      if (e.direction < 0) {
                          if (t.isEnd && !t.params.loop && n.releaseOnEdges) return !0;
                      } else if (t.isBeginning && !t.params.loop && n.releaseOnEdges) return !0;
                      return !1;
                  },
                  enable: function () {
                      var e = this,
                          t = K.event();
                      if (e.params.cssMode) return e.wrapperEl.removeEventListener(t, e.mousewheel.handle), !0;
                      if (!t) return !1;
                      if (e.mousewheel.enabled) return !1;
                      var n = e.$el;
                      return (
                          "container" !== e.params.mousewheel.eventsTarget && (n = g(e.params.mousewheel.eventsTarget)),
                          n.on("mouseenter", e.mousewheel.handleMouseEnter),
                          n.on("mouseleave", e.mousewheel.handleMouseLeave),
                          n.on(t, e.mousewheel.handle),
                          (e.mousewheel.enabled = !0),
                          !0
                      );
                  },
                  disable: function () {
                      var e = this,
                          t = K.event();
                      if (e.params.cssMode) return e.wrapperEl.addEventListener(t, e.mousewheel.handle), !0;
                      if (!t) return !1;
                      if (!e.mousewheel.enabled) return !1;
                      var n = e.$el;
                      return "container" !== e.params.mousewheel.eventsTarget && (n = g(e.params.mousewheel.eventsTarget)), n.off(t, e.mousewheel.handle), (e.mousewheel.enabled = !1), !0;
                  },
              },
              Q = {
                  update: function () {
                      var e = this,
                          t = e.params.navigation;
                      if (!e.params.loop) {
                          var n = e.navigation,
                              r = n.$nextEl,
                              i = n.$prevEl;
                          i && i.length > 0 && (e.isBeginning ? i.addClass(t.disabledClass) : i.removeClass(t.disabledClass), i[e.params.watchOverflow && e.isLocked ? "addClass" : "removeClass"](t.lockClass)),
                              r && r.length > 0 && (e.isEnd ? r.addClass(t.disabledClass) : r.removeClass(t.disabledClass), r[e.params.watchOverflow && e.isLocked ? "addClass" : "removeClass"](t.lockClass));
                      }
                  },
                  onPrevClick: function (e) {
                      var t = this;
                      e.preventDefault(), (t.isBeginning && !t.params.loop) || t.slidePrev();
                  },
                  onNextClick: function (e) {
                      var t = this;
                      e.preventDefault(), (t.isEnd && !t.params.loop) || t.slideNext();
                  },
                  init: function () {
                      var e,
                          t,
                          n = this,
                          r = n.params.navigation;
                      (r.nextEl || r.prevEl) &&
                          (r.nextEl && ((e = g(r.nextEl)), n.params.uniqueNavElements && "string" == typeof r.nextEl && e.length > 1 && 1 === n.$el.find(r.nextEl).length && (e = n.$el.find(r.nextEl))),
                          r.prevEl && ((t = g(r.prevEl)), n.params.uniqueNavElements && "string" == typeof r.prevEl && t.length > 1 && 1 === n.$el.find(r.prevEl).length && (t = n.$el.find(r.prevEl))),
                          e && e.length > 0 && e.on("click", n.navigation.onNextClick),
                          t && t.length > 0 && t.on("click", n.navigation.onPrevClick),
                          C(n.navigation, { $nextEl: e, nextEl: e && e[0], $prevEl: t, prevEl: t && t[0] }));
                  },
                  destroy: function () {
                      var e = this,
                          t = e.navigation,
                          n = t.$nextEl,
                          r = t.$prevEl;
                      n && n.length && (n.off("click", e.navigation.onNextClick), n.removeClass(e.params.navigation.disabledClass)),
                          r && r.length && (r.off("click", e.navigation.onPrevClick), r.removeClass(e.params.navigation.disabledClass));
                  },
              },
              Z = {
                  update: function () {
                      var e = this,
                          t = e.rtl,
                          n = e.params.pagination;
                      if (n.el && e.pagination.el && e.pagination.$el && 0 !== e.pagination.$el.length) {
                          var r,
                              i = e.virtual && e.params.virtual.enabled ? e.virtual.slides.length : e.slides.length,
                              a = e.pagination.$el,
                              s = e.params.loop ? Math.ceil((i - 2 * e.loopedSlides) / e.params.slidesPerGroup) : e.snapGrid.length;
                          if (
                              (e.params.loop
                                  ? ((r = Math.ceil((e.activeIndex - e.loopedSlides) / e.params.slidesPerGroup)) > i - 1 - 2 * e.loopedSlides && (r -= i - 2 * e.loopedSlides),
                                    r > s - 1 && (r -= s),
                                    r < 0 && "bullets" !== e.params.paginationType && (r = s + r))
                                  : (r = void 0 !== e.snapIndex ? e.snapIndex : e.activeIndex || 0),
                              "bullets" === n.type && e.pagination.bullets && e.pagination.bullets.length > 0)
                          ) {
                              var o,
                                  l,
                                  d,
                                  u = e.pagination.bullets;
                              if (
                                  (n.dynamicBullets &&
                                      ((e.pagination.bulletSize = u.eq(0)[e.isHorizontal() ? "outerWidth" : "outerHeight"](!0)),
                                      a.css(e.isHorizontal() ? "width" : "height", e.pagination.bulletSize * (n.dynamicMainBullets + 4) + "px"),
                                      n.dynamicMainBullets > 1 &&
                                          void 0 !== e.previousIndex &&
                                          ((e.pagination.dynamicBulletIndex += r - e.previousIndex),
                                          e.pagination.dynamicBulletIndex > n.dynamicMainBullets - 1
                                              ? (e.pagination.dynamicBulletIndex = n.dynamicMainBullets - 1)
                                              : e.pagination.dynamicBulletIndex < 0 && (e.pagination.dynamicBulletIndex = 0)),
                                      (o = r - e.pagination.dynamicBulletIndex),
                                      (d = ((l = o + (Math.min(u.length, n.dynamicMainBullets) - 1)) + o) / 2)),
                                  u.removeClass(
                                      n.bulletActiveClass + " " + n.bulletActiveClass + "-next " + n.bulletActiveClass + "-next-next " + n.bulletActiveClass + "-prev " + n.bulletActiveClass + "-prev-prev " + n.bulletActiveClass + "-main"
                                  ),
                                  a.length > 1)
                              )
                                  u.each(function (e) {
                                      var t = g(e),
                                          i = t.index();
                                      i === r && t.addClass(n.bulletActiveClass),
                                          n.dynamicBullets &&
                                              (i >= o && i <= l && t.addClass(n.bulletActiveClass + "-main"),
                                              i === o &&
                                                  t
                                                      .prev()
                                                      .addClass(n.bulletActiveClass + "-prev")
                                                      .prev()
                                                      .addClass(n.bulletActiveClass + "-prev-prev"),
                                              i === l &&
                                                  t
                                                      .next()
                                                      .addClass(n.bulletActiveClass + "-next")
                                                      .next()
                                                      .addClass(n.bulletActiveClass + "-next-next"));
                                  });
                              else {
                                  var c = u.eq(r),
                                      p = c.index();
                                  if ((c.addClass(n.bulletActiveClass), n.dynamicBullets)) {
                                      for (var f = u.eq(o), h = u.eq(l), m = o; m <= l; m += 1) u.eq(m).addClass(n.bulletActiveClass + "-main");
                                      if (e.params.loop)
                                          if (p >= u.length - n.dynamicMainBullets) {
                                              for (var v = n.dynamicMainBullets; v >= 0; v -= 1) u.eq(u.length - v).addClass(n.bulletActiveClass + "-main");
                                              u.eq(u.length - n.dynamicMainBullets - 1).addClass(n.bulletActiveClass + "-prev");
                                          } else
                                              f
                                                  .prev()
                                                  .addClass(n.bulletActiveClass + "-prev")
                                                  .prev()
                                                  .addClass(n.bulletActiveClass + "-prev-prev"),
                                                  h
                                                      .next()
                                                      .addClass(n.bulletActiveClass + "-next")
                                                      .next()
                                                      .addClass(n.bulletActiveClass + "-next-next");
                                      else
                                          f
                                              .prev()
                                              .addClass(n.bulletActiveClass + "-prev")
                                              .prev()
                                              .addClass(n.bulletActiveClass + "-prev-prev"),
                                              h
                                                  .next()
                                                  .addClass(n.bulletActiveClass + "-next")
                                                  .next()
                                                  .addClass(n.bulletActiveClass + "-next-next");
                                  }
                              }
                              if (n.dynamicBullets) {
                                  var y = Math.min(u.length, n.dynamicMainBullets + 4),
                                      w = (e.pagination.bulletSize * y - e.pagination.bulletSize) / 2 - d * e.pagination.bulletSize,
                                      b = t ? "right" : "left";
                                  u.css(e.isHorizontal() ? b : "top", w + "px");
                              }
                          }
                          if (("fraction" === n.type && (a.find("." + n.currentClass).text(n.formatFractionCurrent(r + 1)), a.find("." + n.totalClass).text(n.formatFractionTotal(s))), "progressbar" === n.type)) {
                              var E;
                              E = n.progressbarOpposite ? (e.isHorizontal() ? "vertical" : "horizontal") : e.isHorizontal() ? "horizontal" : "vertical";
                              var x = (r + 1) / s,
                                  S = 1,
                                  T = 1;
                              "horizontal" === E ? (S = x) : (T = x),
                                  a
                                      .find("." + n.progressbarFillClass)
                                      .transform("translate3d(0,0,0) scaleX(" + S + ") scaleY(" + T + ")")
                                      .transition(e.params.speed);
                          }
                          "custom" === n.type && n.renderCustom ? (a.html(n.renderCustom(e, r + 1, s)), e.emit("paginationRender", a[0])) : e.emit("paginationUpdate", a[0]),
                              a[e.params.watchOverflow && e.isLocked ? "addClass" : "removeClass"](n.lockClass);
                      }
                  },
                  render: function () {
                      var e = this,
                          t = e.params.pagination;
                      if (t.el && e.pagination.el && e.pagination.$el && 0 !== e.pagination.$el.length) {
                          var n = e.virtual && e.params.virtual.enabled ? e.virtual.slides.length : e.slides.length,
                              r = e.pagination.$el,
                              i = "";
                          if ("bullets" === t.type) {
                              for (var a = e.params.loop ? Math.ceil((n - 2 * e.loopedSlides) / e.params.slidesPerGroup) : e.snapGrid.length, s = 0; s < a; s += 1)
                                  t.renderBullet ? (i += t.renderBullet.call(e, s, t.bulletClass)) : (i += "<" + t.bulletElement + ' class="' + t.bulletClass + '"></' + t.bulletElement + ">");
                              r.html(i), (e.pagination.bullets = r.find("." + t.bulletClass.replace(/ /g, ".")));
                          }
                          "fraction" === t.type && ((i = t.renderFraction ? t.renderFraction.call(e, t.currentClass, t.totalClass) : '<span class="' + t.currentClass + '"></span> / <span class="' + t.totalClass + '"></span>'), r.html(i)),
                              "progressbar" === t.type && ((i = t.renderProgressbar ? t.renderProgressbar.call(e, t.progressbarFillClass) : '<span class="' + t.progressbarFillClass + '"></span>'), r.html(i)),
                              "custom" !== t.type && e.emit("paginationRender", e.pagination.$el[0]);
                      }
                  },
                  init: function () {
                      var e = this,
                          t = e.params.pagination;
                      if (t.el) {
                          var n = g(t.el);
                          0 !== n.length &&
                              (e.params.uniqueNavElements && "string" == typeof t.el && n.length > 1 && (n = e.$el.find(t.el)),
                              "bullets" === t.type && t.clickable && n.addClass(t.clickableClass),
                              n.addClass(t.modifierClass + t.type),
                              "bullets" === t.type && t.dynamicBullets && (n.addClass("" + t.modifierClass + t.type + "-dynamic"), (e.pagination.dynamicBulletIndex = 0), t.dynamicMainBullets < 1 && (t.dynamicMainBullets = 1)),
                              "progressbar" === t.type && t.progressbarOpposite && n.addClass(t.progressbarOppositeClass),
                              t.clickable &&
                                  n.on("click", "." + t.bulletClass.replace(/ /g, "."), function (t) {
                                      t.preventDefault();
                                      var n = g(this).index() * e.params.slidesPerGroup;
                                      e.params.loop && (n += e.loopedSlides), e.slideTo(n);
                                  }),
                              C(e.pagination, { $el: n, el: n[0] }));
                      }
                  },
                  destroy: function () {
                      var e = this,
                          t = e.params.pagination;
                      if (t.el && e.pagination.el && e.pagination.$el && 0 !== e.pagination.$el.length) {
                          var n = e.pagination.$el;
                          n.removeClass(t.hiddenClass),
                              n.removeClass(t.modifierClass + t.type),
                              e.pagination.bullets && e.pagination.bullets.removeClass(t.bulletActiveClass),
                              t.clickable && n.off("click", "." + t.bulletClass.replace(/ /g, "."));
                      }
                  },
              },
              J = {
                  setTranslate: function () {
                      var e = this;
                      if (e.params.scrollbar.el && e.scrollbar.el) {
                          var t = e.scrollbar,
                              n = e.rtlTranslate,
                              r = e.progress,
                              i = t.dragSize,
                              a = t.trackSize,
                              s = t.$dragEl,
                              o = t.$el,
                              l = e.params.scrollbar,
                              d = i,
                              u = (a - i) * r;
                          n ? ((u = -u) > 0 ? ((d = i - u), (u = 0)) : -u + i > a && (d = a + u)) : u < 0 ? ((d = i + u), (u = 0)) : u + i > a && (d = a - u),
                              e.isHorizontal() ? (s.transform("translate3d(" + u + "px, 0, 0)"), (s[0].style.width = d + "px")) : (s.transform("translate3d(0px, " + u + "px, 0)"), (s[0].style.height = d + "px")),
                              l.hide &&
                                  (clearTimeout(e.scrollbar.timeout),
                                  (o[0].style.opacity = 1),
                                  (e.scrollbar.timeout = setTimeout(function () {
                                      (o[0].style.opacity = 0), o.transition(400);
                                  }, 1e3)));
                      }
                  },
                  setTransition: function (e) {
                      var t = this;
                      t.params.scrollbar.el && t.scrollbar.el && t.scrollbar.$dragEl.transition(e);
                  },
                  updateSize: function () {
                      var e = this;
                      if (e.params.scrollbar.el && e.scrollbar.el) {
                          var t = e.scrollbar,
                              n = t.$dragEl,
                              r = t.$el;
                          (n[0].style.width = ""), (n[0].style.height = "");
                          var i,
                              a = e.isHorizontal() ? r[0].offsetWidth : r[0].offsetHeight,
                              s = e.size / e.virtualSize,
                              o = s * (a / e.size);
                          (i = "auto" === e.params.scrollbar.dragSize ? a * s : parseInt(e.params.scrollbar.dragSize, 10)),
                              e.isHorizontal() ? (n[0].style.width = i + "px") : (n[0].style.height = i + "px"),
                              (r[0].style.display = s >= 1 ? "none" : ""),
                              e.params.scrollbar.hide && (r[0].style.opacity = 0),
                              C(t, { trackSize: a, divider: s, moveDivider: o, dragSize: i }),
                              t.$el[e.params.watchOverflow && e.isLocked ? "addClass" : "removeClass"](e.params.scrollbar.lockClass);
                      }
                  },
                  getPointerPosition: function (e) {
                      return this.isHorizontal() ? ("touchstart" === e.type || "touchmove" === e.type ? e.targetTouches[0].clientX : e.clientX) : "touchstart" === e.type || "touchmove" === e.type ? e.targetTouches[0].clientY : e.clientY;
                  },
                  setDragPosition: function (e) {
                      var t,
                          n = this,
                          r = n.scrollbar,
                          i = n.rtlTranslate,
                          a = r.$el,
                          s = r.dragSize,
                          o = r.trackSize,
                          l = r.dragStartPos;
                      (t = (r.getPointerPosition(e) - a.offset()[n.isHorizontal() ? "left" : "top"] - (null !== l ? l : s / 2)) / (o - s)), (t = Math.max(Math.min(t, 1), 0)), i && (t = 1 - t);
                      var d = n.minTranslate() + (n.maxTranslate() - n.minTranslate()) * t;
                      n.updateProgress(d), n.setTranslate(d), n.updateActiveIndex(), n.updateSlidesClasses();
                  },
                  onDragStart: function (e) {
                      var t = this,
                          n = t.params.scrollbar,
                          r = t.scrollbar,
                          i = t.$wrapperEl,
                          a = r.$el,
                          s = r.$dragEl;
                      (t.scrollbar.isTouched = !0),
                          (t.scrollbar.dragStartPos = e.target === s[0] || e.target === s ? r.getPointerPosition(e) - e.target.getBoundingClientRect()[t.isHorizontal() ? "left" : "top"] : null),
                          e.preventDefault(),
                          e.stopPropagation(),
                          i.transition(100),
                          s.transition(100),
                          r.setDragPosition(e),
                          clearTimeout(t.scrollbar.dragTimeout),
                          a.transition(0),
                          n.hide && a.css("opacity", 1),
                          t.params.cssMode && t.$wrapperEl.css("scroll-snap-type", "none"),
                          t.emit("scrollbarDragStart", e);
                  },
                  onDragMove: function (e) {
                      var t = this,
                          n = t.scrollbar,
                          r = t.$wrapperEl,
                          i = n.$el,
                          a = n.$dragEl;
                      t.scrollbar.isTouched && (e.preventDefault ? e.preventDefault() : (e.returnValue = !1), n.setDragPosition(e), r.transition(0), i.transition(0), a.transition(0), t.emit("scrollbarDragMove", e));
                  },
                  onDragEnd: function (e) {
                      var t = this,
                          n = t.params.scrollbar,
                          r = t.scrollbar,
                          i = t.$wrapperEl,
                          a = r.$el;
                      t.scrollbar.isTouched &&
                          ((t.scrollbar.isTouched = !1),
                          t.params.cssMode && (t.$wrapperEl.css("scroll-snap-type", ""), i.transition("")),
                          n.hide &&
                              (clearTimeout(t.scrollbar.dragTimeout),
                              (t.scrollbar.dragTimeout = x(function () {
                                  a.css("opacity", 0), a.transition(400);
                              }, 1e3))),
                          t.emit("scrollbarDragEnd", e),
                          n.snapOnRelease && t.slideToClosest());
                  },
                  enableDraggable: function () {
                      var e = this;
                      if (e.params.scrollbar.el) {
                          var t = s(),
                              n = e.scrollbar,
                              r = e.touchEventsTouch,
                              i = e.touchEventsDesktop,
                              a = e.params,
                              o = e.support,
                              l = n.$el[0],
                              d = !(!o.passiveListener || !a.passiveListeners) && { passive: !1, capture: !1 },
                              u = !(!o.passiveListener || !a.passiveListeners) && { passive: !0, capture: !1 };
                          o.touch
                              ? (l.addEventListener(r.start, e.scrollbar.onDragStart, d), l.addEventListener(r.move, e.scrollbar.onDragMove, d), l.addEventListener(r.end, e.scrollbar.onDragEnd, u))
                              : (l.addEventListener(i.start, e.scrollbar.onDragStart, d), t.addEventListener(i.move, e.scrollbar.onDragMove, d), t.addEventListener(i.end, e.scrollbar.onDragEnd, u));
                      }
                  },
                  disableDraggable: function () {
                      var e = this;
                      if (e.params.scrollbar.el) {
                          var t = s(),
                              n = e.scrollbar,
                              r = e.touchEventsTouch,
                              i = e.touchEventsDesktop,
                              a = e.params,
                              o = e.support,
                              l = n.$el[0],
                              d = !(!o.passiveListener || !a.passiveListeners) && { passive: !1, capture: !1 },
                              u = !(!o.passiveListener || !a.passiveListeners) && { passive: !0, capture: !1 };
                          o.touch
                              ? (l.removeEventListener(r.start, e.scrollbar.onDragStart, d), l.removeEventListener(r.move, e.scrollbar.onDragMove, d), l.removeEventListener(r.end, e.scrollbar.onDragEnd, u))
                              : (l.removeEventListener(i.start, e.scrollbar.onDragStart, d), t.removeEventListener(i.move, e.scrollbar.onDragMove, d), t.removeEventListener(i.end, e.scrollbar.onDragEnd, u));
                      }
                  },
                  init: function () {
                      var e = this;
                      if (e.params.scrollbar.el) {
                          var t = e.scrollbar,
                              n = e.$el,
                              r = e.params.scrollbar,
                              i = g(r.el);
                          e.params.uniqueNavElements && "string" == typeof r.el && i.length > 1 && 1 === n.find(r.el).length && (i = n.find(r.el));
                          var a = i.find("." + e.params.scrollbar.dragClass);
                          0 === a.length && ((a = g('<div class="' + e.params.scrollbar.dragClass + '"></div>')), i.append(a)), C(t, { $el: i, el: i[0], $dragEl: a, dragEl: a[0] }), r.draggable && t.enableDraggable();
                      }
                  },
                  destroy: function () {
                      this.scrollbar.disableDraggable();
                  },
              },
              ee = {
                  setTransform: function (e, t) {
                      var n = this.rtl,
                          r = g(e),
                          i = n ? -1 : 1,
                          a = r.attr("data-swiper-parallax") || "0",
                          s = r.attr("data-swiper-parallax-x"),
                          o = r.attr("data-swiper-parallax-y"),
                          l = r.attr("data-swiper-parallax-scale"),
                          d = r.attr("data-swiper-parallax-opacity");
                      if (
                          (s || o ? ((s = s || "0"), (o = o || "0")) : this.isHorizontal() ? ((s = a), (o = "0")) : ((o = a), (s = "0")),
                          (s = s.indexOf("%") >= 0 ? parseInt(s, 10) * t * i + "%" : s * t * i + "px"),
                          (o = o.indexOf("%") >= 0 ? parseInt(o, 10) * t + "%" : o * t + "px"),
                          null != d)
                      ) {
                          var u = d - (d - 1) * (1 - Math.abs(t));
                          r[0].style.opacity = u;
                      }
                      if (null == l) r.transform("translate3d(" + s + ", " + o + ", 0px)");
                      else {
                          var c = l - (l - 1) * (1 - Math.abs(t));
                          r.transform("translate3d(" + s + ", " + o + ", 0px) scale(" + c + ")");
                      }
                  },
                  setTranslate: function () {
                      var e = this,
                          t = e.$el,
                          n = e.slides,
                          r = e.progress,
                          i = e.snapGrid;
                      t.children("[data-swiper-parallax], [data-swiper-parallax-x], [data-swiper-parallax-y], [data-swiper-parallax-opacity], [data-swiper-parallax-scale]").each(function (t) {
                          e.parallax.setTransform(t, r);
                      }),
                          n.each(function (t, n) {
                              var a = t.progress;
                              e.params.slidesPerGroup > 1 && "auto" !== e.params.slidesPerView && (a += Math.ceil(n / 2) - r * (i.length - 1)),
                                  (a = Math.min(Math.max(a, -1), 1)),
                                  g(t)
                                      .find("[data-swiper-parallax], [data-swiper-parallax-x], [data-swiper-parallax-y], [data-swiper-parallax-opacity], [data-swiper-parallax-scale]")
                                      .each(function (t) {
                                          e.parallax.setTransform(t, a);
                                      });
                          });
                  },
                  setTransition: function (e) {
                      void 0 === e && (e = this.params.speed),
                          this.$el.find("[data-swiper-parallax], [data-swiper-parallax-x], [data-swiper-parallax-y], [data-swiper-parallax-opacity], [data-swiper-parallax-scale]").each(function (t) {
                              var n = g(t),
                                  r = parseInt(n.attr("data-swiper-parallax-duration"), 10) || e;
                              0 === e && (r = 0), n.transition(r);
                          });
                  },
              },
              te = {
                  getDistanceBetweenTouches: function (e) {
                      if (e.targetTouches.length < 2) return 1;
                      var t = e.targetTouches[0].pageX,
                          n = e.targetTouches[0].pageY,
                          r = e.targetTouches[1].pageX,
                          i = e.targetTouches[1].pageY;
                      return Math.sqrt(Math.pow(r - t, 2) + Math.pow(i - n, 2));
                  },
                  onGestureStart: function (e) {
                      var t = this,
                          n = t.support,
                          r = t.params.zoom,
                          i = t.zoom,
                          a = i.gesture;
                      if (((i.fakeGestureTouched = !1), (i.fakeGestureMoved = !1), !n.gestures)) {
                          if ("touchstart" !== e.type || ("touchstart" === e.type && e.targetTouches.length < 2)) return;
                          (i.fakeGestureTouched = !0), (a.scaleStart = te.getDistanceBetweenTouches(e));
                      }
                      (a.$slideEl && a.$slideEl.length) ||
                      ((a.$slideEl = g(e.target).closest("." + t.params.slideClass)),
                      0 === a.$slideEl.length && (a.$slideEl = t.slides.eq(t.activeIndex)),
                      (a.$imageEl = a.$slideEl.find("img, svg, canvas, picture, .swiper-zoom-target")),
                      (a.$imageWrapEl = a.$imageEl.parent("." + r.containerClass)),
                      (a.maxRatio = a.$imageWrapEl.attr("data-swiper-zoom") || r.maxRatio),
                      0 !== a.$imageWrapEl.length)
                          ? (a.$imageEl && a.$imageEl.transition(0), (t.zoom.isScaling = !0))
                          : (a.$imageEl = void 0);
                  },
                  onGestureChange: function (e) {
                      var t = this,
                          n = t.support,
                          r = t.params.zoom,
                          i = t.zoom,
                          a = i.gesture;
                      if (!n.gestures) {
                          if ("touchmove" !== e.type || ("touchmove" === e.type && e.targetTouches.length < 2)) return;
                          (i.fakeGestureMoved = !0), (a.scaleMove = te.getDistanceBetweenTouches(e));
                      }
                      a.$imageEl && 0 !== a.$imageEl.length
                          ? (n.gestures ? (i.scale = e.scale * i.currentScale) : (i.scale = (a.scaleMove / a.scaleStart) * i.currentScale),
                            i.scale > a.maxRatio && (i.scale = a.maxRatio - 1 + Math.pow(i.scale - a.maxRatio + 1, 0.5)),
                            i.scale < r.minRatio && (i.scale = r.minRatio + 1 - Math.pow(r.minRatio - i.scale + 1, 0.5)),
                            a.$imageEl.transform("translate3d(0,0,0) scale(" + i.scale + ")"))
                          : "gesturechange" === e.type && i.onGestureStart(e);
                  },
                  onGestureEnd: function (e) {
                      var t = this,
                          n = t.device,
                          r = t.support,
                          i = t.params.zoom,
                          a = t.zoom,
                          s = a.gesture;
                      if (!r.gestures) {
                          if (!a.fakeGestureTouched || !a.fakeGestureMoved) return;
                          if ("touchend" !== e.type || ("touchend" === e.type && e.changedTouches.length < 2 && !n.android)) return;
                          (a.fakeGestureTouched = !1), (a.fakeGestureMoved = !1);
                      }
                      s.$imageEl &&
                          0 !== s.$imageEl.length &&
                          ((a.scale = Math.max(Math.min(a.scale, s.maxRatio), i.minRatio)),
                          s.$imageEl.transition(t.params.speed).transform("translate3d(0,0,0) scale(" + a.scale + ")"),
                          (a.currentScale = a.scale),
                          (a.isScaling = !1),
                          1 === a.scale && (s.$slideEl = void 0));
                  },
                  onTouchStart: function (e) {
                      var t = this.device,
                          n = this.zoom,
                          r = n.gesture,
                          i = n.image;
                      r.$imageEl &&
                          0 !== r.$imageEl.length &&
                          (i.isTouched ||
                              (t.android && e.cancelable && e.preventDefault(),
                              (i.isTouched = !0),
                              (i.touchesStart.x = "touchstart" === e.type ? e.targetTouches[0].pageX : e.pageX),
                              (i.touchesStart.y = "touchstart" === e.type ? e.targetTouches[0].pageY : e.pageY)));
                  },
                  onTouchMove: function (e) {
                      var t = this,
                          n = t.zoom,
                          r = n.gesture,
                          i = n.image,
                          a = n.velocity;
                      if (r.$imageEl && 0 !== r.$imageEl.length && ((t.allowClick = !1), i.isTouched && r.$slideEl)) {
                          i.isMoved ||
                              ((i.width = r.$imageEl[0].offsetWidth),
                              (i.height = r.$imageEl[0].offsetHeight),
                              (i.startX = T(r.$imageWrapEl[0], "x") || 0),
                              (i.startY = T(r.$imageWrapEl[0], "y") || 0),
                              (r.slideWidth = r.$slideEl[0].offsetWidth),
                              (r.slideHeight = r.$slideEl[0].offsetHeight),
                              r.$imageWrapEl.transition(0),
                              t.rtl && ((i.startX = -i.startX), (i.startY = -i.startY)));
                          var s = i.width * n.scale,
                              o = i.height * n.scale;
                          if (!(s < r.slideWidth && o < r.slideHeight)) {
                              if (
                                  ((i.minX = Math.min(r.slideWidth / 2 - s / 2, 0)),
                                  (i.maxX = -i.minX),
                                  (i.minY = Math.min(r.slideHeight / 2 - o / 2, 0)),
                                  (i.maxY = -i.minY),
                                  (i.touchesCurrent.x = "touchmove" === e.type ? e.targetTouches[0].pageX : e.pageX),
                                  (i.touchesCurrent.y = "touchmove" === e.type ? e.targetTouches[0].pageY : e.pageY),
                                  !i.isMoved && !n.isScaling)
                              ) {
                                  if (t.isHorizontal() && ((Math.floor(i.minX) === Math.floor(i.startX) && i.touchesCurrent.x < i.touchesStart.x) || (Math.floor(i.maxX) === Math.floor(i.startX) && i.touchesCurrent.x > i.touchesStart.x)))
                                      return void (i.isTouched = !1);
                                  if (!t.isHorizontal() && ((Math.floor(i.minY) === Math.floor(i.startY) && i.touchesCurrent.y < i.touchesStart.y) || (Math.floor(i.maxY) === Math.floor(i.startY) && i.touchesCurrent.y > i.touchesStart.y)))
                                      return void (i.isTouched = !1);
                              }
                              e.cancelable && e.preventDefault(),
                                  e.stopPropagation(),
                                  (i.isMoved = !0),
                                  (i.currentX = i.touchesCurrent.x - i.touchesStart.x + i.startX),
                                  (i.currentY = i.touchesCurrent.y - i.touchesStart.y + i.startY),
                                  i.currentX < i.minX && (i.currentX = i.minX + 1 - Math.pow(i.minX - i.currentX + 1, 0.8)),
                                  i.currentX > i.maxX && (i.currentX = i.maxX - 1 + Math.pow(i.currentX - i.maxX + 1, 0.8)),
                                  i.currentY < i.minY && (i.currentY = i.minY + 1 - Math.pow(i.minY - i.currentY + 1, 0.8)),
                                  i.currentY > i.maxY && (i.currentY = i.maxY - 1 + Math.pow(i.currentY - i.maxY + 1, 0.8)),
                                  a.prevPositionX || (a.prevPositionX = i.touchesCurrent.x),
                                  a.prevPositionY || (a.prevPositionY = i.touchesCurrent.y),
                                  a.prevTime || (a.prevTime = Date.now()),
                                  (a.x = (i.touchesCurrent.x - a.prevPositionX) / (Date.now() - a.prevTime) / 2),
                                  (a.y = (i.touchesCurrent.y - a.prevPositionY) / (Date.now() - a.prevTime) / 2),
                                  Math.abs(i.touchesCurrent.x - a.prevPositionX) < 2 && (a.x = 0),
                                  Math.abs(i.touchesCurrent.y - a.prevPositionY) < 2 && (a.y = 0),
                                  (a.prevPositionX = i.touchesCurrent.x),
                                  (a.prevPositionY = i.touchesCurrent.y),
                                  (a.prevTime = Date.now()),
                                  r.$imageWrapEl.transform("translate3d(" + i.currentX + "px, " + i.currentY + "px,0)");
                          }
                      }
                  },
                  onTouchEnd: function () {
                      var e = this.zoom,
                          t = e.gesture,
                          n = e.image,
                          r = e.velocity;
                      if (t.$imageEl && 0 !== t.$imageEl.length) {
                          if (!n.isTouched || !n.isMoved) return (n.isTouched = !1), void (n.isMoved = !1);
                          (n.isTouched = !1), (n.isMoved = !1);
                          var i = 300,
                              a = 300,
                              s = r.x * i,
                              o = n.currentX + s,
                              l = r.y * a,
                              d = n.currentY + l;
                          0 !== r.x && (i = Math.abs((o - n.currentX) / r.x)), 0 !== r.y && (a = Math.abs((d - n.currentY) / r.y));
                          var u = Math.max(i, a);
                          (n.currentX = o), (n.currentY = d);
                          var c = n.width * e.scale,
                              p = n.height * e.scale;
                          (n.minX = Math.min(t.slideWidth / 2 - c / 2, 0)),
                              (n.maxX = -n.minX),
                              (n.minY = Math.min(t.slideHeight / 2 - p / 2, 0)),
                              (n.maxY = -n.minY),
                              (n.currentX = Math.max(Math.min(n.currentX, n.maxX), n.minX)),
                              (n.currentY = Math.max(Math.min(n.currentY, n.maxY), n.minY)),
                              t.$imageWrapEl.transition(u).transform("translate3d(" + n.currentX + "px, " + n.currentY + "px,0)");
                      }
                  },
                  onTransitionEnd: function () {
                      var e = this,
                          t = e.zoom,
                          n = t.gesture;
                      n.$slideEl &&
                          e.previousIndex !== e.activeIndex &&
                          (n.$imageEl && n.$imageEl.transform("translate3d(0,0,0) scale(1)"),
                          n.$imageWrapEl && n.$imageWrapEl.transform("translate3d(0,0,0)"),
                          (t.scale = 1),
                          (t.currentScale = 1),
                          (n.$slideEl = void 0),
                          (n.$imageEl = void 0),
                          (n.$imageWrapEl = void 0));
                  },
                  toggle: function (e) {
                      var t = this.zoom;
                      t.scale && 1 !== t.scale ? t.out() : t.in(e);
                  },
                  in: function (e) {
                      var t,
                          n,
                          r,
                          i,
                          a,
                          s,
                          o,
                          l,
                          d,
                          u,
                          c,
                          p,
                          f,
                          h,
                          m,
                          v,
                          g = this,
                          y = g.zoom,
                          w = g.params.zoom,
                          b = y.gesture,
                          E = y.image;
                      b.$slideEl ||
                          (g.params.virtual && g.params.virtual.enabled && g.virtual ? (b.$slideEl = g.$wrapperEl.children("." + g.params.slideActiveClass)) : (b.$slideEl = g.slides.eq(g.activeIndex)),
                          (b.$imageEl = b.$slideEl.find("img, svg, canvas, picture, .swiper-zoom-target")),
                          (b.$imageWrapEl = b.$imageEl.parent("." + w.containerClass))),
                          b.$imageEl &&
                              0 !== b.$imageEl.length &&
                              (b.$slideEl.addClass("" + w.zoomedSlideClass),
                              void 0 === E.touchesStart.x && e
                                  ? ((t = "touchend" === e.type ? e.changedTouches[0].pageX : e.pageX), (n = "touchend" === e.type ? e.changedTouches[0].pageY : e.pageY))
                                  : ((t = E.touchesStart.x), (n = E.touchesStart.y)),
                              (y.scale = b.$imageWrapEl.attr("data-swiper-zoom") || w.maxRatio),
                              (y.currentScale = b.$imageWrapEl.attr("data-swiper-zoom") || w.maxRatio),
                              e
                                  ? ((m = b.$slideEl[0].offsetWidth),
                                    (v = b.$slideEl[0].offsetHeight),
                                    (r = b.$slideEl.offset().left + m / 2 - t),
                                    (i = b.$slideEl.offset().top + v / 2 - n),
                                    (o = b.$imageEl[0].offsetWidth),
                                    (l = b.$imageEl[0].offsetHeight),
                                    (d = o * y.scale),
                                    (u = l * y.scale),
                                    (f = -(c = Math.min(m / 2 - d / 2, 0))),
                                    (h = -(p = Math.min(v / 2 - u / 2, 0))),
                                    (a = r * y.scale) < c && (a = c),
                                    a > f && (a = f),
                                    (s = i * y.scale) < p && (s = p),
                                    s > h && (s = h))
                                  : ((a = 0), (s = 0)),
                              b.$imageWrapEl.transition(300).transform("translate3d(" + a + "px, " + s + "px,0)"),
                              b.$imageEl.transition(300).transform("translate3d(0,0,0) scale(" + y.scale + ")"));
                  },
                  out: function () {
                      var e = this,
                          t = e.zoom,
                          n = e.params.zoom,
                          r = t.gesture;
                      r.$slideEl ||
                          (e.params.virtual && e.params.virtual.enabled && e.virtual ? (r.$slideEl = e.$wrapperEl.children("." + e.params.slideActiveClass)) : (r.$slideEl = e.slides.eq(e.activeIndex)),
                          (r.$imageEl = r.$slideEl.find("img, svg, canvas, picture, .swiper-zoom-target")),
                          (r.$imageWrapEl = r.$imageEl.parent("." + n.containerClass))),
                          r.$imageEl &&
                              0 !== r.$imageEl.length &&
                              ((t.scale = 1),
                              (t.currentScale = 1),
                              r.$imageWrapEl.transition(300).transform("translate3d(0,0,0)"),
                              r.$imageEl.transition(300).transform("translate3d(0,0,0) scale(1)"),
                              r.$slideEl.removeClass("" + n.zoomedSlideClass),
                              (r.$slideEl = void 0));
                  },
                  toggleGestures: function (e) {
                      var t = this,
                          n = t.zoom,
                          r = n.slideSelector,
                          i = n.passiveListener;
                      t.$wrapperEl[e]("gesturestart", r, n.onGestureStart, i), t.$wrapperEl[e]("gesturechange", r, n.onGestureChange, i), t.$wrapperEl[e]("gestureend", r, n.onGestureEnd, i);
                  },
                  enableGestures: function () {
                      this.zoom.gesturesEnabled || ((this.zoom.gesturesEnabled = !0), this.zoom.toggleGestures("on"));
                  },
                  disableGestures: function () {
                      this.zoom.gesturesEnabled && ((this.zoom.gesturesEnabled = !1), this.zoom.toggleGestures("off"));
                  },
                  enable: function () {
                      var e = this,
                          t = e.support,
                          n = e.zoom;
                      if (!n.enabled) {
                          n.enabled = !0;
                          var r = !("touchstart" !== e.touchEvents.start || !t.passiveListener || !e.params.passiveListeners) && { passive: !0, capture: !1 },
                              i = !t.passiveListener || { passive: !1, capture: !0 },
                              a = "." + e.params.slideClass;
                          (e.zoom.passiveListener = r),
                              (e.zoom.slideSelector = a),
                              t.gestures
                                  ? (e.$wrapperEl.on(e.touchEvents.start, e.zoom.enableGestures, r), e.$wrapperEl.on(e.touchEvents.end, e.zoom.disableGestures, r))
                                  : "touchstart" === e.touchEvents.start &&
                                    (e.$wrapperEl.on(e.touchEvents.start, a, n.onGestureStart, r),
                                    e.$wrapperEl.on(e.touchEvents.move, a, n.onGestureChange, i),
                                    e.$wrapperEl.on(e.touchEvents.end, a, n.onGestureEnd, r),
                                    e.touchEvents.cancel && e.$wrapperEl.on(e.touchEvents.cancel, a, n.onGestureEnd, r)),
                              e.$wrapperEl.on(e.touchEvents.move, "." + e.params.zoom.containerClass, n.onTouchMove, i);
                      }
                  },
                  disable: function () {
                      var e = this,
                          t = e.zoom;
                      if (t.enabled) {
                          var n = e.support;
                          e.zoom.enabled = !1;
                          var r = !("touchstart" !== e.touchEvents.start || !n.passiveListener || !e.params.passiveListeners) && { passive: !0, capture: !1 },
                              i = !n.passiveListener || { passive: !1, capture: !0 },
                              a = "." + e.params.slideClass;
                          n.gestures
                              ? (e.$wrapperEl.off(e.touchEvents.start, e.zoom.enableGestures, r), e.$wrapperEl.off(e.touchEvents.end, e.zoom.disableGestures, r))
                              : "touchstart" === e.touchEvents.start &&
                                (e.$wrapperEl.off(e.touchEvents.start, a, t.onGestureStart, r),
                                e.$wrapperEl.off(e.touchEvents.move, a, t.onGestureChange, i),
                                e.$wrapperEl.off(e.touchEvents.end, a, t.onGestureEnd, r),
                                e.touchEvents.cancel && e.$wrapperEl.off(e.touchEvents.cancel, a, t.onGestureEnd, r)),
                              e.$wrapperEl.off(e.touchEvents.move, "." + e.params.zoom.containerClass, t.onTouchMove, i);
                      }
                  },
              },
              ne = {
                  loadInSlide: function (e, t) {
                      void 0 === t && (t = !0);
                      var n = this,
                          r = n.params.lazy;
                      if (void 0 !== e && 0 !== n.slides.length) {
                          var i = n.virtual && n.params.virtual.enabled ? n.$wrapperEl.children("." + n.params.slideClass + '[data-swiper-slide-index="' + e + '"]') : n.slides.eq(e),
                              a = i.find("." + r.elementClass + ":not(." + r.loadedClass + "):not(." + r.loadingClass + ")");
                          !i.hasClass(r.elementClass) || i.hasClass(r.loadedClass) || i.hasClass(r.loadingClass) || a.push(i[0]),
                              0 !== a.length &&
                                  a.each(function (e) {
                                      var a = g(e);
                                      a.addClass(r.loadingClass);
                                      var s = a.attr("data-background"),
                                          o = a.attr("data-src"),
                                          l = a.attr("data-srcset"),
                                          d = a.attr("data-sizes"),
                                          u = a.parent("picture");
                                      n.loadImage(a[0], o || s, l, d, !1, function () {
                                          if (null != n && n && (!n || n.params) && !n.destroyed) {
                                              if (
                                                  (s
                                                      ? (a.css("background-image", 'url("' + s + '")'), a.removeAttr("data-background"))
                                                      : (l && (a.attr("srcset", l), a.removeAttr("data-srcset")),
                                                        d && (a.attr("sizes", d), a.removeAttr("data-sizes")),
                                                        u.length &&
                                                            u.children("source").each(function (e) {
                                                                var t = g(e);
                                                                t.attr("data-srcset") && (t.attr("srcset", t.attr("data-srcset")), t.removeAttr("data-srcset"));
                                                            }),
                                                        o && (a.attr("src", o), a.removeAttr("data-src"))),
                                                  a.addClass(r.loadedClass).removeClass(r.loadingClass),
                                                  i.find("." + r.preloaderClass).remove(),
                                                  n.params.loop && t)
                                              ) {
                                                  var e = i.attr("data-swiper-slide-index");
                                                  if (i.hasClass(n.params.slideDuplicateClass)) {
                                                      var c = n.$wrapperEl.children('[data-swiper-slide-index="' + e + '"]:not(.' + n.params.slideDuplicateClass + ")");
                                                      n.lazy.loadInSlide(c.index(), !1);
                                                  } else {
                                                      var p = n.$wrapperEl.children("." + n.params.slideDuplicateClass + '[data-swiper-slide-index="' + e + '"]');
                                                      n.lazy.loadInSlide(p.index(), !1);
                                                  }
                                              }
                                              n.emit("lazyImageReady", i[0], a[0]), n.params.autoHeight && n.updateAutoHeight();
                                          }
                                      }),
                                          n.emit("lazyImageLoad", i[0], a[0]);
                                  });
                      }
                  },
                  load: function () {
                      var e = this,
                          t = e.$wrapperEl,
                          n = e.params,
                          r = e.slides,
                          i = e.activeIndex,
                          a = e.virtual && n.virtual.enabled,
                          s = n.lazy,
                          o = n.slidesPerView;
                      function l(e) {
                          if (a) {
                              if (t.children("." + n.slideClass + '[data-swiper-slide-index="' + e + '"]').length) return !0;
                          } else if (r[e]) return !0;
                          return !1;
                      }
                      function d(e) {
                          return a ? g(e).attr("data-swiper-slide-index") : g(e).index();
                      }
                      if (("auto" === o && (o = 0), e.lazy.initialImageLoaded || (e.lazy.initialImageLoaded = !0), e.params.watchSlidesVisibility))
                          t.children("." + n.slideVisibleClass).each(function (t) {
                              var n = a ? g(t).attr("data-swiper-slide-index") : g(t).index();
                              e.lazy.loadInSlide(n);
                          });
                      else if (o > 1) for (var u = i; u < i + o; u += 1) l(u) && e.lazy.loadInSlide(u);
                      else e.lazy.loadInSlide(i);
                      if (s.loadPrevNext)
                          if (o > 1 || (s.loadPrevNextAmount && s.loadPrevNextAmount > 1)) {
                              for (var c = s.loadPrevNextAmount, p = o, f = Math.min(i + p + Math.max(c, p), r.length), h = Math.max(i - Math.max(p, c), 0), m = i + o; m < f; m += 1) l(m) && e.lazy.loadInSlide(m);
                              for (var v = h; v < i; v += 1) l(v) && e.lazy.loadInSlide(v);
                          } else {
                              var y = t.children("." + n.slideNextClass);
                              y.length > 0 && e.lazy.loadInSlide(d(y));
                              var w = t.children("." + n.slidePrevClass);
                              w.length > 0 && e.lazy.loadInSlide(d(w));
                          }
                  },
                  checkInViewOnLoad: function () {
                      var e = l(),
                          t = this;
                      if (t && !t.destroyed) {
                          var n = t.params.lazy.scrollingElement ? g(t.params.lazy.scrollingElement) : g(e),
                              r = n[0] === e,
                              i = r ? e.innerWidth : n[0].offsetWidth,
                              a = r ? e.innerHeight : n[0].offsetHeight,
                              s = t.$el.offset(),
                              o = !1;
                          t.rtlTranslate && (s.left -= t.$el[0].scrollLeft);
                          for (
                              var d = [
                                      [s.left, s.top],
                                      [s.left + t.width, s.top],
                                      [s.left, s.top + t.height],
                                      [s.left + t.width, s.top + t.height],
                                  ],
                                  u = 0;
                              u < d.length;
                              u += 1
                          ) {
                              var c = d[u];
                              if (c[0] >= 0 && c[0] <= i && c[1] >= 0 && c[1] <= a) {
                                  if (0 === c[0] && 0 === c[1]) continue;
                                  o = !0;
                              }
                          }
                          o ? (t.lazy.load(), n.off("scroll", t.lazy.checkInViewOnLoad)) : t.lazy.scrollHandlerAttached || ((t.lazy.scrollHandlerAttached = !0), n.on("scroll", t.lazy.checkInViewOnLoad));
                      }
                  },
              },
              re = {
                  LinearSpline: function (e, t) {
                      var n, r, i, a, s;
                      return (
                          (this.x = e),
                          (this.y = t),
                          (this.lastIndex = e.length - 1),
                          (this.interpolate = function (e) {
                              return e
                                  ? ((s = (function (e, t) {
                                        for (r = -1, n = e.length; n - r > 1; ) e[(i = (n + r) >> 1)] <= t ? (r = i) : (n = i);
                                        return n;
                                    })(this.x, e)),
                                    (a = s - 1),
                                    ((e - this.x[a]) * (this.y[s] - this.y[a])) / (this.x[s] - this.x[a]) + this.y[a])
                                  : 0;
                          }),
                          this
                      );
                  },
                  getInterpolateFunction: function (e) {
                      var t = this;
                      t.controller.spline || (t.controller.spline = t.params.loop ? new re.LinearSpline(t.slidesGrid, e.slidesGrid) : new re.LinearSpline(t.snapGrid, e.snapGrid));
                  },
                  setTranslate: function (e, t) {
                      var n,
                          r,
                          i = this,
                          a = i.controller.control,
                          s = i.constructor;
                      function o(e) {
                          var t = i.rtlTranslate ? -i.translate : i.translate;
                          "slide" === i.params.controller.by && (i.controller.getInterpolateFunction(e), (r = -i.controller.spline.interpolate(-t))),
                              (r && "container" !== i.params.controller.by) || ((n = (e.maxTranslate() - e.minTranslate()) / (i.maxTranslate() - i.minTranslate())), (r = (t - i.minTranslate()) * n + e.minTranslate())),
                              i.params.controller.inverse && (r = e.maxTranslate() - r),
                              e.updateProgress(r),
                              e.setTranslate(r, i),
                              e.updateActiveIndex(),
                              e.updateSlidesClasses();
                      }
                      if (Array.isArray(a)) for (var l = 0; l < a.length; l += 1) a[l] !== t && a[l] instanceof s && o(a[l]);
                      else a instanceof s && t !== a && o(a);
                  },
                  setTransition: function (e, t) {
                      var n,
                          r = this,
                          i = r.constructor,
                          a = r.controller.control;
                      function s(t) {
                          t.setTransition(e, r),
                              0 !== e &&
                                  (t.transitionStart(),
                                  t.params.autoHeight &&
                                      x(function () {
                                          t.updateAutoHeight();
                                      }),
                                  t.$wrapperEl.transitionEnd(function () {
                                      a && (t.params.loop && "slide" === r.params.controller.by && t.loopFix(), t.transitionEnd());
                                  }));
                      }
                      if (Array.isArray(a)) for (n = 0; n < a.length; n += 1) a[n] !== t && a[n] instanceof i && s(a[n]);
                      else a instanceof i && t !== a && s(a);
                  },
              },
              ie = {
                  getRandomNumber: function (e) {
                      return (
                          void 0 === e && (e = 16),
                          "x".repeat(e).replace(/x/g, function () {
                              return Math.round(16 * Math.random()).toString(16);
                          })
                      );
                  },
                  makeElFocusable: function (e) {
                      return e.attr("tabIndex", "0"), e;
                  },
                  makeElNotFocusable: function (e) {
                      return e.attr("tabIndex", "-1"), e;
                  },
                  addElRole: function (e, t) {
                      return e.attr("role", t), e;
                  },
                  addElRoleDescription: function (e, t) {
                      return e.attr("aria-role-description", t), e;
                  },
                  addElControls: function (e, t) {
                      return e.attr("aria-controls", t), e;
                  },
                  addElLabel: function (e, t) {
                      return e.attr("aria-label", t), e;
                  },
                  addElId: function (e, t) {
                      return e.attr("id", t), e;
                  },
                  addElLive: function (e, t) {
                      return e.attr("aria-live", t), e;
                  },
                  disableEl: function (e) {
                      return e.attr("aria-disabled", !0), e;
                  },
                  enableEl: function (e) {
                      return e.attr("aria-disabled", !1), e;
                  },
                  onEnterKey: function (e) {
                      var t = this,
                          n = t.params.a11y;
                      if (13 === e.keyCode) {
                          var r = g(e.target);
                          t.navigation && t.navigation.$nextEl && r.is(t.navigation.$nextEl) && ((t.isEnd && !t.params.loop) || t.slideNext(), t.isEnd ? t.a11y.notify(n.lastSlideMessage) : t.a11y.notify(n.nextSlideMessage)),
                              t.navigation &&
                                  t.navigation.$prevEl &&
                                  r.is(t.navigation.$prevEl) &&
                                  ((t.isBeginning && !t.params.loop) || t.slidePrev(), t.isBeginning ? t.a11y.notify(n.firstSlideMessage) : t.a11y.notify(n.prevSlideMessage)),
                              t.pagination && r.is("." + t.params.pagination.bulletClass.replace(/ /g, ".")) && r[0].click();
                      }
                  },
                  notify: function (e) {
                      var t = this.a11y.liveRegion;
                      0 !== t.length && (t.html(""), t.html(e));
                  },
                  updateNavigation: function () {
                      var e = this;
                      if (!e.params.loop && e.navigation) {
                          var t = e.navigation,
                              n = t.$nextEl,
                              r = t.$prevEl;
                          r && r.length > 0 && (e.isBeginning ? (e.a11y.disableEl(r), e.a11y.makeElNotFocusable(r)) : (e.a11y.enableEl(r), e.a11y.makeElFocusable(r))),
                              n && n.length > 0 && (e.isEnd ? (e.a11y.disableEl(n), e.a11y.makeElNotFocusable(n)) : (e.a11y.enableEl(n), e.a11y.makeElFocusable(n)));
                      }
                  },
                  updatePagination: function () {
                      var e = this,
                          t = e.params.a11y;
                      e.pagination &&
                          e.params.pagination.clickable &&
                          e.pagination.bullets &&
                          e.pagination.bullets.length &&
                          e.pagination.bullets.each(function (n) {
                              var r = g(n);
                              e.a11y.makeElFocusable(r), e.params.pagination.renderBullet || (e.a11y.addElRole(r, "button"), e.a11y.addElLabel(r, t.paginationBulletMessage.replace(/\{\{index\}\}/, r.index() + 1)));
                          });
                  },
                  init: function () {
                      var e = this,
                          t = e.params.a11y;
                      e.$el.append(e.a11y.liveRegion);
                      var n = e.$el;
                      t.containerRoleDescriptionMessage && e.a11y.addElRoleDescription(n, t.containerRoleDescriptionMessage), t.containerMessage && e.a11y.addElLabel(n, t.containerMessage);
                      var r,
                          i,
                          a,
                          s = e.$wrapperEl,
                          o = s.attr("id") || "swiper-wrapper-" + e.a11y.getRandomNumber(16);
                      e.a11y.addElId(s, o),
                          (r = e.params.autoplay && e.params.autoplay.enabled ? "off" : "polite"),
                          e.a11y.addElLive(s, r),
                          t.itemRoleDescriptionMessage && e.a11y.addElRoleDescription(g(e.slides), t.itemRoleDescriptionMessage),
                          e.a11y.addElRole(g(e.slides), "group"),
                          e.slides.each(function (t) {
                              var n = g(t);
                              e.a11y.addElLabel(n, n.index() + 1 + " / " + e.slides.length);
                          }),
                          e.navigation && e.navigation.$nextEl && (i = e.navigation.$nextEl),
                          e.navigation && e.navigation.$prevEl && (a = e.navigation.$prevEl),
                          i &&
                              i.length &&
                              (e.a11y.makeElFocusable(i), "BUTTON" !== i[0].tagName && (e.a11y.addElRole(i, "button"), i.on("keydown", e.a11y.onEnterKey)), e.a11y.addElLabel(i, t.nextSlideMessage), e.a11y.addElControls(i, o)),
                          a &&
                              a.length &&
                              (e.a11y.makeElFocusable(a), "BUTTON" !== a[0].tagName && (e.a11y.addElRole(a, "button"), a.on("keydown", e.a11y.onEnterKey)), e.a11y.addElLabel(a, t.prevSlideMessage), e.a11y.addElControls(a, o)),
                          e.pagination && e.params.pagination.clickable && e.pagination.bullets && e.pagination.bullets.length && e.pagination.$el.on("keydown", "." + e.params.pagination.bulletClass.replace(/ /g, "."), e.a11y.onEnterKey);
                  },
                  destroy: function () {
                      var e,
                          t,
                          n = this;
                      n.a11y.liveRegion && n.a11y.liveRegion.length > 0 && n.a11y.liveRegion.remove(),
                          n.navigation && n.navigation.$nextEl && (e = n.navigation.$nextEl),
                          n.navigation && n.navigation.$prevEl && (t = n.navigation.$prevEl),
                          e && e.off("keydown", n.a11y.onEnterKey),
                          t && t.off("keydown", n.a11y.onEnterKey),
                          n.pagination &&
                              n.params.pagination.clickable &&
                              n.pagination.bullets &&
                              n.pagination.bullets.length &&
                              n.pagination.$el.off("keydown", "." + n.params.pagination.bulletClass.replace(/ /g, "."), n.a11y.onEnterKey);
                  },
              },
              ae = {
                  init: function () {
                      var e = this,
                          t = l();
                      if (e.params.history) {
                          if (!t.history || !t.history.pushState) return (e.params.history.enabled = !1), void (e.params.hashNavigation.enabled = !0);
                          var n = e.history;
                          (n.initialized = !0),
                              (n.paths = ae.getPathValues(e.params.url)),
                              (n.paths.key || n.paths.value) && (n.scrollToSlide(0, n.paths.value, e.params.runCallbacksOnInit), e.params.history.replaceState || t.addEventListener("popstate", e.history.setHistoryPopState));
                      }
                  },
                  destroy: function () {
                      var e = l();
                      this.params.history.replaceState || e.removeEventListener("popstate", this.history.setHistoryPopState);
                  },
                  setHistoryPopState: function () {
                      var e = this;
                      (e.history.paths = ae.getPathValues(e.params.url)), e.history.scrollToSlide(e.params.speed, e.history.paths.value, !1);
                  },
                  getPathValues: function (e) {
                      var t = l(),
                          n = (e ? new URL(e) : t.location).pathname
                              .slice(1)
                              .split("/")
                              .filter(function (e) {
                                  return "" !== e;
                              }),
                          r = n.length;
                      return { key: n[r - 2], value: n[r - 1] };
                  },
                  setHistory: function (e, t) {
                      var n = this,
                          r = l();
                      if (n.history.initialized && n.params.history.enabled) {
                          var i;
                          i = n.params.url ? new URL(n.params.url) : r.location;
                          var a = n.slides.eq(t),
                              s = ae.slugify(a.attr("data-history"));
                          i.pathname.includes(e) || (s = e + "/" + s);
                          var o = r.history.state;
                          (o && o.value === s) || (n.params.history.replaceState ? r.history.replaceState({ value: s }, null, s) : r.history.pushState({ value: s }, null, s));
                      }
                  },
                  slugify: function (e) {
                      return e
                          .toString()
                          .replace(/\s+/g, "-")
                          .replace(/[^\w-]+/g, "")
                          .replace(/--+/g, "-")
                          .replace(/^-+/, "")
                          .replace(/-+$/, "");
                  },
                  scrollToSlide: function (e, t, n) {
                      var r = this;
                      if (t)
                          for (var i = 0, a = r.slides.length; i < a; i += 1) {
                              var s = r.slides.eq(i);
                              if (ae.slugify(s.attr("data-history")) === t && !s.hasClass(r.params.slideDuplicateClass)) {
                                  var o = s.index();
                                  r.slideTo(o, e, n);
                              }
                          }
                      else r.slideTo(0, e, n);
                  },
              },
              se = {
                  onHashCange: function () {
                      var e = this,
                          t = s();
                      e.emit("hashChange");
                      var n = t.location.hash.replace("#", "");
                      if (n !== e.slides.eq(e.activeIndex).attr("data-hash")) {
                          var r = e.$wrapperEl.children("." + e.params.slideClass + '[data-hash="' + n + '"]').index();
                          if (void 0 === r) return;
                          e.slideTo(r);
                      }
                  },
                  setHash: function () {
                      var e = this,
                          t = l(),
                          n = s();
                      if (e.hashNavigation.initialized && e.params.hashNavigation.enabled)
                          if (e.params.hashNavigation.replaceState && t.history && t.history.replaceState) t.history.replaceState(null, null, "#" + e.slides.eq(e.activeIndex).attr("data-hash") || !1), e.emit("hashSet");
                          else {
                              var r = e.slides.eq(e.activeIndex),
                                  i = r.attr("data-hash") || r.attr("data-history");
                              (n.location.hash = i || ""), e.emit("hashSet");
                          }
                  },
                  init: function () {
                      var e = this,
                          t = s(),
                          n = l();
                      if (!(!e.params.hashNavigation.enabled || (e.params.history && e.params.history.enabled))) {
                          e.hashNavigation.initialized = !0;
                          var r = t.location.hash.replace("#", "");
                          if (r)
                              for (var i = 0, a = e.slides.length; i < a; i += 1) {
                                  var o = e.slides.eq(i);
                                  if ((o.attr("data-hash") || o.attr("data-history")) === r && !o.hasClass(e.params.slideDuplicateClass)) {
                                      var d = o.index();
                                      e.slideTo(d, 0, e.params.runCallbacksOnInit, !0);
                                  }
                              }
                          e.params.hashNavigation.watchState && g(n).on("hashchange", e.hashNavigation.onHashCange);
                      }
                  },
                  destroy: function () {
                      var e = l();
                      this.params.hashNavigation.watchState && g(e).off("hashchange", this.hashNavigation.onHashCange);
                  },
              },
              oe = {
                  run: function () {
                      var e = this,
                          t = e.slides.eq(e.activeIndex),
                          n = e.params.autoplay.delay;
                      t.attr("data-swiper-autoplay") && (n = t.attr("data-swiper-autoplay") || e.params.autoplay.delay),
                          clearTimeout(e.autoplay.timeout),
                          (e.autoplay.timeout = x(function () {
                              var t;
                              e.params.autoplay.reverseDirection
                                  ? e.params.loop
                                      ? (e.loopFix(), (t = e.slidePrev(e.params.speed, !0, !0)), e.emit("autoplay"))
                                      : e.isBeginning
                                      ? e.params.autoplay.stopOnLastSlide
                                          ? e.autoplay.stop()
                                          : ((t = e.slideTo(e.slides.length - 1, e.params.speed, !0, !0)), e.emit("autoplay"))
                                      : ((t = e.slidePrev(e.params.speed, !0, !0)), e.emit("autoplay"))
                                  : e.params.loop
                                  ? (e.loopFix(), (t = e.slideNext(e.params.speed, !0, !0)), e.emit("autoplay"))
                                  : e.isEnd
                                  ? e.params.autoplay.stopOnLastSlide
                                      ? e.autoplay.stop()
                                      : ((t = e.slideTo(0, e.params.speed, !0, !0)), e.emit("autoplay"))
                                  : ((t = e.slideNext(e.params.speed, !0, !0)), e.emit("autoplay")),
                                  ((e.params.cssMode && e.autoplay.running) || !1 === t) && e.autoplay.run();
                          }, n));
                  },
                  start: function () {
                      var e = this;
                      return void 0 === e.autoplay.timeout && !e.autoplay.running && ((e.autoplay.running = !0), e.emit("autoplayStart"), e.autoplay.run(), !0);
                  },
                  stop: function () {
                      var e = this;
                      return !!e.autoplay.running && void 0 !== e.autoplay.timeout && (e.autoplay.timeout && (clearTimeout(e.autoplay.timeout), (e.autoplay.timeout = void 0)), (e.autoplay.running = !1), e.emit("autoplayStop"), !0);
                  },
                  pause: function (e) {
                      var t = this;
                      t.autoplay.running &&
                          (t.autoplay.paused ||
                              (t.autoplay.timeout && clearTimeout(t.autoplay.timeout),
                              (t.autoplay.paused = !0),
                              0 !== e && t.params.autoplay.waitForTransition
                                  ? (t.$wrapperEl[0].addEventListener("transitionend", t.autoplay.onTransitionEnd), t.$wrapperEl[0].addEventListener("webkitTransitionEnd", t.autoplay.onTransitionEnd))
                                  : ((t.autoplay.paused = !1), t.autoplay.run())));
                  },
                  onVisibilityChange: function () {
                      var e = this,
                          t = s();
                      "hidden" === t.visibilityState && e.autoplay.running && e.autoplay.pause(), "visible" === t.visibilityState && e.autoplay.paused && (e.autoplay.run(), (e.autoplay.paused = !1));
                  },
                  onTransitionEnd: function (e) {
                      var t = this;
                      t &&
                          !t.destroyed &&
                          t.$wrapperEl &&
                          e.target === t.$wrapperEl[0] &&
                          (t.$wrapperEl[0].removeEventListener("transitionend", t.autoplay.onTransitionEnd),
                          t.$wrapperEl[0].removeEventListener("webkitTransitionEnd", t.autoplay.onTransitionEnd),
                          (t.autoplay.paused = !1),
                          t.autoplay.running ? t.autoplay.run() : t.autoplay.stop());
                  },
              },
              le = {
                  setTranslate: function () {
                      for (var e = this, t = e.slides, n = 0; n < t.length; n += 1) {
                          var r = e.slides.eq(n),
                              i = -r[0].swiperSlideOffset;
                          e.params.virtualTranslate || (i -= e.translate);
                          var a = 0;
                          e.isHorizontal() || ((a = i), (i = 0));
                          var s = e.params.fadeEffect.crossFade ? Math.max(1 - Math.abs(r[0].progress), 0) : 1 + Math.min(Math.max(r[0].progress, -1), 0);
                          r.css({ opacity: s }).transform("translate3d(" + i + "px, " + a + "px, 0px)");
                      }
                  },
                  setTransition: function (e) {
                      var t = this,
                          n = t.slides,
                          r = t.$wrapperEl;
                      if ((n.transition(e), t.params.virtualTranslate && 0 !== e)) {
                          var i = !1;
                          n.transitionEnd(function () {
                              if (!i && t && !t.destroyed) {
                                  (i = !0), (t.animating = !1);
                                  for (var e = ["webkitTransitionEnd", "transitionend"], n = 0; n < e.length; n += 1) r.trigger(e[n]);
                              }
                          });
                      }
                  },
              },
              de = {
                  setTranslate: function () {
                      var e,
                          t = this,
                          n = t.$el,
                          r = t.$wrapperEl,
                          i = t.slides,
                          a = t.width,
                          s = t.height,
                          o = t.rtlTranslate,
                          l = t.size,
                          d = t.browser,
                          u = t.params.cubeEffect,
                          c = t.isHorizontal(),
                          p = t.virtual && t.params.virtual.enabled,
                          f = 0;
                      u.shadow &&
                          (c
                              ? (0 === (e = r.find(".swiper-cube-shadow")).length && ((e = g('<div class="swiper-cube-shadow"></div>')), r.append(e)), e.css({ height: a + "px" }))
                              : 0 === (e = n.find(".swiper-cube-shadow")).length && ((e = g('<div class="swiper-cube-shadow"></div>')), n.append(e)));
                      for (var h = 0; h < i.length; h += 1) {
                          var m = i.eq(h),
                              v = h;
                          p && (v = parseInt(m.attr("data-swiper-slide-index"), 10));
                          var y = 90 * v,
                              w = Math.floor(y / 360);
                          o && ((y = -y), (w = Math.floor(-y / 360)));
                          var b = Math.max(Math.min(m[0].progress, 1), -1),
                              E = 0,
                              x = 0,
                              S = 0;
                          v % 4 == 0 ? ((E = 4 * -w * l), (S = 0)) : (v - 1) % 4 == 0 ? ((E = 0), (S = 4 * -w * l)) : (v - 2) % 4 == 0 ? ((E = l + 4 * w * l), (S = l)) : (v - 3) % 4 == 0 && ((E = -l), (S = 3 * l + 4 * l * w)),
                              o && (E = -E),
                              c || ((x = E), (E = 0));
                          var T = "rotateX(" + (c ? 0 : -y) + "deg) rotateY(" + (c ? y : 0) + "deg) translate3d(" + E + "px, " + x + "px, " + S + "px)";
                          if ((b <= 1 && b > -1 && ((f = 90 * v + 90 * b), o && (f = 90 * -v - 90 * b)), m.transform(T), u.slideShadows)) {
                              var _ = c ? m.find(".swiper-slide-shadow-left") : m.find(".swiper-slide-shadow-top"),
                                  C = c ? m.find(".swiper-slide-shadow-right") : m.find(".swiper-slide-shadow-bottom");
                              0 === _.length && ((_ = g('<div class="swiper-slide-shadow-' + (c ? "left" : "top") + '"></div>')), m.append(_)),
                                  0 === C.length && ((C = g('<div class="swiper-slide-shadow-' + (c ? "right" : "bottom") + '"></div>')), m.append(C)),
                                  _.length && (_[0].style.opacity = Math.max(-b, 0)),
                                  C.length && (C[0].style.opacity = Math.max(b, 0));
                          }
                      }
                      if (
                          (r.css({
                              "-webkit-transform-origin": "50% 50% -" + l / 2 + "px",
                              "-moz-transform-origin": "50% 50% -" + l / 2 + "px",
                              "-ms-transform-origin": "50% 50% -" + l / 2 + "px",
                              "transform-origin": "50% 50% -" + l / 2 + "px",
                          }),
                          u.shadow)
                      )
                          if (c) e.transform("translate3d(0px, " + (a / 2 + u.shadowOffset) + "px, " + -a / 2 + "px) rotateX(90deg) rotateZ(0deg) scale(" + u.shadowScale + ")");
                          else {
                              var M = Math.abs(f) - 90 * Math.floor(Math.abs(f) / 90),
                                  P = 1.5 - (Math.sin((2 * M * Math.PI) / 360) / 2 + Math.cos((2 * M * Math.PI) / 360) / 2),
                                  L = u.shadowScale,
                                  A = u.shadowScale / P,
                                  k = u.shadowOffset;
                              e.transform("scale3d(" + L + ", 1, " + A + ") translate3d(0px, " + (s / 2 + k) + "px, " + -s / 2 / A + "px) rotateX(-90deg)");
                          }
                      var z = d.isSafari || d.isWebView ? -l / 2 : 0;
                      r.transform("translate3d(0px,0," + z + "px) rotateX(" + (t.isHorizontal() ? 0 : f) + "deg) rotateY(" + (t.isHorizontal() ? -f : 0) + "deg)");
                  },
                  setTransition: function (e) {
                      var t = this,
                          n = t.$el;
                      t.slides.transition(e).find(".swiper-slide-shadow-top, .swiper-slide-shadow-right, .swiper-slide-shadow-bottom, .swiper-slide-shadow-left").transition(e),
                          t.params.cubeEffect.shadow && !t.isHorizontal() && n.find(".swiper-cube-shadow").transition(e);
                  },
              },
              ue = {
                  setTranslate: function () {
                      for (var e = this, t = e.slides, n = e.rtlTranslate, r = 0; r < t.length; r += 1) {
                          var i = t.eq(r),
                              a = i[0].progress;
                          e.params.flipEffect.limitRotation && (a = Math.max(Math.min(i[0].progress, 1), -1));
                          var s = -180 * a,
                              o = 0,
                              l = -i[0].swiperSlideOffset,
                              d = 0;
                          if ((e.isHorizontal() ? n && (s = -s) : ((d = l), (l = 0), (o = -s), (s = 0)), (i[0].style.zIndex = -Math.abs(Math.round(a)) + t.length), e.params.flipEffect.slideShadows)) {
                              var u = e.isHorizontal() ? i.find(".swiper-slide-shadow-left") : i.find(".swiper-slide-shadow-top"),
                                  c = e.isHorizontal() ? i.find(".swiper-slide-shadow-right") : i.find(".swiper-slide-shadow-bottom");
                              0 === u.length && ((u = g('<div class="swiper-slide-shadow-' + (e.isHorizontal() ? "left" : "top") + '"></div>')), i.append(u)),
                                  0 === c.length && ((c = g('<div class="swiper-slide-shadow-' + (e.isHorizontal() ? "right" : "bottom") + '"></div>')), i.append(c)),
                                  u.length && (u[0].style.opacity = Math.max(-a, 0)),
                                  c.length && (c[0].style.opacity = Math.max(a, 0));
                          }
                          i.transform("translate3d(" + l + "px, " + d + "px, 0px) rotateX(" + o + "deg) rotateY(" + s + "deg)");
                      }
                  },
                  setTransition: function (e) {
                      var t = this,
                          n = t.slides,
                          r = t.activeIndex,
                          i = t.$wrapperEl;
                      if ((n.transition(e).find(".swiper-slide-shadow-top, .swiper-slide-shadow-right, .swiper-slide-shadow-bottom, .swiper-slide-shadow-left").transition(e), t.params.virtualTranslate && 0 !== e)) {
                          var a = !1;
                          n.eq(r).transitionEnd(function () {
                              if (!a && t && !t.destroyed) {
                                  (a = !0), (t.animating = !1);
                                  for (var e = ["webkitTransitionEnd", "transitionend"], n = 0; n < e.length; n += 1) i.trigger(e[n]);
                              }
                          });
                      }
                  },
              },
              ce = {
                  setTranslate: function () {
                      for (
                          var e = this,
                              t = e.width,
                              n = e.height,
                              r = e.slides,
                              i = e.slidesSizesGrid,
                              a = e.params.coverflowEffect,
                              s = e.isHorizontal(),
                              o = e.translate,
                              l = s ? t / 2 - o : n / 2 - o,
                              d = s ? a.rotate : -a.rotate,
                              u = a.depth,
                              c = 0,
                              p = r.length;
                          c < p;
                          c += 1
                      ) {
                          var f = r.eq(c),
                              h = i[c],
                              m = ((l - f[0].swiperSlideOffset - h / 2) / h) * a.modifier,
                              v = s ? d * m : 0,
                              y = s ? 0 : d * m,
                              w = -u * Math.abs(m),
                              b = a.stretch;
                          "string" == typeof b && -1 !== b.indexOf("%") && (b = (parseFloat(a.stretch) / 100) * h);
                          var E = s ? 0 : b * m,
                              x = s ? b * m : 0,
                              S = 1 - (1 - a.scale) * Math.abs(m);
                          Math.abs(x) < 0.001 && (x = 0), Math.abs(E) < 0.001 && (E = 0), Math.abs(w) < 0.001 && (w = 0), Math.abs(v) < 0.001 && (v = 0), Math.abs(y) < 0.001 && (y = 0), Math.abs(S) < 0.001 && (S = 0);
                          var T = "translate3d(" + x + "px," + E + "px," + w + "px)  rotateX(" + y + "deg) rotateY(" + v + "deg) scale(" + S + ")";
                          if ((f.transform(T), (f[0].style.zIndex = 1 - Math.abs(Math.round(m))), a.slideShadows)) {
                              var _ = s ? f.find(".swiper-slide-shadow-left") : f.find(".swiper-slide-shadow-top"),
                                  C = s ? f.find(".swiper-slide-shadow-right") : f.find(".swiper-slide-shadow-bottom");
                              0 === _.length && ((_ = g('<div class="swiper-slide-shadow-' + (s ? "left" : "top") + '"></div>')), f.append(_)),
                                  0 === C.length && ((C = g('<div class="swiper-slide-shadow-' + (s ? "right" : "bottom") + '"></div>')), f.append(C)),
                                  _.length && (_[0].style.opacity = m > 0 ? m : 0),
                                  C.length && (C[0].style.opacity = -m > 0 ? -m : 0);
                          }
                      }
                  },
                  setTransition: function (e) {
                      this.slides.transition(e).find(".swiper-slide-shadow-top, .swiper-slide-shadow-right, .swiper-slide-shadow-bottom, .swiper-slide-shadow-left").transition(e);
                  },
              },
              pe = {
                  init: function () {
                      var e = this,
                          t = e.params.thumbs;
                      if (e.thumbs.initialized) return !1;
                      e.thumbs.initialized = !0;
                      var n = e.constructor;
                      return (
                          t.swiper instanceof n
                              ? ((e.thumbs.swiper = t.swiper), C(e.thumbs.swiper.originalParams, { watchSlidesProgress: !0, slideToClickedSlide: !1 }), C(e.thumbs.swiper.params, { watchSlidesProgress: !0, slideToClickedSlide: !1 }))
                              : _(t.swiper) && ((e.thumbs.swiper = new n(C({}, t.swiper, { watchSlidesVisibility: !0, watchSlidesProgress: !0, slideToClickedSlide: !1 }))), (e.thumbs.swiperCreated = !0)),
                          e.thumbs.swiper.$el.addClass(e.params.thumbs.thumbsContainerClass),
                          e.thumbs.swiper.on("tap", e.thumbs.onThumbClick),
                          !0
                      );
                  },
                  onThumbClick: function () {
                      var e = this,
                          t = e.thumbs.swiper;
                      if (t) {
                          var n = t.clickedIndex,
                              r = t.clickedSlide;
                          if (!((r && g(r).hasClass(e.params.thumbs.slideThumbActiveClass)) || null == n)) {
                              var i;
                              if (((i = t.params.loop ? parseInt(g(t.clickedSlide).attr("data-swiper-slide-index"), 10) : n), e.params.loop)) {
                                  var a = e.activeIndex;
                                  e.slides.eq(a).hasClass(e.params.slideDuplicateClass) && (e.loopFix(), (e._clientLeft = e.$wrapperEl[0].clientLeft), (a = e.activeIndex));
                                  var s = e.slides
                                          .eq(a)
                                          .prevAll('[data-swiper-slide-index="' + i + '"]')
                                          .eq(0)
                                          .index(),
                                      o = e.slides
                                          .eq(a)
                                          .nextAll('[data-swiper-slide-index="' + i + '"]')
                                          .eq(0)
                                          .index();
                                  i = void 0 === s ? o : void 0 === o ? s : o - a < a - s ? o : s;
                              }
                              e.slideTo(i);
                          }
                      }
                  },
                  update: function (e) {
                      var t = this,
                          n = t.thumbs.swiper;
                      if (n) {
                          var r = "auto" === n.params.slidesPerView ? n.slidesPerViewDynamic() : n.params.slidesPerView,
                              i = t.params.thumbs.autoScrollOffset,
                              a = i && !n.params.loop;
                          if (t.realIndex !== n.realIndex || a) {
                              var s,
                                  o,
                                  l = n.activeIndex;
                              if (n.params.loop) {
                                  n.slides.eq(l).hasClass(n.params.slideDuplicateClass) && (n.loopFix(), (n._clientLeft = n.$wrapperEl[0].clientLeft), (l = n.activeIndex));
                                  var d = n.slides
                                          .eq(l)
                                          .prevAll('[data-swiper-slide-index="' + t.realIndex + '"]')
                                          .eq(0)
                                          .index(),
                                      u = n.slides
                                          .eq(l)
                                          .nextAll('[data-swiper-slide-index="' + t.realIndex + '"]')
                                          .eq(0)
                                          .index();
                                  (s = void 0 === d ? u : void 0 === u ? d : u - l == l - d ? l : u - l < l - d ? u : d), (o = t.activeIndex > t.previousIndex ? "next" : "prev");
                              } else o = (s = t.realIndex) > t.previousIndex ? "next" : "prev";
                              a && (s += "next" === o ? i : -1 * i),
                                  n.visibleSlidesIndexes &&
                                      n.visibleSlidesIndexes.indexOf(s) < 0 &&
                                      (n.params.centeredSlides ? (s = s > l ? s - Math.floor(r / 2) + 1 : s + Math.floor(r / 2) - 1) : s > l && (s = s - r + 1), n.slideTo(s, e ? 0 : void 0));
                          }
                          var c = 1,
                              p = t.params.thumbs.slideThumbActiveClass;
                          if (
                              (t.params.slidesPerView > 1 && !t.params.centeredSlides && (c = t.params.slidesPerView),
                              t.params.thumbs.multipleActiveThumbs || (c = 1),
                              (c = Math.floor(c)),
                              n.slides.removeClass(p),
                              n.params.loop || (n.params.virtual && n.params.virtual.enabled))
                          )
                              for (var f = 0; f < c; f += 1) n.$wrapperEl.children('[data-swiper-slide-index="' + (t.realIndex + f) + '"]').addClass(p);
                          else for (var h = 0; h < c; h += 1) n.slides.eq(t.realIndex + h).addClass(p);
                      }
                  },
              },
              fe = [
                  X,
                  U,
                  {
                      name: "mousewheel",
                      params: { mousewheel: { enabled: !1, releaseOnEdges: !1, invert: !1, forceToAxis: !1, sensitivity: 1, eventsTarget: "container", thresholdDelta: null, thresholdTime: null } },
                      create: function () {
                          M(this, {
                              mousewheel: {
                                  enabled: !1,
                                  lastScrollTime: S(),
                                  lastEventBeforeSnap: void 0,
                                  recentWheelEvents: [],
                                  enable: K.enable,
                                  disable: K.disable,
                                  handle: K.handle,
                                  handleMouseEnter: K.handleMouseEnter,
                                  handleMouseLeave: K.handleMouseLeave,
                                  animateSlider: K.animateSlider,
                                  releaseScroll: K.releaseScroll,
                              },
                          });
                      },
                      on: {
                          init: function (e) {
                              !e.params.mousewheel.enabled && e.params.cssMode && e.mousewheel.disable(), e.params.mousewheel.enabled && e.mousewheel.enable();
                          },
                          destroy: function (e) {
                              e.params.cssMode && e.mousewheel.enable(), e.mousewheel.enabled && e.mousewheel.disable();
                          },
                      },
                  },
                  {
                      name: "navigation",
                      params: { navigation: { nextEl: null, prevEl: null, hideOnClick: !1, disabledClass: "swiper-button-disabled", hiddenClass: "swiper-button-hidden", lockClass: "swiper-button-lock" } },
                      create: function () {
                          M(this, { navigation: t({}, Q) });
                      },
                      on: {
                          init: function (e) {
                              e.navigation.init(), e.navigation.update();
                          },
                          toEdge: function (e) {
                              e.navigation.update();
                          },
                          fromEdge: function (e) {
                              e.navigation.update();
                          },
                          destroy: function (e) {
                              e.navigation.destroy();
                          },
                          click: function (e, t) {
                              var n,
                                  r = e.navigation,
                                  i = r.$nextEl,
                                  a = r.$prevEl;
                              !e.params.navigation.hideOnClick ||
                                  g(t.target).is(a) ||
                                  g(t.target).is(i) ||
                                  (i ? (n = i.hasClass(e.params.navigation.hiddenClass)) : a && (n = a.hasClass(e.params.navigation.hiddenClass)),
                                  !0 === n ? e.emit("navigationShow") : e.emit("navigationHide"),
                                  i && i.toggleClass(e.params.navigation.hiddenClass),
                                  a && a.toggleClass(e.params.navigation.hiddenClass));
                          },
                      },
                  },
                  {
                      name: "pagination",
                      params: {
                          pagination: {
                              el: null,
                              bulletElement: "span",
                              clickable: !1,
                              hideOnClick: !1,
                              renderBullet: null,
                              renderProgressbar: null,
                              renderFraction: null,
                              renderCustom: null,
                              progressbarOpposite: !1,
                              type: "bullets",
                              dynamicBullets: !1,
                              dynamicMainBullets: 1,
                              formatFractionCurrent: function (e) {
                                  return e;
                              },
                              formatFractionTotal: function (e) {
                                  return e;
                              },
                              bulletClass: "swiper-pagination-bullet",
                              bulletActiveClass: "swiper-pagination-bullet-active",
                              modifierClass: "swiper-pagination-",
                              currentClass: "swiper-pagination-current",
                              totalClass: "swiper-pagination-total",
                              hiddenClass: "swiper-pagination-hidden",
                              progressbarFillClass: "swiper-pagination-progressbar-fill",
                              progressbarOppositeClass: "swiper-pagination-progressbar-opposite",
                              clickableClass: "swiper-pagination-clickable",
                              lockClass: "swiper-pagination-lock",
                          },
                      },
                      create: function () {
                          M(this, { pagination: t({ dynamicBulletIndex: 0 }, Z) });
                      },
                      on: {
                          init: function (e) {
                              e.pagination.init(), e.pagination.render(), e.pagination.update();
                          },
                          activeIndexChange: function (e) {
                              (e.params.loop || void 0 === e.snapIndex) && e.pagination.update();
                          },
                          snapIndexChange: function (e) {
                              e.params.loop || e.pagination.update();
                          },
                          slidesLengthChange: function (e) {
                              e.params.loop && (e.pagination.render(), e.pagination.update());
                          },
                          snapGridLengthChange: function (e) {
                              e.params.loop || (e.pagination.render(), e.pagination.update());
                          },
                          destroy: function (e) {
                              e.pagination.destroy();
                          },
                          click: function (e, t) {
                              e.params.pagination.el &&
                                  e.params.pagination.hideOnClick &&
                                  e.pagination.$el.length > 0 &&
                                  !g(t.target).hasClass(e.params.pagination.bulletClass) &&
                                  (!0 === e.pagination.$el.hasClass(e.params.pagination.hiddenClass) ? e.emit("paginationShow") : e.emit("paginationHide"), e.pagination.$el.toggleClass(e.params.pagination.hiddenClass));
                          },
                      },
                  },
                  {
                      name: "scrollbar",
                      params: { scrollbar: { el: null, dragSize: "auto", hide: !1, draggable: !1, snapOnRelease: !0, lockClass: "swiper-scrollbar-lock", dragClass: "swiper-scrollbar-drag" } },
                      create: function () {
                          M(this, { scrollbar: t({ isTouched: !1, timeout: null, dragTimeout: null }, J) });
                      },
                      on: {
                          init: function (e) {
                              e.scrollbar.init(), e.scrollbar.updateSize(), e.scrollbar.setTranslate();
                          },
                          update: function (e) {
                              e.scrollbar.updateSize();
                          },
                          resize: function (e) {
                              e.scrollbar.updateSize();
                          },
                          observerUpdate: function (e) {
                              e.scrollbar.updateSize();
                          },
                          setTranslate: function (e) {
                              e.scrollbar.setTranslate();
                          },
                          setTransition: function (e, t) {
                              e.scrollbar.setTransition(t);
                          },
                          destroy: function (e) {
                              e.scrollbar.destroy();
                          },
                      },
                  },
                  {
                      name: "parallax",
                      params: { parallax: { enabled: !1 } },
                      create: function () {
                          M(this, { parallax: t({}, ee) });
                      },
                      on: {
                          beforeInit: function (e) {
                              e.params.parallax.enabled && ((e.params.watchSlidesProgress = !0), (e.originalParams.watchSlidesProgress = !0));
                          },
                          init: function (e) {
                              e.params.parallax.enabled && e.parallax.setTranslate();
                          },
                          setTranslate: function (e) {
                              e.params.parallax.enabled && e.parallax.setTranslate();
                          },
                          setTransition: function (e, t) {
                              e.params.parallax.enabled && e.parallax.setTransition(t);
                          },
                      },
                  },
                  {
                      name: "zoom",
                      params: { zoom: { enabled: !1, maxRatio: 3, minRatio: 1, toggle: !0, containerClass: "swiper-zoom-container", zoomedSlideClass: "swiper-slide-zoomed" } },
                      create: function () {
                          var e = this;
                          M(e, {
                              zoom: t(
                                  {
                                      enabled: !1,
                                      scale: 1,
                                      currentScale: 1,
                                      isScaling: !1,
                                      gesture: { $slideEl: void 0, slideWidth: void 0, slideHeight: void 0, $imageEl: void 0, $imageWrapEl: void 0, maxRatio: 3 },
                                      image: {
                                          isTouched: void 0,
                                          isMoved: void 0,
                                          currentX: void 0,
                                          currentY: void 0,
                                          minX: void 0,
                                          minY: void 0,
                                          maxX: void 0,
                                          maxY: void 0,
                                          width: void 0,
                                          height: void 0,
                                          startX: void 0,
                                          startY: void 0,
                                          touchesStart: {},
                                          touchesCurrent: {},
                                      },
                                      velocity: { x: void 0, y: void 0, prevPositionX: void 0, prevPositionY: void 0, prevTime: void 0 },
                                  },
                                  te
                              ),
                          });
                          var n = 1;
                          Object.defineProperty(e.zoom, "scale", {
                              get: function () {
                                  return n;
                              },
                              set: function (t) {
                                  if (n !== t) {
                                      var r = e.zoom.gesture.$imageEl ? e.zoom.gesture.$imageEl[0] : void 0,
                                          i = e.zoom.gesture.$slideEl ? e.zoom.gesture.$slideEl[0] : void 0;
                                      e.emit("zoomChange", t, r, i);
                                  }
                                  n = t;
                              },
                          });
                      },
                      on: {
                          init: function (e) {
                              e.params.zoom.enabled && e.zoom.enable();
                          },
                          destroy: function (e) {
                              e.zoom.disable();
                          },
                          touchStart: function (e, t) {
                              e.zoom.enabled && e.zoom.onTouchStart(t);
                          },
                          touchEnd: function (e, t) {
                              e.zoom.enabled && e.zoom.onTouchEnd(t);
                          },
                          doubleTap: function (e, t) {
                              e.params.zoom.enabled && e.zoom.enabled && e.params.zoom.toggle && e.zoom.toggle(t);
                          },
                          transitionEnd: function (e) {
                              e.zoom.enabled && e.params.zoom.enabled && e.zoom.onTransitionEnd();
                          },
                          slideChange: function (e) {
                              e.zoom.enabled && e.params.zoom.enabled && e.params.cssMode && e.zoom.onTransitionEnd();
                          },
                      },
                  },
                  {
                      name: "lazy",
                      params: {
                          lazy: {
                              checkInView: !1,
                              enabled: !1,
                              loadPrevNext: !1,
                              loadPrevNextAmount: 1,
                              loadOnTransitionStart: !1,
                              scrollingElement: "",
                              elementClass: "swiper-lazy",
                              loadingClass: "swiper-lazy-loading",
                              loadedClass: "swiper-lazy-loaded",
                              preloaderClass: "swiper-lazy-preloader",
                          },
                      },
                      create: function () {
                          M(this, { lazy: t({ initialImageLoaded: !1 }, ne) });
                      },
                      on: {
                          beforeInit: function (e) {
                              e.params.lazy.enabled && e.params.preloadImages && (e.params.preloadImages = !1);
                          },
                          init: function (e) {
                              e.params.lazy.enabled && !e.params.loop && 0 === e.params.initialSlide && (e.params.lazy.checkInView ? e.lazy.checkInViewOnLoad() : e.lazy.load());
                          },
                          scroll: function (e) {
                              e.params.freeMode && !e.params.freeModeSticky && e.lazy.load();
                          },
                          resize: function (e) {
                              e.params.lazy.enabled && e.lazy.load();
                          },
                          scrollbarDragMove: function (e) {
                              e.params.lazy.enabled && e.lazy.load();
                          },
                          transitionStart: function (e) {
                              e.params.lazy.enabled && (e.params.lazy.loadOnTransitionStart || (!e.params.lazy.loadOnTransitionStart && !e.lazy.initialImageLoaded)) && e.lazy.load();
                          },
                          transitionEnd: function (e) {
                              e.params.lazy.enabled && !e.params.lazy.loadOnTransitionStart && e.lazy.load();
                          },
                          slideChange: function (e) {
                              e.params.lazy.enabled && e.params.cssMode && e.lazy.load();
                          },
                      },
                  },
                  {
                      name: "controller",
                      params: { controller: { control: void 0, inverse: !1, by: "slide" } },
                      create: function () {
                          M(this, { controller: t({ control: this.params.controller.control }, re) });
                      },
                      on: {
                          update: function (e) {
                              e.controller.control && e.controller.spline && ((e.controller.spline = void 0), delete e.controller.spline);
                          },
                          resize: function (e) {
                              e.controller.control && e.controller.spline && ((e.controller.spline = void 0), delete e.controller.spline);
                          },
                          observerUpdate: function (e) {
                              e.controller.control && e.controller.spline && ((e.controller.spline = void 0), delete e.controller.spline);
                          },
                          setTranslate: function (e, t, n) {
                              e.controller.control && e.controller.setTranslate(t, n);
                          },
                          setTransition: function (e, t, n) {
                              e.controller.control && e.controller.setTransition(t, n);
                          },
                      },
                  },
                  {
                      name: "a11y",
                      params: {
                          a11y: {
                              enabled: !0,
                              notificationClass: "swiper-notification",
                              prevSlideMessage: "Previous slide",
                              nextSlideMessage: "Next slide",
                              firstSlideMessage: "This is the first slide",
                              lastSlideMessage: "This is the last slide",
                              paginationBulletMessage: "Go to slide {{index}}",
                              containerMessage: null,
                              containerRoleDescriptionMessage: null,
                              itemRoleDescriptionMessage: null,
                          },
                      },
                      create: function () {
                          M(this, { a11y: t({}, ie, { liveRegion: g('<span class="' + this.params.a11y.notificationClass + '" aria-live="assertive" aria-atomic="true"></span>') }) });
                      },
                      on: {
                          afterInit: function (e) {
                              e.params.a11y.enabled && (e.a11y.init(), e.a11y.updateNavigation());
                          },
                          toEdge: function (e) {
                              e.params.a11y.enabled && e.a11y.updateNavigation();
                          },
                          fromEdge: function (e) {
                              e.params.a11y.enabled && e.a11y.updateNavigation();
                          },
                          paginationUpdate: function (e) {
                              e.params.a11y.enabled && e.a11y.updatePagination();
                          },
                          destroy: function (e) {
                              e.params.a11y.enabled && e.a11y.destroy();
                          },
                      },
                  },
                  {
                      name: "history",
                      params: { history: { enabled: !1, replaceState: !1, key: "slides" } },
                      create: function () {
                          M(this, { history: t({}, ae) });
                      },
                      on: {
                          init: function (e) {
                              e.params.history.enabled && e.history.init();
                          },
                          destroy: function (e) {
                              e.params.history.enabled && e.history.destroy();
                          },
                          transitionEnd: function (e) {
                              e.history.initialized && e.history.setHistory(e.params.history.key, e.activeIndex);
                          },
                          slideChange: function (e) {
                              e.history.initialized && e.params.cssMode && e.history.setHistory(e.params.history.key, e.activeIndex);
                          },
                      },
                  },
                  {
                      name: "hash-navigation",
                      params: { hashNavigation: { enabled: !1, replaceState: !1, watchState: !1 } },
                      create: function () {
                          M(this, { hashNavigation: t({ initialized: !1 }, se) });
                      },
                      on: {
                          init: function (e) {
                              e.params.hashNavigation.enabled && e.hashNavigation.init();
                          },
                          destroy: function (e) {
                              e.params.hashNavigation.enabled && e.hashNavigation.destroy();
                          },
                          transitionEnd: function (e) {
                              e.hashNavigation.initialized && e.hashNavigation.setHash();
                          },
                          slideChange: function (e) {
                              e.hashNavigation.initialized && e.params.cssMode && e.hashNavigation.setHash();
                          },
                      },
                  },
                  {
                      name: "autoplay",
                      params: { autoplay: { enabled: !1, delay: 3e3, waitForTransition: !0, disableOnInteraction: !0, stopOnLastSlide: !1, reverseDirection: !1 } },
                      create: function () {
                          M(this, { autoplay: t({}, oe, { running: !1, paused: !1 }) });
                      },
                      on: {
                          init: function (e) {
                              e.params.autoplay.enabled && (e.autoplay.start(), s().addEventListener("visibilitychange", e.autoplay.onVisibilityChange));
                          },
                          beforeTransitionStart: function (e, t, n) {
                              e.autoplay.running && (n || !e.params.autoplay.disableOnInteraction ? e.autoplay.pause(t) : e.autoplay.stop());
                          },
                          sliderFirstMove: function (e) {
                              e.autoplay.running && (e.params.autoplay.disableOnInteraction ? e.autoplay.stop() : e.autoplay.pause());
                          },
                          touchEnd: function (e) {
                              e.params.cssMode && e.autoplay.paused && !e.params.autoplay.disableOnInteraction && e.autoplay.run();
                          },
                          destroy: function (e) {
                              e.autoplay.running && e.autoplay.stop(), s().removeEventListener("visibilitychange", e.autoplay.onVisibilityChange);
                          },
                      },
                  },
                  {
                      name: "effect-fade",
                      params: { fadeEffect: { crossFade: !1 } },
                      create: function () {
                          M(this, { fadeEffect: t({}, le) });
                      },
                      on: {
                          beforeInit: function (e) {
                              if ("fade" === e.params.effect) {
                                  e.classNames.push(e.params.containerModifierClass + "fade");
                                  var t = { slidesPerView: 1, slidesPerColumn: 1, slidesPerGroup: 1, watchSlidesProgress: !0, spaceBetween: 0, virtualTranslate: !0 };
                                  C(e.params, t), C(e.originalParams, t);
                              }
                          },
                          setTranslate: function (e) {
                              "fade" === e.params.effect && e.fadeEffect.setTranslate();
                          },
                          setTransition: function (e, t) {
                              "fade" === e.params.effect && e.fadeEffect.setTransition(t);
                          },
                      },
                  },
                  {
                      name: "effect-cube",
                      params: { cubeEffect: { slideShadows: !0, shadow: !0, shadowOffset: 20, shadowScale: 0.94 } },
                      create: function () {
                          M(this, { cubeEffect: t({}, de) });
                      },
                      on: {
                          beforeInit: function (e) {
                              if ("cube" === e.params.effect) {
                                  e.classNames.push(e.params.containerModifierClass + "cube"), e.classNames.push(e.params.containerModifierClass + "3d");
                                  var t = { slidesPerView: 1, slidesPerColumn: 1, slidesPerGroup: 1, watchSlidesProgress: !0, resistanceRatio: 0, spaceBetween: 0, centeredSlides: !1, virtualTranslate: !0 };
                                  C(e.params, t), C(e.originalParams, t);
                              }
                          },
                          setTranslate: function (e) {
                              "cube" === e.params.effect && e.cubeEffect.setTranslate();
                          },
                          setTransition: function (e, t) {
                              "cube" === e.params.effect && e.cubeEffect.setTransition(t);
                          },
                      },
                  },
                  {
                      name: "effect-flip",
                      params: { flipEffect: { slideShadows: !0, limitRotation: !0 } },
                      create: function () {
                          M(this, { flipEffect: t({}, ue) });
                      },
                      on: {
                          beforeInit: function (e) {
                              if ("flip" === e.params.effect) {
                                  e.classNames.push(e.params.containerModifierClass + "flip"), e.classNames.push(e.params.containerModifierClass + "3d");
                                  var t = { slidesPerView: 1, slidesPerColumn: 1, slidesPerGroup: 1, watchSlidesProgress: !0, spaceBetween: 0, virtualTranslate: !0 };
                                  C(e.params, t), C(e.originalParams, t);
                              }
                          },
                          setTranslate: function (e) {
                              "flip" === e.params.effect && e.flipEffect.setTranslate();
                          },
                          setTransition: function (e, t) {
                              "flip" === e.params.effect && e.flipEffect.setTransition(t);
                          },
                      },
                  },
                  {
                      name: "effect-coverflow",
                      params: { coverflowEffect: { rotate: 50, stretch: 0, depth: 100, scale: 1, modifier: 1, slideShadows: !0 } },
                      create: function () {
                          M(this, { coverflowEffect: t({}, ce) });
                      },
                      on: {
                          beforeInit: function (e) {
                              "coverflow" === e.params.effect &&
                                  (e.classNames.push(e.params.containerModifierClass + "coverflow"),
                                  e.classNames.push(e.params.containerModifierClass + "3d"),
                                  (e.params.watchSlidesProgress = !0),
                                  (e.originalParams.watchSlidesProgress = !0));
                          },
                          setTranslate: function (e) {
                              "coverflow" === e.params.effect && e.coverflowEffect.setTranslate();
                          },
                          setTransition: function (e, t) {
                              "coverflow" === e.params.effect && e.coverflowEffect.setTransition(t);
                          },
                      },
                  },
                  {
                      name: "thumbs",
                      params: { thumbs: { swiper: null, multipleActiveThumbs: !0, autoScrollOffset: 0, slideThumbActiveClass: "swiper-slide-thumb-active", thumbsContainerClass: "swiper-container-thumbs" } },
                      create: function () {
                          M(this, { thumbs: t({ swiper: null, initialized: !1 }, pe) });
                      },
                      on: {
                          beforeInit: function (e) {
                              var t = e.params.thumbs;
                              t && t.swiper && (e.thumbs.init(), e.thumbs.update(!0));
                          },
                          slideChange: function (e) {
                              e.thumbs.swiper && e.thumbs.update();
                          },
                          update: function (e) {
                              e.thumbs.swiper && e.thumbs.update();
                          },
                          resize: function (e) {
                              e.thumbs.swiper && e.thumbs.update();
                          },
                          observerUpdate: function (e) {
                              e.thumbs.swiper && e.thumbs.update();
                          },
                          setTransition: function (e, t) {
                              var n = e.thumbs.swiper;
                              n && n.setTransition(t);
                          },
                          beforeDestroy: function (e) {
                              var t = e.thumbs.swiper;
                              t && e.thumbs.swiperCreated && t && t.destroy();
                          },
                      },
                  },
              ];
          return V.use(fe), V;
      });
  },
  function (e, t, n) {
      "use strict";
      if (r || a || i != null) {
      var r = n(2)(n(43)),
          i = document.querySelector(".drop-down"),
          a = document.querySelector(".drop-down-bg");
      r.default.set(a, { height: i.clientHeight }),
          i.addEventListener("mouseover", function () {
              r.default.to(a, { duration: 1, height: i.scrollHeight, ease: "Power4.easeOut" });
          }),
          i.addEventListener("mouseleave", function () {
              r.default.to(a, { duration: 1, height: i.clientHeight, delay: 0.2, ease: "Power4.easeOut" });
          });
        }
  },
  function (e, t, n) {
      "use strict";
      var r = n(2),
          i = (r(n(43)), r(n(8))),
          a = window.innerWidth <= 1024,
          s = document.querySelectorAll(".nav-item-container"),
          o = document.querySelectorAll(".nav-item-sub");
      if (a) {
          s.forEach(function (e) {
              var t = e.querySelector("svg"),
                  n = e.querySelector(".nav-item-sub");
              t.addEventListener("click", function (e) {
                  e.stopPropagation(),
                      e.preventDefault(),
                      console.log(n.style.display),
                      "none" === n.style.display || "" == n.style.display
                          ? (o.forEach(function (e) {
                                return (e.style.display = "none");
                            }),
                            (n.style.display = "block"))
                          : o.forEach(function (e) {
                                return (e.style.display = "none");
                            });
              });
          });
          var l = document.getElementById("nav");
          window.scroll = new i.default(function (e) {
              e > d ? (l.classList.add("hide"), l.classList.remove("show")) : e < d && (e > 0.03 ? l.classList.add("bgWhite") : l.classList.remove("bgWhite"), l.classList.remove("hide"), l.classList.add("show"));
              d = e;
          });
          var d = 0;
      }
  },
  function (e, t, n) {
      "use strict";
      var r = n(2),
          i = r(n(7));
      n(10);
      var a = r(n(6)),
          s = r(n(11)),
          o = r(n(12)),
          l = r(n(13)),
          d = r(n(8)),
          u = [].concat((0, i.default)(Array.from(document.querySelectorAll(".fade-in"))), (0, i.default)(Array.from(document.querySelectorAll(".fade-in-y"))));
      function c(e) {
          u.forEach(function (e) {
              !e.classList.contains("show") && a.default.isInViewportDom(e, 220) && e.classList.add("show");
          });
      }
      a.default.waitForLoader(function () {
          (window.scroll = new d.default(c)), new s.default(), new o.default(), new l.default();
          var e = document.querySelector(".scrollDown");
          if(e) {
          e.addEventListener("click", function () {
              window.scroll.goTo(e.dataset.to);
          }),
              c();
          }
      });
  },
  function (e, t, n) {
      "use strict";
      var r = n(2),
          i = r(n(7));
      n(10), n(16);
      var a = r(n(43)),
          s = r(n(6)),
          o = r(n(11)),
          l = r(n(12)),
          d = r(n(13)),
          u = r(n(8));
      function c(e, t) {
          var n;
          if ("undefined" == typeof Symbol || null == e[Symbol.iterator]) {
              if (
                  Array.isArray(e) ||
                  (n = (function (e, t) {
                      if (!e) return;
                      if ("string" == typeof e) return p(e, t);
                      var n = Object.prototype.toString.call(e).slice(8, -1);
                      "Object" === n && e.constructor && (n = e.constructor.name);
                      if ("Map" === n || "Set" === n) return Array.from(e);
                      if ("Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return p(e, t);
                  })(e)) ||
                  (t && e && "number" == typeof e.length)
              ) {
                  n && (e = n);
                  var r = 0,
                      i = function () {};
                  return {
                      s: i,
                      n: function () {
                          return r >= e.length ? { done: !0 } : { done: !1, value: e[r++] };
                      },
                      e: function (e) {
                          throw e;
                      },
                      f: i,
                  };
              }
              throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
          }
          var a,
              s = !0,
              o = !1;
          return {
              s: function () {
                  n = e[Symbol.iterator]();
              },
              n: function () {
                  var e = n.next();
                  return (s = e.done), e;
              },
              e: function (e) {
                  (o = !0), (a = e);
              },
              f: function () {
                  try {
                      s || null == n.return || n.return();
                  } finally {
                      if (o) throw a;
                  }
              },
          };
      }
      function p(e, t) {
          (null == t || t > e.length) && (t = e.length);
          for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
          return r;
      }
      var f,
          h = [].concat((0, i.default)(Array.from(document.querySelectorAll(".fade-in"))), (0, i.default)(Array.from(document.querySelectorAll(".fade-in-y"))));
      function m(e) {
          h.forEach(function (e) {
              !e.classList.contains("show") && s.default.isInViewportDom(e, 220) && e.classList.add("show");
          });
      }
      s.default.waitForLoader(function () {
          (window.scroll = new u.default(E)),
              (window.scroll = new u.default(m)),
              new o.default(),
              new l.default(),
              new d.default(),
              (function () {
                  window.innerWidth;
                  var e = 0.01 * window.innerHeight;
                  (f = window.innerWidth <= 1024) ? document.documentElement.style.setProperty("--vh", "".concat(e, "px")) : f || document.documentElement.style.setProperty("--vh", "".concat(e, "px"));
                  var t = document.querySelector(".container");
                  if (t) {
                      var n = t.getBoundingClientRect();
                      document.documentElement.style.setProperty("--container-margin", "".concat(n.left, "px")), document.documentElement.style.setProperty("--container-width", "".concat(n.width, "px"));
                  }
              })(),
              m();
          var e = document.querySelector(".scrollDown");
          if(e) {
          e.addEventListener("click", function () {
              window.scroll.goTo(e.dataset.to);
          });
        }
      });
      var v = document.querySelectorAll(".btn-tab"),
          g = document.querySelectorAll(".content-tab");
      v.forEach(function (e) {
          e.addEventListener("click", function (t) {
              var n = e.dataset.section,
                  r = document.getElementById(n);
              v.forEach(function (e) {
                  return e.classList.remove("active");
              }),
                  e.classList.add("active"),
                  g.forEach(function (e) {
                      return a.default.to(e, 0.6, { opacity: 0, display: "none", y: 20 });
                  }),
                  a.default.to(r, 0.6, { opacity: 1, display: "block", delay: 0.7, y: 0 });
          });
      });
      var y = document.querySelectorAll("section"),
          w = document.querySelectorAll(".menu_item"),
          b = document.querySelector(".itemsSticky");
      function E() {
          var e = new IntersectionObserver(
              function (e) {
                  e.forEach(function (e) {
                      if (e.isIntersecting) {
                          var t,
                              n = Array.from(w).find(function (t) {
                                  return t.dataset.url === e.target.id;
                              }),
                              r = c(w);
                          try {
                              for (r.s(); !(t = r.n()).done; ) {
                                  var i = t.value;
                                  i != n && i.classList.remove("active");
                              }
                          } catch (e) {
                              r.e(e);
                          } finally {
                              r.f();
                          }
                          if (n== 'undefined'){
                            "keydata" == n.dataset.url ? b.classList.add("white") : b.classList.remove("white"), n.classList.add("active");
                          }
                      }
                  });
              },
              { root: null, rootMargin: "0px", threshold: 0.2 }
          );
          y.forEach(function (t) {
              return e.observe(t);
          });
      }
  },
  function (e, t, n) {
      "use strict";
      var r = n(2),
          i = r(n(7));
      n(10), n(16);
      var a,
          s = r(n(6)),
          o = r(n(11)),
          l = r(n(12)),
          d = r(n(13)),
          u = r(n(8)),
          c = [].concat((0, i.default)(Array.from(document.querySelectorAll(".fade-in"))), (0, i.default)(Array.from(document.querySelectorAll(".fade-in-y"))));
      function p(e) {
          c.forEach(function (e) {
              !e.classList.contains("show") && s.default.isInViewportDom(e, 220) && e.classList.add("show");
          });
      }
      s.default.waitForLoader(function () {
          (window.scroll = new u.default()),
              new o.default(),
              new l.default(),
              new d.default(),
              (function () {
                  window.innerWidth;
                  var e = 0.01 * window.innerHeight;
                  (a = window.innerWidth <= 1024) ? document.documentElement.style.setProperty("--vh", "".concat(e, "px")) : a || document.documentElement.style.setProperty("--vh", "".concat(e, "px"));
                  var t = document.querySelector(".container");
                  if (t) {
                      var n = t.getBoundingClientRect();
                      document.documentElement.style.setProperty("--container-margin", "".concat(n.left, "px")), document.documentElement.style.setProperty("--container-width", "".concat(n.width, "px"));
                  }
              })();
          var e = document.querySelector(".scrollDown");
          if(e) {
          e.addEventListener("click", function () {
              window.scroll.goTo(e.dataset.to);
          }),
              (window.scroll = new u.default(p)),
              p();
        }
      });
  },
  function (e, t, n) {
      "use strict";
      var r = n(2),
          i = r(n(7));
      n(10);
      var a,
          s = r(n(6)),
          o = r(n(11)),
          l = r(n(12)),
          d = r(n(13)),
          u = r(n(8)),
          c = [].concat((0, i.default)(Array.from(document.querySelectorAll(".fade-in"))), (0, i.default)(Array.from(document.querySelectorAll(".fade-in-y"))));
      function p(e) {
          c.forEach(function (e) {
              !e.classList.contains("show") && s.default.isInViewportDom(e, 220) && e.classList.add("show");
          });
      }
      s.default.waitForLoader(function () {
          (window.scroll = new u.default()),
              new o.default(),
              new l.default(),
              new d.default(),
              (function () {
                  window.innerWidth;
                  var e = 0.01 * window.innerHeight;
                  (a = window.innerWidth <= 1024) ? document.documentElement.style.setProperty("--vh", "".concat(e, "px")) : a || document.documentElement.style.setProperty("--vh", "".concat(e, "px"));
                  var t = document.querySelector(".container");
                  if (t) {
                      var n = t.getBoundingClientRect();
                      document.documentElement.style.setProperty("--container-margin", "".concat(n.left, "px")), document.documentElement.style.setProperty("--container-width", "".concat(n.width, "px"));
                  }
              })(),
              (window.scroll = new u.default(p)),
              p();
      });
  },
  function (e, t, n) {
      "use strict";
      var r = n(2),
          i = r(n(7));
      n(10), n(113);
      var a = r(n(6)),
          s = r(n(11)),
          o = r(n(12)),
          l = r(n(13)),
          d = r(n(8)),
          u = [].concat((0, i.default)(Array.from(document.querySelectorAll(".fade-in"))), (0, i.default)(Array.from(document.querySelectorAll(".fade-in-y"))));
      function c(e) {
          u.forEach(function (e) {
              !e.classList.contains("show") && a.default.isInViewportDom(e, 220) && e.classList.add("show");
          });
      }
      a.default.waitForLoader(function () {
          new s.default(), new o.default(), new l.default(), (window.scroll = new d.default(c)), c();
      });
  },
  function (e, t, n) {
      "use strict";
      var r = n(2),
          i = r(n(7));
      n(10), n(16);
      var a,
          s = r(n(6)),
          o = r(n(11)),
          l = r(n(12)),
          d = r(n(13)),
          u = r(n(8)),
          c = [].concat((0, i.default)(Array.from(document.querySelectorAll(".fade-in"))), (0, i.default)(Array.from(document.querySelectorAll(".fade-in-y"))));
      function p(e) {
          c.forEach(function (e) {
              !e.classList.contains("show") && s.default.isInViewportDom(e, 220) && e.classList.add("show");
          });
      }
      s.default.waitForLoader(function () {
          (window.scroll = new u.default(p)),
              new o.default(),
              new l.default(),
              new d.default(),
              (function () {
                  window.innerWidth;
                  var e = 0.01 * window.innerHeight;
                  (a = window.innerWidth <= 1024) ? document.documentElement.style.setProperty("--vh", "".concat(e, "px")) : a || document.documentElement.style.setProperty("--vh", "".concat(e, "px"));
                  var t = document.querySelector(".container");
                  if (t) {
                      var n = t.getBoundingClientRect();
                      document.documentElement.style.setProperty("--container-margin", "".concat(n.left, "px")), document.documentElement.style.setProperty("--container-width", "".concat(n.width, "px"));
                  }
              })(),
              p();
      });
  },
  function (e, t, n) {
      "use strict";
      var r = n(2),
          i = r(n(7));
      n(10), n(16);
      var a,
          s = r(n(43)),
          o = r(n(6)),
          l = r(n(11)),
          d = r(n(12)),
          u = r(n(13)),
          c = r(n(8)),
          p = [].concat((0, i.default)(Array.from(document.querySelectorAll(".fade-in"))), (0, i.default)(Array.from(document.querySelectorAll(".fade-in-y"))));
      o.default.waitForLoader(function () {
          (window.scroll = new c.default(m)),
              new l.default(),
              new d.default(),
              new u.default(),
              (function () {
                  window.innerWidth;
                  var e = 0.01 * window.innerHeight;
                  (a = window.innerWidth <= 1024) ? document.documentElement.style.setProperty("--vh", "".concat(e, "px")) : a || document.documentElement.style.setProperty("--vh", "".concat(e, "px"));
                  var t = document.querySelector(".container");
                  if (t) {
                      var n = t.getBoundingClientRect();
                      document.documentElement.style.setProperty("--container-margin", "".concat(n.left, "px")), document.documentElement.style.setProperty("--container-width", "".concat(n.width, "px"));
                  }
              })(),
              m();
      });
      var f = document.querySelectorAll(".btn-tab"),
          h = document.querySelectorAll(".content-tab");
      function m(e) {
          p.forEach(function (e) {
              !e.classList.contains("show") && o.default.isInViewportDom(e, 220) && e.classList.add("show");
          });
      }
      f.forEach(function (e) {
          e.addEventListener("click", function (t) {
              var n = e.dataset.section,
                  r = document.getElementById(n);
              f.forEach(function (e) {
                  return e.classList.remove("active");
              }),
                  e.classList.add("active"),
                  h.forEach(function (e) {
                      return s.default.to(e, 0.6, { opacity: 0, display: "none", y: 20 });
                  }),
                  s.default.to(r, 0.6, { opacity: 1, display: "block", delay: 0.7, y: 0 });
          });
      });
  },
  function (e, t, n) {
      "use strict";
      var r = n(2),
          i = r(n(7));
      n(10), n(16);
      var a,
          s = r(n(6)),
          o = r(n(11)),
          l = r(n(12)),
          d = r(n(13)),
          u = r(n(8)),
          c = [].concat((0, i.default)(Array.from(document.querySelectorAll(".fade-in"))), (0, i.default)(Array.from(document.querySelectorAll(".fade-in-y"))));
      function p(e) {
          c.forEach(function (e) {
              !e.classList.contains("show") && s.default.isInViewportDom(e, 220) && e.classList.add("show");
          });
      }
      s.default.waitForLoader(function () {
          (window.scroll = new u.default(p)),
              new o.default(),
              new l.default(),
              new d.default(),
              (function () {
                  window.innerWidth;
                  var e = 0.01 * window.innerHeight;
                  (a = window.innerWidth <= 1024) ? document.documentElement.style.setProperty("--vh", "".concat(e, "px")) : a || document.documentElement.style.setProperty("--vh", "".concat(e, "px"));
                  var t = document.querySelector(".container");
                  if (t) {
                      var n = t.getBoundingClientRect();
                      document.documentElement.style.setProperty("--container-margin", "".concat(n.left, "px")), document.documentElement.style.setProperty("--container-width", "".concat(n.width, "px"));
                  }
              })(),
              p();
      });
  },
  function (e, t, n) {
      "use strict";
      var r = n(2),
          i = r(n(7));
      n(10);
      var a = r(n(6));
      n(16);
      var s,
          o,
          l = r(n(8)),
          d = r(n(11)),
          u = r(n(12)),
          c = r(n(13)),
          p = document.getElementById("overlay"),
          f = [].concat((0, i.default)(Array.from(document.querySelectorAll(".fade-in"))), (0, i.default)(Array.from(document.querySelectorAll(".fade-in-y"))));
      function h(e) {
          f.forEach(function (e) {
              !e.classList.contains("show") && a.default.isInViewportDom(e, 220) && e.classList.add("show");
          });
      }
      function m() {
          window.innerWidth;
          var e = 0.01 * window.innerHeight;
          (s = window.innerWidth <= 1024) && !o ? ((o = !0), document.documentElement.style.setProperty("--vh", "".concat(e, "px"))) : s || document.documentElement.style.setProperty("--vh", "".concat(e, "px"));
          var t = document.querySelector(".container");
          if (t) {
              var n = t.getBoundingClientRect();
              document.documentElement.style.setProperty("--container-margin", "".concat(n.left, "px")), document.documentElement.style.setProperty("--container-width", "".concat(n.width, "px"));
          }
      }
      a.default.waitForLoader(function () {
          (window.scroll = new l.default(h)), new d.default(), new u.default(), new c.default(), h();
      }),
          document.documentElement.setAttribute("data-browser", a.default.getBrowser()),
          m(),
          window.addEventListener("resize", m),
          Array.from(document.querySelectorAll(".inner-link")).forEach(function (e) {
              e.addEventListener("click", function (t) {
                  t.preventDefault(),
                      p.classList.add("show"),
                      setTimeout(function () {
                          location.href = e.getAttribute("href");
                      }, 350);
              });
          }),
          window.addEventListener("beforeunload", function (e) {
              p.classList.add("show");
          });
  },
  function (e, t, n) {
      "use strict";
      var r = n(2),
          i = r(n(7));
      n(10);
      var a = r(n(6));
      n(16), n(55), n(56);
      var s,
          o,
          l = r(n(8)),
          d = r(n(11)),
          u = r(n(12)),
          c = r(n(13)),
          p = document.getElementById("overlay"),
          f = [].concat((0, i.default)(Array.from(document.querySelectorAll(".fade-in"))), (0, i.default)(Array.from(document.querySelectorAll(".fade-in-y"))));
      function h(e) {
          f.forEach(function (e) {
              !e.classList.contains("show") && a.default.isInViewportDom(e, 220) && e.classList.add("show");
          });
      }
      function m() {
          window.innerWidth;
          var e = 0.01 * window.innerHeight;
          (s = window.innerWidth <= 1024) && !o ? ((o = !0), document.documentElement.style.setProperty("--vh", "".concat(e, "px"))) : s || document.documentElement.style.setProperty("--vh", "".concat(e, "px"));
          var t = document.querySelector(".container");
          if (t) {
              var n = t.getBoundingClientRect();
              document.documentElement.style.setProperty("--container-margin", "".concat(n.left, "px")), document.documentElement.style.setProperty("--container-width", "".concat(n.width, "px"));
          }
      }
      a.default.waitForLoader(function () {
          (window.scroll = new l.default(h)), new d.default(), new u.default(), new c.default(), h();
      }),
          document.documentElement.setAttribute("data-browser", a.default.getBrowser()),
          m(),
          window.addEventListener("resize", m),
          Array.from(document.querySelectorAll(".inner-link")).forEach(function (e) {
              e.addEventListener("click", function (t) {
                  t.preventDefault(),
                      p.classList.add("show"),
                      setTimeout(function () {
                          location.href = e.getAttribute("href");
                      }, 350);
              });
          }),
          window.addEventListener("beforeunload", function (e) {
              p.classList.add("show");
          });
  },
  function (e, t, n) {
      "use strict";
      var r = n(2),
          i = r(n(7));
      n(10);
      var a = r(n(6));
      n(16), n(55), n(56);
      var s,
          o,
          l = r(n(8)),
          d = r(n(11)),
          u = r(n(12)),
          c = r(n(13)),
          p = document.getElementById("overlay"),
          f = [].concat((0, i.default)(Array.from(document.querySelectorAll(".fade-in"))), (0, i.default)(Array.from(document.querySelectorAll(".fade-in-y"))));
      function h(e) {
          f.forEach(function (e) {
              !e.classList.contains("show") && a.default.isInViewportDom(e, 220) && e.classList.add("show");
          });
      }
      function m() {
          window.innerWidth;
          var e = 0.01 * window.innerHeight;
          (s = window.innerWidth <= 1024) && !o ? ((o = !0), document.documentElement.style.setProperty("--vh", "".concat(e, "px"))) : s || document.documentElement.style.setProperty("--vh", "".concat(e, "px"));
          var t = document.querySelector(".container");
          if (t) {
              var n = t.getBoundingClientRect();
              document.documentElement.style.setProperty("--container-margin", "".concat(n.left, "px")), document.documentElement.style.setProperty("--container-width", "".concat(n.width, "px"));
          }
      }
      a.default.waitForLoader(function () {
          (window.scroll = new l.default(h)), new d.default(), new u.default(), new c.default(), h();
      }),
          document.documentElement.setAttribute("data-browser", a.default.getBrowser()),
          m(),
          window.addEventListener("resize", m),
          Array.from(document.querySelectorAll(".inner-link")).forEach(function (e) {
              e.addEventListener("click", function (t) {
                  t.preventDefault(),
                      p.classList.add("show"),
                      setTimeout(function () {
                          location.href = e.getAttribute("href");
                      }, 350);
              });
          }),
          window.addEventListener("beforeunload", function (e) {
              p.classList.add("show");
          });
  },
  function (e, t, n) {
      "use strict";
      var r = n(2),
          i = r(n(7));
      n(10);
      var a = r(n(6));
      n(16), n(55), n(56);
      var s,
          o,
          l = r(n(8)),
          d = r(n(11)),
          u = r(n(12)),
          c = r(n(13)),
          p = document.getElementById("overlay"),
          f = [].concat((0, i.default)(Array.from(document.querySelectorAll(".fade-in"))), (0, i.default)(Array.from(document.querySelectorAll(".fade-in-y"))));
      function h(e) {
          f.forEach(function (e) {
              !e.classList.contains("show") && a.default.isInViewportDom(e, 220) && e.classList.add("show");
          });
      }
      function m() {
          window.innerWidth;
          var e = 0.01 * window.innerHeight;
          (s = window.innerWidth <= 1024) && !o ? ((o = !0), document.documentElement.style.setProperty("--vh", "".concat(e, "px"))) : s || document.documentElement.style.setProperty("--vh", "".concat(e, "px"));
          var t = document.querySelector(".container");
          if (t) {
              var n = t.getBoundingClientRect();
              document.documentElement.style.setProperty("--container-margin", "".concat(n.left, "px")), document.documentElement.style.setProperty("--container-width", "".concat(n.width, "px"));
          }
      }
      a.default.waitForLoader(function () {
          (window.scroll = new l.default(h)), new d.default(), new u.default(), new c.default(), h();
      }),
          document.documentElement.setAttribute("data-browser", a.default.getBrowser()),
          m(),
          window.addEventListener("resize", m),
          Array.from(document.querySelectorAll(".inner-link")).forEach(function (e) {
              e.addEventListener("click", function (t) {
                  t.preventDefault(),
                      p.classList.add("show"),
                      setTimeout(function () {
                          location.href = e.getAttribute("href");
                      }, 350);
              });
          }),
          window.addEventListener("beforeunload", function (e) {
              p.classList.add("show");
          });
  },
  function (e, t, n) {
      "use strict";
      var r = n(2),
          i = r(n(7));
      n(10);
      var a = r(n(6));
      n(16), n(55), n(56);
      var s,
          o,
          l = r(n(8)),
          d = r(n(11)),
          u = r(n(12)),
          c = r(n(13)),
          p = document.getElementById("overlay"),
          f = [].concat((0, i.default)(Array.from(document.querySelectorAll(".fade-in"))), (0, i.default)(Array.from(document.querySelectorAll(".fade-in-y"))));
      function h(e) {
          f.forEach(function (e) {
              !e.classList.contains("show") && a.default.isInViewportDom(e, 220) && e.classList.add("show");
          });
      }
      function m() {
          window.innerWidth;
          var e = 0.01 * window.innerHeight;
          (s = window.innerWidth <= 1024) && !o ? ((o = !0), document.documentElement.style.setProperty("--vh", "".concat(e, "px"))) : s || document.documentElement.style.setProperty("--vh", "".concat(e, "px"));
          var t = document.querySelector(".container");
          if (t) {
              var n = t.getBoundingClientRect();
              document.documentElement.style.setProperty("--container-margin", "".concat(n.left, "px")), document.documentElement.style.setProperty("--container-width", "".concat(n.width, "px"));
          }
      }
      a.default.waitForLoader(function () {
          (window.scroll = new l.default(h)), new d.default(), new u.default(), new c.default(), h();
      }),
          document.documentElement.setAttribute("data-browser", a.default.getBrowser()),
          m(),
          window.addEventListener("resize", m),
          Array.from(document.querySelectorAll(".inner-link")).forEach(function (e) {
              e.addEventListener("click", function (t) {
                  t.preventDefault(),
                      p.classList.add("show"),
                      setTimeout(function () {
                          location.href = e.getAttribute("href");
                      }, 350);
              });
          }),
          window.addEventListener("beforeunload", function (e) {
              p.classList.add("show");
          });
  },
  function (e, t, n) {
      "use strict";
      var r = n(2),
          i = r(n(7));
      n(10);
      var a = r(n(6));
      n(16), n(55), n(56);
      var s,
          o,
          l = r(n(8)),
          d = r(n(11)),
          u = r(n(12)),
          c = r(n(13)),
          p = document.getElementById("overlay"),
          f = [].concat((0, i.default)(Array.from(document.querySelectorAll(".fade-in"))), (0, i.default)(Array.from(document.querySelectorAll(".fade-in-y"))));
      function h(e) {
          f.forEach(function (e) {
              !e.classList.contains("show") && a.default.isInViewportDom(e, 220) && e.classList.add("show");
          });
      }
      function m() {
          window.innerWidth;
          var e = 0.01 * window.innerHeight;
          (s = window.innerWidth <= 1024) && !o ? ((o = !0), document.documentElement.style.setProperty("--vh", "".concat(e, "px"))) : s || document.documentElement.style.setProperty("--vh", "".concat(e, "px"));
          var t = document.querySelector(".container");
          if (t) {
              var n = t.getBoundingClientRect();
              document.documentElement.style.setProperty("--container-margin", "".concat(n.left, "px")), document.documentElement.style.setProperty("--container-width", "".concat(n.width, "px"));
          }
      }
      a.default.waitForLoader(function () {
          (window.scroll = new l.default(h)), new d.default(), new u.default(), new c.default(), h();
      }),
          document.documentElement.setAttribute("data-browser", a.default.getBrowser()),
          m(),
          window.addEventListener("resize", m),
          Array.from(document.querySelectorAll(".inner-link")).forEach(function (e) {
              e.addEventListener("click", function (t) {
                  t.preventDefault(),
                      p.classList.add("show"),
                      setTimeout(function () {
                          location.href = e.getAttribute("href");
                      }, 350);
              });
          }),
          window.addEventListener("beforeunload", function (e) {
              p.classList.add("show");
          });
  },
  function (e, t, n) {
      "use strict";
      var r = n(2),
          i = r(n(7));
      n(10);
      var a = r(n(6));
      n(16), n(55), n(56);
      var s,
          o,
          l = r(n(8)),
          d = r(n(11)),
          u = r(n(12)),
          c = r(n(13)),
          p = document.getElementById("overlay"),
          f = [].concat((0, i.default)(Array.from(document.querySelectorAll(".fade-in"))), (0, i.default)(Array.from(document.querySelectorAll(".fade-in-y"))));
      function h(e) {
          f.forEach(function (e) {
              !e.classList.contains("show") && a.default.isInViewportDom(e, 220) && e.classList.add("show");
          });
      }
      function m() {
          window.innerWidth;
          var e = 0.01 * window.innerHeight;
          (s = window.innerWidth <= 1024) && !o ? ((o = !0), document.documentElement.style.setProperty("--vh", "".concat(e, "px"))) : s || document.documentElement.style.setProperty("--vh", "".concat(e, "px"));
          var t = document.querySelector(".container");
          if (t) {
              var n = t.getBoundingClientRect();
              document.documentElement.style.setProperty("--container-margin", "".concat(n.left, "px")), document.documentElement.style.setProperty("--container-width", "".concat(n.width, "px"));
          }
      }
      a.default.waitForLoader(function () {
          (window.scroll = new l.default(h)), new d.default(), new u.default(), new c.default(), h();
      }),
          document.documentElement.setAttribute("data-browser", a.default.getBrowser()),
          m(),
          window.addEventListener("resize", m),
          Array.from(document.querySelectorAll(".inner-link")).forEach(function (e) {
              e.addEventListener("click", function (t) {
                  t.preventDefault(),
                      p.classList.add("show"),
                      setTimeout(function () {
                          location.href = e.getAttribute("href");
                      }, 350);
              });
          }),
          window.addEventListener("beforeunload", function (e) {
              p.classList.add("show");
          });
  },
  function (e, t, n) {
      "use strict";
      var r = n(2),
          i = r(n(7));
      n(10), n(16);
      var a = r(n(6)),
          s = r(n(11)),
          o = r(n(12)),
          l = r(n(13)),
          d = r(n(8));
      function u(e, t) {
          var n;
          if ("undefined" == typeof Symbol || null == e[Symbol.iterator]) {
              if (
                  Array.isArray(e) ||
                  (n = (function (e, t) {
                      if (!e) return;
                      if ("string" == typeof e) return c(e, t);
                      var n = Object.prototype.toString.call(e).slice(8, -1);
                      "Object" === n && e.constructor && (n = e.constructor.name);
                      if ("Map" === n || "Set" === n) return Array.from(e);
                      if ("Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return c(e, t);
                  })(e)) ||
                  (t && e && "number" == typeof e.length)
              ) {
                  n && (e = n);
                  var r = 0,
                      i = function () {};
                  return {
                      s: i,
                      n: function () {
                          return r >= e.length ? { done: !0 } : { done: !1, value: e[r++] };
                      },
                      e: function (e) {
                          throw e;
                      },
                      f: i,
                  };
              }
              throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
          }
          var a,
              s = !0,
              o = !1;
          return {
              s: function () {
                  n = e[Symbol.iterator]();
              },
              n: function () {
                  var e = n.next();
                  return (s = e.done), e;
              },
              e: function (e) {
                  (o = !0), (a = e);
              },
              f: function () {
                  try {
                      s || null == n.return || n.return();
                  } finally {
                      if (o) throw a;
                  }
              },
          };
      }
      function c(e, t) {
          (null == t || t > e.length) && (t = e.length);
          for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
          return r;
      }
      var p,
          f = [].concat((0, i.default)(Array.from(document.querySelectorAll(".fade-in"))), (0, i.default)(Array.from(document.querySelectorAll(".fade-in-y"))));
      function h(e) {
          f.forEach(function (e) {
              !e.classList.contains("show") && a.default.isInViewportDom(e, 220) && e.classList.add("show");
          });
      }
      a.default.waitForLoader(function () {
          (window.scroll = new d.default(y)),
              (window.scroll = new d.default(h)),
              new s.default(),
              new o.default(),
              new l.default(),
              (function () {
                  window.innerWidth;
                  var e = 0.01 * window.innerHeight;
                  (p = window.innerWidth <= 1024) ? document.documentElement.style.setProperty("--vh", "".concat(e, "px")) : p || document.documentElement.style.setProperty("--vh", "".concat(e, "px"));
                  var t = document.querySelector(".container");
                  if (t) {
                      var n = t.getBoundingClientRect();
                      document.documentElement.style.setProperty("--container-margin", "".concat(n.left, "px")), document.documentElement.style.setProperty("--container-width", "".concat(n.width, "px"));
                  }
              })(),
              h();
      });
      var m = document.querySelectorAll("section"),
          v = document.querySelectorAll(".menu_item"),
          g = document.querySelector(".itemsSticky");
      function y() {
          var e = new IntersectionObserver(
              function (e) {
                  e.forEach(function (e) {
                      if (e.isIntersecting) {
                          var t,
                              n = Array.from(v).find(function (t) {
                                  return t.dataset.url === e.target.id;
                              }),
                              r = u(v);
                          try {
                              for (r.s(); !(t = r.n()).done; ) {
                                  var i = t.value;
                                  i != n && i.classList.remove("active");
                              }
                          } catch (e) {
                              r.e(e);
                          } finally {
                              r.f();
                          }
                          if (n == "undefined") {
                          "keydata" == n.dataset.url ? g.classList.add("white") : g.classList.remove("white"), n.classList.add("active");
                        }
                      }
                  });
              },
              { root: null, rootMargin: "0px", threshold: 0.2 }
          );
          m.forEach(function (t) {
              return e.observe(t);
          });
      }
  },
  function (e, t, n) {
      "use strict";
      var r = n(2),
          i = r(n(7));
      n(10), n(16);
      var a,
          s = r(n(6)),
          o = r(n(11)),
          l = r(n(12)),
          d = r(n(13)),
          u = r(n(8)),
          c = [].concat((0, i.default)(Array.from(document.querySelectorAll(".fade-in"))), (0, i.default)(Array.from(document.querySelectorAll(".fade-in-y"))));
      function p(e) {
          c.forEach(function (e) {
              !e.classList.contains("show") && s.default.isInViewportDom(e, 220) && e.classList.add("show");
          });
      }
      s.default.waitForLoader(function () {
          (window.scroll = new u.default(p)),
              new o.default(),
              new l.default(),
              new d.default(),
              (function () {
                  window.innerWidth;
                  var e = 0.01 * window.innerHeight;
                  (a = window.innerWidth <= 1024) ? document.documentElement.style.setProperty("--vh", "".concat(e, "px")) : a || document.documentElement.style.setProperty("--vh", "".concat(e, "px"));
                  var t = document.querySelector(".container");
                  if (t) {
                      var n = t.getBoundingClientRect();
                      document.documentElement.style.setProperty("--container-margin", "".concat(n.left, "px")), document.documentElement.style.setProperty("--container-width", "".concat(n.width, "px"));
                  }
              })(),
              p();
      });
  },
  function (e, t, n) {
      "use strict";
      var r = n(2),
          i = r(n(7));
      n(10), n(16);
      var a,
          s = r(n(6)),
          o = r(n(11)),
          l = r(n(12)),
          d = r(n(13)),
          u = r(n(8)),
          c = [].concat((0, i.default)(Array.from(document.querySelectorAll(".fade-in"))), (0, i.default)(Array.from(document.querySelectorAll(".fade-in-y"))));
      function p(e) {
          c.forEach(function (e) {
              !e.classList.contains("show") && s.default.isInViewportDom(e, 220) && e.classList.add("show");
          });
      }
      s.default.waitForLoader(function () {
          new o.default(),
              new l.default(),
              new d.default(),
              (function () {
                  window.innerWidth;
                  var e = 0.01 * window.innerHeight;
                  (a = window.innerWidth <= 1024) ? document.documentElement.style.setProperty("--vh", "".concat(e, "px")) : a || document.documentElement.style.setProperty("--vh", "".concat(e, "px"));
                  var t = document.querySelector(".container");
                  if (t) {
                      var n = t.getBoundingClientRect();
                      document.documentElement.style.setProperty("--container-margin", "".concat(n.left, "px")), document.documentElement.style.setProperty("--container-width", "".concat(n.width, "px"));
                  }
              })(),
              (window.scroll = new u.default(p)),
              p();
      });
  },
  function (e, t, n) {
      "use strict";
      var r = n(2),
          i = r(n(7));
      n(10), n(16);
      var a,
          s = r(n(6)),
          o = r(n(11)),
          l = r(n(12)),
          d = r(n(13)),
          u = r(n(8)),
          c = [].concat((0, i.default)(Array.from(document.querySelectorAll(".fade-in"))), (0, i.default)(Array.from(document.querySelectorAll(".fade-in-y"))));
      function p(e) {
          c.forEach(function (e) {
              !e.classList.contains("show") && s.default.isInViewportDom(e, 220) && e.classList.add("show");
          });
      }
      s.default.waitForLoader(function () {
          new o.default(),
              new l.default(),
              new d.default(),
              (function () {
                  window.innerWidth;
                  var e = 0.01 * window.innerHeight;
                  (a = window.innerWidth <= 1024) ? document.documentElement.style.setProperty("--vh", "".concat(e, "px")) : a || document.documentElement.style.setProperty("--vh", "".concat(e, "px"));
                  var t = document.querySelector(".container");
                  if (t) {
                      var n = t.getBoundingClientRect();
                      document.documentElement.style.setProperty("--container-margin", "".concat(n.left, "px")), document.documentElement.style.setProperty("--container-width", "".concat(n.width, "px"));
                  }
              })(),
              (window.scroll = new u.default(p)),
              p();
      });
  },
  function (e, t, n) {
      "use strict";
      var r = n(2),
          i = r(n(7));
      n(10), n(16);
      var a,
          s = r(n(6)),
          o = r(n(11)),
          l = r(n(12)),
          d = r(n(13)),
          u = r(n(8)),
          c = [].concat((0, i.default)(Array.from(document.querySelectorAll(".fade-in"))), (0, i.default)(Array.from(document.querySelectorAll(".fade-in-y"))));
      function p(e) {
          c.forEach(function (e) {
              !e.classList.contains("show") && s.default.isInViewportDom(e, 220) && e.classList.add("show");
          });
      }
      s.default.waitForLoader(function () {
          new o.default(),
              new l.default(),
              new d.default(),
              (function () {
                  window.innerWidth;
                  var e = 0.01 * window.innerHeight;
                  (a = window.innerWidth <= 1024) ? document.documentElement.style.setProperty("--vh", "".concat(e, "px")) : a || document.documentElement.style.setProperty("--vh", "".concat(e, "px"));
                  var t = document.querySelector(".container");
                  if (t) {
                      var n = t.getBoundingClientRect();
                      document.documentElement.style.setProperty("--container-margin", "".concat(n.left, "px")), document.documentElement.style.setProperty("--container-width", "".concat(n.width, "px"));
                  }
              })(),
              (window.scroll = new u.default(p)),
              p();
      });
  },
  function (e, t, n) {
      "use strict";
      var r = n(2),
          i = r(n(7));
      n(10);
      var a = r(n(6)),
          s = r(n(81)),
          o = r(n(82));
      n(16);
      var l,
          d,
          u = r(n(8)),
          c = r(n(11)),
          p = r(n(12)),
          f = r(n(13)),
          h = r(n(83)),
          m = document.getElementById("overlay"),
          v = [].concat((0, i.default)(Array.from(document.querySelectorAll(".fade-in"))), (0, i.default)(Array.from(document.querySelectorAll(".fade-in-y")))),
          g = (new o.default(), []);
      function y(e) {
          v.forEach(function (e) {
              !e.classList.contains("show") && a.default.isInViewportDom(e, 220) && e.classList.add("show");
          });
      }
      function w() {
          window.innerWidth;
          var e = 0.01 * window.innerHeight;
          (l = window.innerWidth <= 1024) && !d ? ((d = !0), document.documentElement.style.setProperty("--vh", "".concat(e, "px"))) : l || document.documentElement.style.setProperty("--vh", "".concat(e, "px"));
          var t = document.querySelector(".container");
          if (t) {
              var n = t.getBoundingClientRect();
              document.documentElement.style.setProperty("--container-margin", "".concat(n.left, "px")), document.documentElement.style.setProperty("--container-width", "".concat(n.width, "px"));
          }
      }
      a.default.waitForLoader(function () {
          (window.scroll = new u.default(y)), new c.default(), new p.default(), new f.default(), y();
      }),
          document.documentElement.setAttribute("data-browser", a.default.getBrowser()),
          (function () {
              function e(t) {
                  Array.from(document.querySelectorAll(".video-component .video-container")).forEach(function (t) {
                      t.removeEventListener("click", e);
                  }),
                      s.default.init(function () {
                          var e;
                          (e = function () {
                              t.click();
                          }),
                              Array.from(document.querySelectorAll(".video-component .video-container")).forEach(function (e) {
                                  g.push(
                                      new h.default(e, function () {
                                          g.forEach(function (t) {
                                              t.$el !== e && t.stop();
                                          });
                                      })
                                  );
                              }),
                              setTimeout(function () {
                                  e && e();
                              }, 1e3);
                      });
              }
              Array.from(document.querySelectorAll(".video-component .video-container")).forEach(function (t) {
                  t.addEventListener("click", function () {
                      e(t);
                  });
              }),
                  !0;
          })(),
          w(),
          window.addEventListener("resize", w),
          Array.from(document.querySelectorAll(".inner-link")).forEach(function (e) {
              e.addEventListener("click", function (t) {
                  t.preventDefault(),
                      m.classList.add("show"),
                      setTimeout(function () {
                          location.href = e.getAttribute("href");
                      }, 350);
              });
          }),
          window.addEventListener("beforeunload", function (e) {
              m.classList.add("show");
          });
  },
  function (e, t, n) {
      "use strict";
      var r = n(2),
          i = r(n(7));
      n(10), n(16);
      var a,
          s = r(n(6)),
          o = r(n(11)),
          l = r(n(12)),
          d = r(n(13)),
          u = r(n(8)),
          c = [].concat((0, i.default)(Array.from(document.querySelectorAll(".fade-in"))), (0, i.default)(Array.from(document.querySelectorAll(".fade-in-y"))));
      function p(e) {
          c.forEach(function (e) {
              !e.classList.contains("show") && s.default.isInViewportDom(e, 220) && e.classList.add("show");
          });
      }
      s.default.waitForLoader(function () {
          (window.scroll = new u.default(p)),
              new o.default(),
              new l.default(),
              new d.default(),
              (function () {
                  window.innerWidth;
                  var e = 0.01 * window.innerHeight;
                  (a = window.innerWidth <= 1024) && !mobileInitialized
                      ? ((mobileInitialized = !0), document.documentElement.style.setProperty("--vh", "".concat(e, "px")))
                      : a || document.documentElement.style.setProperty("--vh", "".concat(e, "px"));
                  var t = document.querySelector(".container");
                  if (t) {
                      var n = t.getBoundingClientRect();
                      document.documentElement.style.setProperty("--container-margin", "".concat(n.left, "px")), document.documentElement.style.setProperty("--container-width", "".concat(n.width, "px"));
                  }
              })(),
              p();
      });
  },
  function (e, t, n) {
      "use strict";
      var r = n(2),
          i = r(n(7));
      n(10);
      var a = r(n(6)),
          s = r(n(81)),
          o = r(n(82));
      n(16);
      var l,
          d,
          u = r(n(8)),
          c = r(n(11)),
          p = r(n(12)),
          f = r(n(13)),
          h = r(n(83)),
          m = (r(n(184)), document.getElementById("overlay")),
          v = [].concat((0, i.default)(Array.from(document.querySelectorAll(".fade-in"))), (0, i.default)(Array.from(document.querySelectorAll(".fade-in-y")))),
          g = (new o.default(), []);
      function y(e) {
          v.forEach(function (e) {
              !e.classList.contains("show") && a.default.isInViewportDom(e, 220) && e.classList.add("show");
          });
      }
      function w() {
          window.innerWidth;
          var e = 0.01 * window.innerHeight;
          (l = window.innerWidth <= 1024) && !d ? ((d = !0), document.documentElement.style.setProperty("--vh", "".concat(e, "px"))) : l || document.documentElement.style.setProperty("--vh", "".concat(e, "px"));
          var t = document.querySelector(".container");
          if (t) {
              var n = t.getBoundingClientRect();
              document.documentElement.style.setProperty("--container-margin", "".concat(n.left, "px")), document.documentElement.style.setProperty("--container-width", "".concat(n.width, "px"));
          }
      }
      a.default.waitForLoader(function () {
          (window.scroll = new u.default(y)), new c.default(), new p.default(), new f.default(), y();
      }),
          document.documentElement.setAttribute("data-browser", a.default.getBrowser()),
          (function () {
              function e(t) {
                  Array.from(document.querySelectorAll(".video-component .video-container")).forEach(function (t) {
                      t.removeEventListener("click", e);
                  }),
                      s.default.init(function () {
                          var e;
                          (e = function () {
                              t.click();
                          }),
                              Array.from(document.querySelectorAll(".video-component .video-container")).forEach(function (e) {
                                  g.push(
                                      new h.default(e, function () {
                                          g.forEach(function (t) {
                                              t.$el !== e && t.stop();
                                          });
                                      })
                                  );
                              }),
                              setTimeout(function () {
                                  e && e();
                              }, 1e3);
                      });
              }
              Array.from(document.querySelectorAll(".video-component .video-container")).forEach(function (t) {
                  t.addEventListener("click", function () {
                      e(t);
                  });
              }),
                  !0;
          })(),
          w(),
          window.addEventListener("resize", w),
          Array.from(document.querySelectorAll(".inner-link")).forEach(function (e) {
              e.addEventListener("click", function (t) {
                  t.preventDefault(),
                      m.classList.add("show"),
                      setTimeout(function () {
                          location.href = e.getAttribute("href");
                      }, 350);
              });
          }),
          window.addEventListener("beforeunload", function (e) {
              m.classList.add("show");
          });
  },
  function (e, t, n) {
      "use strict";
      var r = document.querySelector(".audio-player");
      if (r) {
          var i = r.dataset.audio,
              a = new Audio("".concat(i));
          a.addEventListener(
              "loadeddata",
              function () {
                  (r.querySelector(".time .length").textContent = d(a.duration)), (a.volume = 0.75);
              },
              !1
          );
          var s = r.querySelector(".timeline");
          s.addEventListener(
              "click",
              function (e) {
                  var t = window.getComputedStyle(s).width,
                      n = (e.offsetX / parseInt(t)) * a.duration;
                  a.currentTime = n;
              },
              !1
          );
          var o = r.querySelector(".controls .volume-slider");
          o.addEventListener(
              "click",
              function (e) {
                  var t = window.getComputedStyle(o).width,
                      n = e.offsetX / parseInt(t);
                  (a.volume = n), (r.querySelector(".controls .volume-percentage").style.width = 100 * n + "%");
              },
              !1
          ),
              setInterval(function () {
                  (r.querySelector(".progress").style.width = (a.currentTime / a.duration) * 100 + "%"), (r.querySelector(".time .current").textContent = d(a.currentTime));
              }, 500);
          var l = r.querySelector(".controls .toggle-play");
          function d(e) {
              var t = parseInt(e),
                  n = parseInt(t / 60);
              t -= 60 * n;
              var r = parseInt(n / 60);
              return (
                  (n -= 60 * r),
                  0 === r
                      ? "".concat(n, ":").concat(String(t % 60).padStart(2, 0))
                      : ""
                            .concat(String(r).padStart(2, 0), ":")
                            .concat(n, ":")
                            .concat(String(t % 60).padStart(2, 0))
              );
          }
          l.addEventListener(
              "click",
              function () {
                  a.paused ? (l.classList.remove("play"), l.classList.add("pause"), a.play()) : (l.classList.remove("pause"), l.classList.add("play"), a.pause());
              },
              !1
          ),
              r.querySelector(".volume-button").addEventListener("click", function () {
                  var e = r.querySelector(".volume-container .volume");
                  (a.muted = !a.muted), a.muted ? (e.classList.remove("icono-volumeMedium"), e.classList.add("icono-volumeMute")) : (e.classList.add("icono-volumeMedium"), e.classList.remove("icono-volumeMute"));
              });
      }
  },
]);
