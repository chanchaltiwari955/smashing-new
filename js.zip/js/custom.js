(function ($, Drupal) {
  Drupal.behaviors.searchcustomBehavior = {
    attach: function (context, settings) {
      if('#input-search'){
        $(document, context).ajaxComplete(function(){
          $("#search-content").css({ "opacity": "1", "height": "313px" });
        });
      }
      $(document, context).ajaxComplete(function(){
        $(".small-container").children().addClass("show");
      });
      $('.clear-search', context).on('click', function(){
        $('#input-search').val("");
        $('span.notag').remove();
      });

      $('#nav-search', context).on('click', function(){
        if(!$('#search').hasClass('show')) {
          $('#search').addClass('show')
        }
      });

      if(location.pathname.slice(settings.path.baseUrl.length) == 'contact-us'){
        $("#nav-share").hide();
      }
      $(document).ready(function(){
        var $temp = $("<input>");
        var $url = $(location).attr('href');
        $('#copy-link').click(function() {
        $("body").append($temp);
        $temp.val($url).select();
        document.execCommand("copy");
        $temp.remove();
        $("div.copy-link-msg").text("copy");
        });
      });
    }
  };

  $(document).ajaxComplete(function(){
    Array.from(document.querySelectorAll('.cards-grid')).forEach(function (el) {
      var isMobile = window.innerWidth < 800;
    
      if (!isMobile) {
        grid_resize(el);
      }
    });
    
  });

  function grid_resize(el) {
    var maxItems = 3;
    var containerWidth = el.parentElement.clientWidth;
    var cardM = 32;
    var cardW = (containerWidth - cardM * (maxItems - 1)) / maxItems;
    var cards = Array.from(el.children);

    el.style.width = "".concat(containerWidth + cardM, "px");
    var j = 1;
    cards.forEach(function (card, i) {
      var size = 'normal';
      if (maxItems === 3 && (j === 2 || j === 6)) size = 'big';
      if (maxItems === 3 && j === 8) size = 'full';
      card.setAttribute('data-size', size);

      switch (size) {
        case 'big':
          card.style.width = "".concat(cardW * 2 + cardM, "px");
          break;

        case 'full':
          card.style.width = "".concat(containerWidth, "px");
          break;

        default:
          card.style.width = "".concat(cardW, "px");
          break;
      }

      if (size === 'big' || size === 'full') {
        if (card.classList.contains('card-news')) {
          card.querySelector('.card-content').style.width = "".concat(cardW, "px");
          card.querySelector('figure').style.width = "calc(100% - ".concat(cardW, "px)");
        }
      }

      card.style.marginRight = "".concat(cardM, "px");
      card.style.marginBottom = "".concat(cardM, "px");
      if (j > 7) j = 1;else j++;
    });
  }
  function contact_url() {
    var url = $(location).attr('href',);
    if(url == '/contact-us') {
      $("#nav-share").hide();
    }
  }
})(jQuery, Drupal);
